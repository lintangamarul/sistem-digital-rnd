<?php 
namespace App\Controllers;

use App\Models\McSpecModel; // Tetap pertahankan model lainnya jika diperlukan
use Config\Database;

class MasterPps extends BaseController
{
    public function index()
    {
        // Query untuk data MC Spec
        $mcModel = new McSpecModel();
        $mcModel->select('mc_spec.*, master_table.capacity as master_capacity, master_table.cushion as master_cushion, master_table.dh_dies as master_dh_dies');
        $mcModel->join('master_table', 'master_table.machine = mc_spec.machine', 'left');
        $data['specs'] = $mcModel->findAll();
    
        // Query untuk data Standard Die Design
        $db = \Config\Database::connect();
        $sql = "SELECT die_length, die_width, die_height, category, jenis_proses, proses
                FROM standard_die_design";
        $query = $db->query($sql);
        $data['design'] = $query->getResultArray();
    
        // Data gabungan dikirim ke view
        return view('master_pps/index', $data);
    }
    

    
}
