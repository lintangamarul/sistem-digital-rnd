<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use PhpOffice\PhpSpreadsheet\IOFactory;     
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\PpsModel;
use App\Models\PpsDiesModel;
use App\Models\DcpOverviewModel;
use App\Models\McSpecModel;
use App\Models\MasterTableModel;

use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
class Pps extends Controller
{

    protected $ppsModel;
    protected $ppsDiesModel;
    protected $mcSpecModel;
    protected $masterTableModel;

    public function __construct()
    {   
        $this->ppsModel = new PpsModel();
        $this->ppsDiesModel = new PpsDiesModel();
        $this->mcSpecModel = new McSpecModel();  
        $this->masterTableModel = new MasterTableModel(); 
    }
    // Tampilkan form input
    public function create()
    {
        $mcSpecData = $this->mcSpecModel->findAll();
        
        // Ambil data dari master_table
        $masterTableData = $this->masterTableModel->findAll();
  
        // Kirimkan data ke view
        return view('pps/create', [
            'mcSpecData' => $mcSpecData,
            'masterTableData' => $masterTableData
        ]);
    }

    public function index()
    {
        $ppsModel = new PpsModel();
        $data['pps'] = $ppsModel->findAll(); 

        return view('pps/index', $data);
    }

    public function detail($id)
    {
        $ppsModel = new PpsModel();
        $ppsDiesModel = new PpsDiesModel();

        $pps = $ppsModel->find($id);
        if (!$pps) {
            return redirect()->to('/pps')->with('error', 'Data tidak ditemukan');
        }

        $dies = $ppsDiesModel->getDiesByPps($id);

        $data = [
            'pps'  => $pps,
            'dies' => $dies
        ];

        return view('pps/detail', $data);
    }
    public function listProcessDies($id)
    {
        $ppsModel      = new PpsModel();
        $ppsDiesModel  = new PpsDiesModel();
        $overviewModel = new DcpOverviewModel();
    
        $dies = $ppsDiesModel->getDiesByPps($id);
        $pps = $ppsModel->where('id', $id)->first();
        if (!empty($dies)) {
            $diesIds = array_column($dies, 'id');
            $dcp = $overviewModel->whereIn('id_pps_dies', $diesIds)->findAll();
        } else {
            $dcp = [];
        }

        $data = [
            'dies' => $dies,
            'dcp'  => $dcp,
            'pps'  => $pps,
            'id' => $id
        ];
    
        return view('pps/list_process_dcp', $data);
    }
    public function fetchMachine()
    {
        $db = \Config\Database::connect();
    
        // Ambil input dari POST
        $process       = $this->request->getPost('process');
        $proses        = $this->request->getPost('proses');
        $proses_join   = $this->request->getPost('proses_join');
        $length_mp     = $this->request->getPost('length_mp');
        $main_pressure = $this->request->getPost('main_pressure');
    
        if (!$process || !$proses || !$length_mp || !$main_pressure) {
            return $this->response->setStatusCode(400)->setJSON([
                'error'    => 'Data tidak lengkap, pastikan kolom Process, Proses, Length MP dan Main Pressure tidak kosong.',
                'csrfHash' => csrf_hash()
            ]);
        }
    
        $dieCount = count($process);
        if (count($main_pressure) !== $dieCount) {
            return $this->response->setStatusCode(400)->setJSON([
                'error'    => 'Jumlah nilai Main Pressure tidak sesuai dengan baris input lainnya.',
                'csrfHash' => csrf_hash()
            ]);
        }
    
        for ($i = 0; $i < $dieCount; $i++) {
            if (empty($process[$i]) || empty($proses[$i]) || empty($length_mp[$i]) || empty($main_pressure[$i])) {
                return $this->response->setStatusCode(400)->setJSON([
                    'error'    => 'Data tidak boleh kosong pada baris ke-' . ($i + 1),
                    'csrfHash' => csrf_hash()
                ]);
            }
        }
    
        $thresholds = array_map('floatval', $main_pressure);
    
        $selectColumns    = [];
        $joins            = "";
        $whereConditions  = [];
        $total_diff_parts = [];
        $tes = null;
    
        if ($dieCount > 4) {
            $selectColumns[] = "t1.machine AS machine1";
            $selectColumns[] = "t1.capacity AS capacity1";
            $selectColumns[] = "t1.cushion AS cushion1";
            $selectColumns[] = "t1.dh_dies AS dh_dies1";
            $whereConditions[] = "(0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= " . $thresholds[0] .
                                 " AND (t1.machine LIKE '%1%') AND (t1.machine LIKE '%G%' OR t1.machine LIKE '%F%')";
            $total_diff_parts[] = "(0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2)) - " . $thresholds[0] . ")";
    
            for ($i = 2; $i <= $dieCount && $i <= 4; $i++) {
                $alias = "t" . $i;
                $selectColumns[] = "$alias.machine AS machine$i";
                $selectColumns[] = "$alias.capacity AS capacity$i";
                $selectColumns[] = "$alias.cushion AS cushion$i";
                $selectColumns[] = "$alias.dh_dies AS dh_dies$i";
                $prevAlias = "t" . ($i - 1);
                $joins .= " JOIN master_table $alias ON LEFT(t1.machine, 1) = LEFT($alias.machine, 1) AND $prevAlias.machine < $alias.machine ";
                $whereConditions[] = "(0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= " . $thresholds[$i - 1] .
                                     " AND (t$i.machine LIKE '%$i%') AND (t$i.machine LIKE '%G%' OR t$i.machine LIKE '%F%')";
                $total_diff_parts[] = "(0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2)) - " . $thresholds[$i - 1] . ")";
            }
              
            $select = implode(", ", $selectColumns);
            $total_diff = "(" . implode(" + ", $total_diff_parts) . ") AS total_diff";
            $select .= ", " . $total_diff;
            $where = implode(" AND ", $whereConditions);
            
            $sql = "SELECT $select FROM master_table t1 $joins WHERE $where ORDER BY total_diff ASC LIMIT 1"; 
            $query = $db->query($sql);
        } else {
            $selectColumns[] = "t1.machine AS machine1";
            $selectColumns[] = "t1.capacity AS capacity1";
            $selectColumns[] = "t1.cushion AS cushion1";
            $selectColumns[] = "t1.dh_dies AS dh_dies1";
            $whereConditions[] = "(0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= " . $thresholds[0] .
                                 " AND (t1.machine LIKE '%1%' OR t1.machine LIKE '%SP%')";
            $total_diff_parts[] = "(0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2)) - " . $thresholds[0] . ")";
            
            for ($i = 2; $i <= $dieCount && $i <= 4; $i++) {
                $alias = "t" . $i;
                $prevAlias = "t" . ($i - 1);
            
                $selectColumns[] = "$alias.machine AS machine$i";
                $selectColumns[] = "$alias.capacity AS capacity$i";
                $selectColumns[] = "$alias.cushion AS cushion$i";
                $selectColumns[] = "$alias.dh_dies AS dh_dies$i";
            
                // Penyesuaian join jika machine sebelumnya adalah SP
                $joins .= " JOIN master_table $alias ON LEFT(t1.machine, 1) = LEFT($alias.machine, 1) AND (
                                $prevAlias.machine LIKE '%SP%' OR $prevAlias.machine < $alias.machine
                            )";
            
                $whereConditions[] = "(0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= " . $thresholds[$i - 1] .
                                     " AND ($alias.machine LIKE '%$i%' OR $alias.machine LIKE '%SP%')";
            
                $total_diff_parts[] = "(0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2)) - " . $thresholds[$i - 1] . ")";
            }
            
            $select = implode(", ", $selectColumns);
            $total_diff = "(" . implode(" + ", $total_diff_parts) . ") AS total_diff";
            $select .= ", " . $total_diff;
            $where = implode(" AND ", $whereConditions);
            
            $sql = "SELECT $select FROM master_table t1 $joins WHERE $where ORDER BY total_diff ASC LIMIT 1";
            $query = $db->query($sql);
            
        }
      
        if ($query && $query->getNumRows() > 0) {
            $result = $query->getRowArray();
            if (empty($result['machine1'])) {
                return $this->response->setStatusCode(400)->setJSON([
                    'error'    => 'Machine tidak boleh kosong.',
                    'csrfHash' => csrf_hash()
                ]);
            }
           
            for ($i = 5; $i <= $dieCount; $i++) {
                $acuanMachine = isset($result['machine3']) ? $result['machine3'] : '';
                if (strpos($acuanMachine, 'F') !== false) {
                    $machineTarget = 'D' . ($i - 4);
                    $sqlNew = "SELECT machine, capacity, cushion, dh_dies FROM master_table WHERE machine LIKE ? LIMIT 1";
                    $queryNew = $db->query($sqlNew, [$machineTarget . '%']);
                    if ($queryNew->getNumRows() > 0) {
                        $machinelastData = $queryNew->getRow();
                        $result['machine' . $i] = $machinelastData->machine;
                        $result['capacity' . $i] = $machinelastData->capacity;
                        $result['cushion' . $i]  = $machinelastData->cushion;
                        $result['dh_dies' . $i]  = $machinelastData->dh_dies;
                    }
                } elseif (strpos($acuanMachine, 'G') !== false) {
                    $machineTarget = 'D' . ($i - 4);
                    $sqlNew = "SELECT machine, capacity, cushion, dh_dies FROM master_table WHERE machine LIKE ? LIMIT 1";
                    $queryNew = $db->query($sqlNew, [$machineTarget . '%']);
                    if ($queryNew->getNumRows() > 0) {
                        $machinelastData = $queryNew->getRow();
                        $result['machine' . $i] = $machinelastData->machine;
                        $result['capacity' . $i] = $machinelastData->capacity;
                        $result['cushion' . $i]  = $machinelastData->cushion;
                        $result['dh_dies' . $i]  = $machinelastData->dh_dies;
                    }
                } else {
                    if ($i == 5) {
                        $alias = "t5";
                        $prevAlias = "t4";
                        $sqlDefault = "SELECT $alias.machine AS machine, $alias.capacity AS capacity, $alias.cushion AS cushion, $alias.dh_dies AS dh_dies 
                                       FROM master_table $alias 
                                       WHERE (0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= ? 
                                       LIMIT 1";
                        $queryDefault = $db->query($sqlDefault, [$thresholds[$i - 1]]);
                        if ($queryDefault->getNumRows() > 0) {
                            $machinelastData = $queryDefault->getRow();
                            $result['machine' . $i] = $machinelastData->machine;
                            $result['capacity' . $i] = $machinelastData->capacity;
                            $result['cushion' . $i]  = $machinelastData->cushion;
                            $result['dh_dies' . $i]  = $machinelastData->dh_dies;
                        }
                        $tes = $result['machine' . $i];
                    } else {
                        $alias = "t" . $i;
                        $prevAlias = "t" . ($i - 1);
                        $sqlDefault = "SELECT $alias.machine AS machine, $alias.capacity AS capacity, $alias.cushion AS cushion, $alias.dh_dies AS dh_dies 
                                       FROM master_table $alias 
                                       JOIN master_table $prevAlias ON LEFT($prevAlias.machine, 1) = LEFT($alias.machine, 1) AND $prevAlias.machine < $alias.machine 
                                       WHERE (0.85 * CAST(REPLACE(REPLACE($alias.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= ? 
                                       LIMIT 1";
                        $queryDefault = $db->query($sqlDefault, [$thresholds[$i - 1]]);
                        $tes = $queryDefault;
                        if ($queryDefault->getNumRows() > 0) {
                            $machinelastData = $queryDefault->getRow();
                            $result['machine' . $i] = $machinelastData->machine;
                            $result['capacity' . $i] = $machinelastData->capacity;
                            $result['cushion' . $i]  = $machinelastData->cushion;
                            $result['dh_dies' . $i]  = $machinelastData->dh_dies;
                        }
                    }
                }
            }
            if (isset($proses[0]) && strpos($proses[0], 'BL') !== false) {
                if (isset($result['machine' . $dieCount]) && isset($result['capacity' . $dieCount])) {
                    $machinelast = $result['machine' . $dieCount];
                    $capacitylast = floatval($result['capacity' . $dieCount]);
                    
                    if (($capacitylast * 0.85) >= floatval($main_pressure[0])) {
                        $sqlMachine = "SELECT 
                                            t1.machine AS machine, 
                                            t1.capacity AS capacity, 
                                            t1.cushion AS cushion,
                                            t1.dh_dies AS dh_dies,
                                            ABS((0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) - ?) AS diff
                                    FROM master_table t1 
                                    WHERE (0.85 * CAST(REPLACE(REPLACE(t1.capacity, ',', ''), ' T', '') AS DECIMAL(10,2))) >= ? 
                                        AND (t1.machine LIKE '%1%' OR t1.machine LIKE '%MP%' OR t1.machine LIKE '%4%' OR t1.machine LIKE '%SP%')
                                    ORDER BY diff ASC
                                    LIMIT 1";
                        $queryMachine = $db->query($sqlMachine, [floatval($main_pressure[0]), $thresholds[0]]);
                        
                        if ($queryMachine->getNumRows() > 0) {
                            $machinelastData = $queryMachine->getRow();
                            $checknewt1 = $machinelastData->machine;
                            $checkoldt1 = $result['machine1'];
                        
                            if ($checknewt1 != $checkoldt1) {

                                $tempMachine  = [];
                                $tempCapacity = [];
                                $tempCushion  = [];
                                $tempDhDies   = [];
                                
                                for ($i = 2; $i <= $dieCount && $i <= 4; $i++) {
                                    $tempMachine[$i ]  = $result['machine' . $i- 1];
                                    $tempCapacity[$i] = $result['capacity' . $i- 1];
                                    $tempCushion[$i]  = $result['cushion' . $i- 1];
                                    $tempDhDies[$i]   = $result['dh_dies' . $i- 1];
                                }
                                
                                for ($i = 2; $i <= $dieCount && $i <= 4; $i++) {
                                    $result['machine' . $i] = $tempMachine[$i];
                                    $result['capacity' . $i] = $tempCapacity[$i];
                                    $result['cushion' . $i]  = $tempCushion[$i];
                                    $result['dh_dies' . $i]  = $tempDhDies[$i];
                                }
                            }
                            
                        
                            $result['machine1'] = $machinelastData->machine;
                            $result['capacity1'] = $machinelastData->capacity;
                            $result['cushion1']  = $machinelastData->cushion;
                            $result['dh_dies1']  = $machinelastData->dh_dies;
                        }
                    }
                }
            }
            
            $machineData = [];
            $categoryData = [];
            $bigDieMachines = ['A', 'D', 'E', 'F', 'G'];
            $mediumDieMachines = ['B', 'H', 'C'];
    
            for ($i = 1; $i <= $dieCount; $i++) {
                $machineName = isset($result['machine' . $i]) ? $result['machine' . $i] : null;
                if (!empty($machineName)) {
                $queryMachine = $db->query("
                    SELECT 
                        machine,
                        bolster_length,
                        bolster_width,
                        slide_area_length,
                        slide_area_width,
                        die_height,
                        cushion_pad_length,
                        cushion_pad_width,
                        cushion_stroke
                    FROM mc_spec 
                    WHERE machine = ?", [$machineName]);
                // $machineData[] = $queryMachine->getRowArray();

                $machineRow = $queryMachine->getRowArray();
                $machineData[] = $machineRow;

                if ($machineRow) {
                    $result['dh_dies' . $i] = $machineRow['die_height'];
                }
                } else {
                    $machineData[] = null;
                }
                $machinePrefix = strtoupper(substr($machineName, 0, 1));
                if (in_array($machinePrefix, $bigDieMachines)) {
                    $categoryData[] = "BIG DIE";
                } elseif (in_array($machinePrefix, $mediumDieMachines)) {
                    $categoryData[] = "MEDIUM DIE";
                } else {
                    $categoryData[] = "SMALL DIE";
                }
            }
            
            $dieLengthStandard = [];
            $dieWidthStandard  = [];
            $dieHeightStandard = [];
            $prosesValue = NULL;
            $die_proses_standard_die = [];
            for ($i = 0; $i < $dieCount; $i++) {
                $jenis_proses = empty($proses_join[$i]) ? "SINGLE" : "GANG";
                if ($categoryData[$i] == "BIG DIE") {
                    $jenis_proses = "SINGLE";
                    if ($jenis_proses == "SINGLE") {
                        if (
                            strpos($proses[$i], "DRAW") !== false ||
                            strpos($proses[$i], "FORM") !== false ||
                            strpos($proses[$i], "BEND") !== false ||
                            strpos($proses[$i], "REST") !== false
                        ) {
                            $prosesValue = "DRAW";
                        } elseif (strpos($proses[$i], "CAM-FLANGE") !== false) {
                            $prosesValue = "CAM FLANGE";
                        } elseif (strpos($proses[$i], "FLANGE") !== false) {
                            $prosesValue = "FLANGE";
                        } else {
                            $prosesValue = "TRIM";
                        }
                    }
                } elseif ($categoryData[$i] == "MEDIUM DIE") {
                    if ($jenis_proses == "SINGLE") {
                        if (
                            strpos($proses[$i], "DRAW") !== false ||
                            strpos($proses[$i], "FORM") !== false ||
                            strpos($proses[$i], "BEND") !== false ||
                            strpos($proses[$i], "REST") !== false
                        ) {
                            $prosesValue = "DRAW";
                        } elseif (strpos($proses[$i], "FLANGE") !== false) {
                            $prosesValue = "FLANGE";
                        }elseif (strpos($proses[$i], "CAM") !== false && strpos($proses[$i], "PIE") !== false) {
                            $prosesValue = "CAM PIE";
                        } else {
                            $prosesValue = "TRIM";
                        }
                    } else {
                        if (
                            strpos($proses[$i], "DRAW") !== false ||
                            strpos($proses[$i], "FLANGE") !== false ||
                            strpos($proses[$i], "FORM") !== false ||
                            strpos($proses[$i], "BEND") !== false ||
                            strpos($proses[$i], "REST") !== false
                        ) {
                            $prosesValue = "DRAW";
                        } elseif (
                            strpos($proses[$i], "CAM") !== false && strpos($proses[$i], "PIE") !== false
                        ) {
                            if (strpos($proses_join[$i], "FLANGE") !== false) {
                                $prosesValue = "FLANGE-CAM PIE";
                            }
                        } elseif (strpos($proses[$i], "FLANGE") !== false) {
                            if (strpos($proses_join[$i], "CAM") !== false && strpos($proses_join[$i], "PIE") !== false) {
                                $prosesValue = "FLANGE-CAM PIE";
                            }
                        } else {
                            $prosesValue = "TRIM";
                        }
                    }
                } elseif ($categoryData[$i] == "SMALL DIE") {
                    if ($jenis_proses == "SINGLE") {
                        if (strpos($proses[$i], "CAM") !== false && strpos($proses[$i], "PIE") !== false) {
                            $prosesValue = "CAM PIE";
                        } 
                        elseif (
                            strpos($proses[$i], "DRAW") !== false ||
                            strpos($proses[$i], "FLANGE") !== false ||
                            strpos($proses[$i], "FORM") !== false ||
                            strpos($proses[$i], "BEND") !== false ||
                            strpos($proses[$i], "PIE") !== false ||
                            strpos($proses[$i], "REST") !== false
                        ) {
                            $prosesValue = "FORMING";
                        } else {
                            $prosesValue = "BLANK";
                        }
                    } elseif ($jenis_proses == "GANG") {
                        if (
                            (isset($proses[$i]) && strpos($proses[$i], "BEND") !== false) || 
                            (isset($proses_join[$i]) && strpos($proses_join[$i], "BEND") !== false)
                        ) {
                            $prosesValue = "BEND 1, BEND 2";
                        } elseif (
                            ((isset($proses[$i]) && strpos($proses[$i], "FORM") !== false) || 
                            (isset($proses_join[$i]) && strpos($proses_join[$i], "FORM") !== false)) &&
                            ((isset($proses[$i]) && strpos($proses[$i], "PIE") !== false) || 
                            (isset($proses_join[$i]) && strpos($proses_join[$i], "PIE") !== false))
                        ) {
                            $prosesValue = "FORMING, PIE";
                        } elseif (
                            ((isset($proses[$i]) && strpos($proses[$i], "BLANK") !== false) || 
                            (isset($proses_join[$i]) && strpos($proses_join[$i], "BLANK") !== false)) &&
                            ((isset($proses[$i]) && strpos($proses[$i], "PIE") !== false) || 
                            (isset($proses_join[$i]) && strpos($proses_join[$i], "PIE") !== false))
                        ) {
                            $prosesValue = "BLANK-PIE";
                        } elseif (
                            (isset($proses[$i]) && preg_match("/TRIM|PIE|BLANK|SEP/", $proses[$i])) || 
                            (isset($proses_join[$i]) && preg_match("/TRIM|PIE|BLANK|SEP/", $proses_join[$i]))
                        ) {
                            $prosesValue = "BLANK-PIE";
                        } else {
                            $prosesValue = "FORM-FLANGE";
                        }
                        
                    }
                }
                $category = isset($categoryData[$i]) ? $categoryData[$i] : '';
                $die_proses_standard_die[$i] = $category . "|" . $jenis_proses . "|" . $prosesValue;
                if (!empty($prosesValue) && !empty($jenis_proses) && !empty($category)) {
                    $queryStandard = $db->query("
                        SELECT die_length, die_width, die_height
                        FROM standard_die_design 
                        WHERE proses = ? AND jenis_proses = ? AND category = ?",  
                        [$prosesValue, $jenis_proses, $category]
                    );
                    $row = $queryStandard->getRow();
                    $dieLengthStandard[$i] = isset($row->die_length) ? $row->die_length : '';
                    $dieWidthStandard[$i]  = isset($row->die_width) ? $row->die_width : '';
                    $dieHeightStandard[$i] = isset($row->die_height) ? $row->die_height : '';
                } else {
                    $dieLengthStandard[$i] = '';
                    $dieWidthStandard[$i]  = '';
                    $dieHeightStandard[$i] = '';
                }
            }
     
            return $this->response->setStatusCode(200)->setJSON([
                'success'                 => true,
                'data'                    => $result,
                'machine_data'            => $machineData,
                'die_length_standard'     => $dieLengthStandard,
                'die_width_standard'      => $dieWidthStandard,
                'die_height_standard'     => $dieHeightStandard,
                'die_proses_standard_die' => $die_proses_standard_die,
                'jenis_proses'            => $jenis_proses,
                'prosesValue'             => $prosesValue,
                'categoryData'            => $category,
                'tes'                     => $proses[0],
                'csrfHash'                => csrf_hash()
            ]);
        } else {
            $result = [];
            $machineData = [];
            $dieLengthStandard = [];
            $dieWidthStandard  = [];
            $dieHeightStandard = [];
            $die_proses_standard_die = [];
            $jenis_proses = null;
            $prosesValue = null;
            $category = [];
            
            // Generate data kosong untuk semua baris
            for ($i = 0; $i < $dieCount; $i++) {
                $result['machine' . ($i + 1)] = null;
                $result['capacity' . ($i + 1)] = null;
                $result['cushion' . ($i + 1)] = null;
                $result['dh_dies' . ($i + 1)] = null;
                $machineData[] = null;
                $dieLengthStandard[$i] = null;
                $dieWidthStandard[$i] = null;
                $dieHeightStandard[$i] = null;
                $die_proses_standard_die[$i] = null;
                $category[] = null;
            }
            
            return $this->response->setStatusCode(200)->setJSON([
                'success'                 => true, // Pastikan success tetap true
                'data'                    => $result,
                'machine_data'            => $machineData,
                'die_length_standard'     => $dieLengthStandard,
                'die_width_standard'      => $dieWidthStandard,
                'die_height_standard'     => $dieHeightStandard,
                'die_proses_standard_die' => $die_proses_standard_die,
                'jenis_proses'            => $jenis_proses,
                'prosesValue'             => $prosesValue,
                'categoryData'            => $category,
                'tes'                     => $proses[0] ?? '',
                'csrfHash'                => csrf_hash()
            ]);

        
        }
    }
    
    public function fetchStandard()
    {
        $db = \Config\Database::connect();
        $standard = $this->request->getPost('standard');
    
        if (empty($standard)) {
            return $this->response
                        ->setStatusCode(400)
                        ->setJSON([
                            'error'    => 'Parameter standard tidak boleh kosong.',
                            'csrfHash' => csrf_hash()
                        ]);
        }
        $category     = null;
        $jenis_proses = null;
        $prosesValue  = null;
        $parts = explode("|", $standard);
        if (count($parts) == 3) {
            $category     = trim($parts[0]);
            $jenis_proses = trim($parts[1]);
            $prosesValue  = trim($parts[2]);
        } else {
            $category = $jenis_proses = $prosesValue = '';
        }
        
        if (!empty($prosesValue)) {
            $queryStandard = $db->query("
                SELECT die_length, die_width, die_height
                FROM standard_die_design 
                WHERE proses = ? AND jenis_proses = ? AND category = ?",  
                [$prosesValue, $jenis_proses, $category]
            );
            
            if ($queryStandard->getNumRows() > 0) {
                $row = $queryStandard->getRow();
                return $this->response
                            ->setStatusCode(200)
                            ->setJSON([
                                'success'  => true,
                                'data'     => $row,
                                'csrfHash' => csrf_hash()
                            ]);
            } else {
                return $this->response
                            ->setStatusCode(404)
                            ->setJSON([
                                'error'    => 'Data standar die design tidak ditemukan untuk standard: ' . $standard,
                                'csrfHash' => csrf_hash()
                            ]);
            }
        } else {
            return $this->response
                        ->setStatusCode(404)
                        ->setJSON([
                            'error'    => 'Data tidak ditemukan untuk standard: ' . $category,
                            'csrfHash' => csrf_hash()
                        ]);
        }
    }
    
    

    public function fetchMachineByMachine()
    {
        $db = \Config\Database::connect();
        $machine = $this->request->getPost('machine');

        if (empty($machine)) {
            return $this->response
                        ->setStatusCode(400)
                        ->setJSON([
                            'error'    => 'Parameter machine tidak boleh kosong.',
                            'csrfHash' => csrf_hash()
                        ]);
        }

        $builder = $db->table('master_table');
        $builder->select('capacity, cushion', 'dh_dies');
        $builder->where('machine', $machine);
        $query = $builder->get();

        if ($query && $query->getNumRows() > 0) {
            $result = $query->getRowArray();
            $machineData = null;
            $dh_dies = null;
                    $queryMachine = $db->query("
                        SELECT 
                            machine,
                            bolster_length,
                            bolster_width,
                            slide_area_length,
                            slide_area_width,
                            die_height,
                            cushion_pad_length,
                            cushion_pad_width,
                            cushion_stroke
                        FROM mc_spec 
                        WHERE machine = ?",  $machine);
                    $machineData = $queryMachine->getRowArray();
             
                    $queryMachine = $db->query("
                    SELECT 
                        dh_dies
                    FROM master_table 
                    WHERE machine = ?",  $machine);
                $dh_dies = $queryMachine->getRowArray();
         
    
            return $this->response
                        ->setStatusCode(200)
                        ->setJSON([
                            'success'      => true,
                            'data'         => $result,
                            'dh_dies'         => $dh_dies,
                            'machine_data' => $machineData,
                            'csrfHash'     => csrf_hash()
                        ]);

        } else {
            return $this->response
                        ->setStatusCode(404)
                        ->setJSON([
                            'error'    => 'Data tidak ditemukan untuk machine: ' . $machine,
                            'csrfHash' => csrf_hash()
                        ]);
        }
    }
    
    // public function submitPrint()
    // {
    //     $db = \Config\Database::connect();

    //         $templatePath = FCPATH . 'uploads/template/templatePPS.xlsx';

    //         if (!file_exists($templatePath)) {
    //             return redirect()->back()->with('error', 'Template Excel tidak ditemukan.');
    //         }

    //     $spreadsheet = IOFactory::load($templatePath);
    //     $sheet = $spreadsheet->getActiveSheet();
    //     $uploadPath = FCPATH . 'uploads/pps/';
    //     if (!is_dir($uploadPath)) {
    //         mkdir($uploadPath, 0777, true);
    //     }
        
    //     $clayoutFiles = $this->request->getFileMultiple("c_layout");
    //     $dcFiles = $this->request->getFileMultiple("die_construction_img");
    //     $BlayoutImg = $this->request->getFile("blank_layout_img");

    //     if ($BlayoutImg && $BlayoutImg->isValid() && !$BlayoutImg->hasMoved()) {
    //         $BlayoutImgNew = "blank_layout_" . time() . "." . $BlayoutImg->getExtension();
    //         $BlayoutImg->move($uploadPath, $BlayoutImgNew); 
        
    //         $drawing = new Drawing();
    //         $drawing->setName('Blank Layout Image');
    //         $drawing->setDescription('Blank Layout Image');
    //         $drawing->setPath($uploadPath . $BlayoutImgNew);
    //         $drawing->setOffsetX(10);
    //         $drawing->setOffsetY(10); 
    //         $drawing->setResizeProportional(true);
    //         $drawing->setWidth(100); 
    //         $drawing->setHeight(100); 
    //         $drawing->setCoordinates('CP4'); 
    //         $drawing->setWorksheet($sheet);
    //     }
    
    //     $processLayout = $this->request->getFile("process_layout_img");

    //     if ($processLayout && $processLayout->isValid() && !$processLayout->hasMoved()) {
    //         $processLayoutNew = "blank_layout_" . time() . "." . $processLayout->getExtension();
    //         $processLayout->move($uploadPath, $processLayoutNew);
        
    //         $drawing = new Drawing();
    //         $drawing->setName('Blank Layout Image');
    //         $drawing->setDescription('Blank Layout Image');
    //         $drawing->setPath($uploadPath . $processLayoutNew);
    //         $drawing->setOffsetX(10); 
    //         $drawing->setOffsetY(10); 
    //         $drawing->setResizeProportional(true);
    //         $drawing->setWidth(100); 
    //         $drawing->setHeight(100); 
      
    //         $drawing->setCoordinates('CI16'); 
    //         $drawing->setWorksheet($sheet);
    //     }
    

    //         $sheet->setCellValue('C6', $this->request->getPost('cust'));
    //         $sheet->setCellValue('P6', $this->request->getPost('model'));
    
    //         $today = date('d-m-Y');
    //         $sheet->setCellValue('AQ6',  $this->request->getPost('receive'));
    
    //         $sheet->setCellValue('CG5', $this->request->getPost('total_dies'));
    //         $sheet->setCellValue('CG7', $this->request->getPost('total_mp'));
    //         $sheet->setCellValue('CG9', $this->request->getPost('total_stroke'));
    //         $sheet->setCellValue('CG11', $this->request->getPost('doc_level'));
        
    //         $length = (float) $this->request->getPost('length');
    //         $width = (float) $this->request->getPost('width');
    //         $boq = (float) $this->request->getPost('boq');
    //         $partNo = "Part No :\n" . $this->request->getPost('part_no');
    //         $sheet->setCellValue('CG73', $partNo);
    //         $sheet->getStyle('CG73')->getFont()->setBold(true); 
    //         $sheet->getStyle('CG73')->getAlignment()->setWrapText(true); 

    //         $partName = "Part Name :\n" . $this->request->getPost('part_name');
    //         $sheet->setCellValue('CU73', $partName);
    //         $sheet->getStyle('CU73')->getFont()->setBold(true); 
    //         $sheet->getStyle('CU73')->getAlignment()->setWrapText(true); 

    //         $sheet->setCellValue('CI70', $length);
    //         $sheet->setCellValue('CI71', $width);
    //         $sheet->setCellValue('CI72', $boq);
    //         $sheet->setCellValue('CO71',$this->request->getPost('blank'));
    //         $sheet->setCellValue('DB71',  $this->request->getPost('scrap'));
    //         $sheet->setCellValue('CU71',$this->request->getPost('panel'));
        
    //         $sheet->setCellValue('CO66', $this->request->getPost('cf') . " Unit");

    //         $sheet->setCellValue('CS68', $this->request->getPost('material'));
    //         $session = session(); 
    //         $sheet->setCellValue('DB79', $session->get('nickname'));
            
    //         $opCells      = ['C9',  'C21', 'C33', 'C45', 'C57', 'C70'];
    //         $processCells = ['C12', 'C24', 'C36', 'C48', 'C60', 'C73'];
    //         $procCells    = ['C15', 'C27', 'C39', 'C51', 'C63', 'C76'];
    //         $prosesCells  = ['C18', 'C30', 'C42', 'C54', 'C66', 'C79'];
          
    //         $cgOpProcessCells = ['CG48', 'CG51', 'CG54', 'CG57', 'CG60', 'CG63', ];
    //         $cgProcessCells = ['CG49', 'CG52', 'CG55', 'CG58', 'CG61', 'CG64'];
         
            
        
    //         $totalDies = min(6, (int) $this->request->getPost('total_dies'));
    //         $processArray = $this->request->getPost('process') ?? [];
    //         $prosesArray  = $this->request->getPost('proses') ?? [];

    //         $upperCells      = ['AY18', 'AY30', 'AY42', 'AY54', 'AY67', 'AY80'];
    //         $lowerCells      = ['AY19', 'AY31', 'AY43', 'AY55', 'AY68', 'AY81'];
    //         $padCells        = ['AY20', 'AY33', 'AY45', 'AY57', 'AY70', 'AY83'];
    //         $slidingCells    = ['BJ18', 'BJ30', 'BJ42', 'BJ54', 'BJ67', 'BJ80'];
    //         $guideCells      = ['BJ19', 'BJ31', 'BJ43', 'BJ55', 'BJ68', 'BJ81'];
    //         $padLifterCells  = ['BM19', 'BM32', 'BM44', 'BM56', 'BM69', 'BM82'];
    //         $insertCells     = ['BX18', 'BX30', 'BX42', 'BX54', 'BX67', 'BX80'];
            
    //         $upperTextCells      = ['AU18', 'AU30', 'AU42', 'AU54', 'AU67', 'AU80'];
    //         $lowerTextCells      = ['AU19', 'AU31', 'AU43', 'AU55', 'AU68', 'AU81'];
    //         $padTextCells       = ['AU20', 'AU32', 'AU44', 'AU56', 'AU69', 'AU82'];
    //         $slidingTextCells    = ['BE18', 'BE30', 'BE42', 'BE54', 'BE67', 'BE80'];
    //         $guideTextCells      = ['BE19', 'BE31', 'BE43', 'BE55', 'BE68', 'BE81'];
    //         $padLifterTextCells  = ['BE20', 'BE32', 'BE44', 'BE56', 'BE69', 'BE82'];
    //         $insertTextCells     = ['BT18', 'BT30', 'BT42', 'BT54', 'BT67', 'BT80'];
    //         $dieLengthCells = [];
    //         for ($i = 48; $i <= 63; $i += 3) {
    //             $dieLengthCells[] = 'CW' . $i;
    //         }

    //         $dieWeightCells = [];
    //         for ($i = 49; $i <= 64; $i += 3) {
    //             $dieWeightCells[] = 'CW' . $i;
    //         }

    //         $dieHeightCells = [];
    //         for ($i = 50; $i <= 65; $i += 3) {
    //             $dieHeightCells[] = 'CW' . $i;
    //         }

    //         $qtyDiesProcessCells = ['CL48', 'CL51', 'CL54', 'CL57', 'CL60', 'CL63'];
    //         $dieCushionCells = [];
    //         for ($i = 50; $i <= 65; $i += 3) {
    //             $dieCushionCells[] = 'CO' . $i;
    //         }
    //         $mcCells =  [];
    //         for ($i = 48; $i <= 63; $i += 3) {
    //             $mcCells[] = 'CO' . $i;
    //         }
    //     // Ambil data dari form, pastikan datanya berupa array atau default ke array kosong
    //     $bolsterLengthArr    = is_array($this->request->getPost('bolster_length'))    ? $this->request->getPost('bolster_length')    : [];
    //     $bolsterWeightArr    = is_array($this->request->getPost('bolster_width'))    ? $this->request->getPost('bolster_width')    : [];
    //     $slideAreaLengthArr  = is_array($this->request->getPost('slide_area_length'))  ? $this->request->getPost('slide_area_length')  : [];
    //     $slideAreaWeightArr  = is_array($this->request->getPost('slide_area_width'))  ? $this->request->getPost('slide_area_width')  : [];
    //     $dieHeightMaxArr     = is_array($this->request->getPost('die_height'))         ? $this->request->getPost('die_height')         : [];
    //     $cushionPadLengthArr = is_array($this->request->getPost('cushion_pad_length')) ? $this->request->getPost('cushion_pad_length') : [];
    //     $cushionPadWeightArr = is_array($this->request->getPost('cushion_pad_width')) ? $this->request->getPost('cushion_pad_width') : [];
    //     $cushionStrokeArr    = is_array($this->request->getPost('cushion_stroke'))     ? $this->request->getPost('cushion_stroke')     : [];
    //     $machineSpec         = is_array($this->request->getPost('machine'))            ? $this->request->getPost('machine')            : [];

    //     // Daftar kolom target yang ingin diisi data
    //     $targetColumns = ["CQ", "CU", "CZ", "DE"];
    //     $j = 0; // indeks untuk targetColumns

    //     // Pastikan $totalDies sudah didefinisikan, misal jumlah elemen di salah satu array
    //     $totalDies = count($bolsterLengthArr);

    //     for ($i = 0; $i < $totalDies; $i++) {
    //         $column = $targetColumns[$j] ?? end($targetColumns);
            
    //         // Cek apakah ada baris selanjutnya untuk dibandingkan
    //         if (
    //             ($i < $totalDies - 1) &&
    //             ($bolsterLengthArr[$i]    ?? '') == ($bolsterLengthArr[$i+1]    ?? '') &&
    //             ($bolsterWeightArr[$i]    ?? '') == ($bolsterWeightArr[$i+1]    ?? '') &&
    //             ($slideAreaLengthArr[$i]  ?? '') == ($slideAreaLengthArr[$i+1]  ?? '') &&
    //             ($slideAreaWeightArr[$i]  ?? '') == ($slideAreaWeightArr[$i+1]  ?? '') &&
    //             ($dieHeightMaxArr[$i]     ?? '') == ($dieHeightMaxArr[$i+1]     ?? '') &&
    //             ($cushionPadLengthArr[$i] ?? '') == ($cushionPadLengthArr[$i+1] ?? '') &&
    //             ($cushionPadWeightArr[$i] ?? '') == ($cushionPadWeightArr[$i+1] ?? '') &&
    //             ($cushionStrokeArr[$i]    ?? '') == ($cushionStrokeArr[$i+1]    ?? '')
    //         ) {
    //             // Jika data baris ke-i dan ke-(i+1) identik, gabungkan machineSpec
    //             $mergedMachine = ($machineSpec[$i] ?? '') . ', ' . ($machineSpec[$i+1] ?? '');
                
    //             $sheet->setCellValue("{$column}34", $mergedMachine);
    //             $sheet->setCellValue("{$column}35", $bolsterLengthArr[$i]    ?? '');
    //             $sheet->setCellValue("{$column}36", $bolsterWeightArr[$i]    ?? '');
    //             $sheet->setCellValue("{$column}37", $slideAreaLengthArr[$i]  ?? '');
    //             $sheet->setCellValue("{$column}38", $slideAreaWeightArr[$i]  ?? '');
    //             $sheet->setCellValue("{$column}39", $dieHeightMaxArr[$i]     ?? '');
    //             $sheet->setCellValue("{$column}40", $cushionPadLengthArr[$i] ?? '');
    //             $sheet->setCellValue("{$column}41", $cushionPadWeightArr[$i] ?? '');
    //             $sheet->setCellValue("{$column}42", $cushionStrokeArr[$i]    ?? '');
                
    //             // Lewati baris berikutnya karena sudah digabung
    //             $i++; 
    //             $j++;
    //         } else {
    //             // Jika tidak ada pasangan (atau baris berikutnya berbeda), tuliskan data baris ke-i secara individual
    //             $sheet->setCellValue("{$column}34", $machineSpec[$i]         ?? '');
    //             $sheet->setCellValue("{$column}35", $bolsterLengthArr[$i]    ?? '');
    //             $sheet->setCellValue("{$column}36", $bolsterWeightArr[$i]    ?? '');
    //             $sheet->setCellValue("{$column}37", $slideAreaLengthArr[$i]  ?? '');
    //             $sheet->setCellValue("{$column}38", $slideAreaWeightArr[$i]  ?? '');
    //             $sheet->setCellValue("{$column}39", $dieHeightMaxArr[$i]     ?? '');
    //             $sheet->setCellValue("{$column}40", $cushionPadLengthArr[$i] ?? '');
    //             $sheet->setCellValue("{$column}41", $cushionPadWeightArr[$i] ?? '');
    //             $sheet->setCellValue("{$column}42", $cushionStrokeArr[$i]    ?? '');
    //             $j++;
    //         }
    //     }




    //         $capacityCells =  [];
    //         for ($i = 49; $i <= 64; $i += 3) {
    //             $capacityCells[] = 'CO' . $i;
    //         }
    //         $ClayoutImageCells = ['H9', 'H21', 'H33', 'H45', 'H57', 'H70'];
    //         $DcLayoutCells = ['AT9', 'AT21', 'AT33', 'AT45', 'AT57', 'AT70'];
    //         $upperArr      = $this->request->getPost('upper') ?? [];
    //         $lowerArr      = $this->request->getPost('lower') ?? [];
    //         $padArr        = $this->request->getPost('pad') ?? [];
    //         $slidingArr    = $this->request->getPost('sliding') ?? [];
    //         $guideArr      = $this->request->getPost('guide') ?? [];
    //         $padLifterArr  = $this->request->getPost('pad_lifter') ?? [];
    //         $insertArr     = $this->request->getPost('insert') ?? [];

    //         $machines   = $this->request->getPost('machine') ?? [];
    //         $capacities = $this->request->getPost('capacity') ?? [];
    //         $cushions   = $this->request->getPost('cushion') ?? [];
    //         $maxWidth = 300;
    //         $maxHeight = 400;
    //         $padding = 10;

    //         for ($i = 0; $i < $totalDies; $i++) {
    //             $sheet->setCellValue($processCells[$i], $processArray[$i] ?? '');
    //             $sheet->setCellValue($prosesCells[$i], $prosesArray[$i] ?? '');
    //             $sheet->setCellValue($opCells[$i], 'OP');
    //             if (isset($qtyDiesProcessCells[$i])) {
    //                 $sheet->setCellValue($qtyDiesProcessCells[$i], 1);
    //             }

    //             if (isset($procCells[$i])) {
    //                 $sheet->setCellValue($procCells[$i], 'PROC.');
    //             }
    
    //             $sheet->setCellValue($cgOpProcessCells[$i], $processArray[$i] ?? '');
    //             $sheet->setCellValue(
    //                 $cgOpProcessCells[$i] ?? '', 
    //                 'OP ' . ($processArray[$i] ?? '')
    //             );
                
    //             $sheet->setCellValue($cgProcessCells[$i],  ($prosesArray[$i] ?? ''));
                
              
    //             $sheet->setCellValue($mcCells[$i], $machines[$i]); 
        
        
    //             $sheet->setCellValue($dieCushionCells[$i], $cushions[$i]); 
            
    //             $sheet->setCellValue($capacityCells[$i], $capacities[$i]); 
             
             
    //             if (isset($upperCells[$i])) {
    //                 $sheet->setCellValue($upperCells[$i], $upperArr[$i] ?? '');
    //             }
        
    //             if (isset($lowerCells[$i])) {
    //                 $sheet->setCellValue($lowerCells[$i], $lowerArr[$i] ?? '');
    //             }
            
    //             if (isset($padCells[$i])) {
    //                 $sheet->setCellValue($padCells[$i], $padArr[$i] ?? '');
    //             }
            
    //             if (isset($slidingCells[$i])) {
    //                 $sheet->setCellValue($slidingCells[$i], $slidingArr[$i] ?? '');
    //             }
            
    //             if (isset($guideCells[$i])) {
    //                 $sheet->setCellValue($guideCells[$i], $guideArr[$i] ?? '');
    //             }
            
    //             if (isset($padLifterCells[$i])) {
    //                 $sheet->setCellValue($padLifterCells[$i], $padLifterArr[$i] ?? '');
    //             }
            
    //             if (isset($insertCells[$i])) {
    //                 $sheet->setCellValue($insertCells[$i], $insertArr[$i] ?? '');
    //             }

    //             if (isset($upperTextCells[$i])) {
    //                 $sheet->setCellValue($upperTextCells[$i], 'UPPER');
    //             }
            
    //             if (isset($lowerTextCells[$i])) {
    //                 $sheet->setCellValue($lowerTextCells[$i], 'LOWER');
    //             }
            
    //             if (isset($padTextCells[$i])) {
    //                 $sheet->setCellValue($padTextCells[$i], 'PAD');
    //             }
            
    //             if (isset($slidingTextCells[$i])) {
    //                 $sheet->setCellValue($slidingTextCells[$i], 'SLIDING');
    //             }
            
    //             if (isset($guideTextCells[$i])) {
    //                 $sheet->setCellValue($guideTextCells[$i], 'GUIDE');
    //             }
            
    //             if (isset($padLifterTextCells[$i])) {
    //                 $sheet->setCellValue($padLifterTextCells[$i], 'PAD LIFTER');
    //             }
            
    //             if (isset($insertTextCells[$i])) {
    //                 $sheet->setCellValue($insertTextCells[$i], 'INSERT');
    //             }
    //             if (isset($clayoutFiles[$i]) && $clayoutFiles[$i]->isValid() && !$clayoutFiles[$i]->hasMoved()) {
    //                 // Generate nama file baru dengan timestamp dan indeks
    //                 $clayoutNewName = "clayout_" . time() . "_" . $i . "." . $clayoutFiles[$i]->getExtension();
                    
    //                 // Pindahkan file ke direktori upload
    //                 $clayoutFiles[$i]->move($uploadPath, $clayoutNewName);
                    
    //                 // Buat objek Drawing untuk menyisipkan gambar
    //                 $drawing = new Drawing();
    //                 $drawing->setName('Clayout Image');
    //                 $drawing->setDescription('Clayout Image');
    //                 $drawing->setPath($uploadPath . $clayoutNewName);
    //                 $drawing->setOffsetX(10); 
    //                 $drawing->setOffsetY(10); 
                    
    //                 // Set ukuran gambar secara proporsional
    //                 $drawing->setResizeProportional(true);
    //                 $drawing->setWidth(400);  // Set lebar gambar (tinggi akan disesuaikan secara proporsional)
                    
    //                 // Pastikan $ClayoutImageCells[$i] berisi koordinat yang valid, misalnya "H9", "H21", dll.
    //                 if (isset($ClayoutImageCells[$i])) {
    //                     $drawing->setCoordinates($ClayoutImageCells[$i]);
    //                 } else {
    //                     // Jika tidak ada koordinat yang valid, tampilkan pesan atau lakukan tindakan lainnya
    //                     echo "Koordinat gambar tidak valid untuk indeks $i.";
    //                 }
                    
    //                 // Tentukan worksheet untuk menyisipkan gambar
    //                 $drawing->setWorksheet($sheet);
    //             }
                
    //            if (isset($dcFiles[$i]) && $dcFiles[$i]->isValid() && !$dcFiles[$i]->hasMoved()) {
    //                 $dcNewName = "die_construction_" . time() . "_" . $i . "." . $dcFiles[$i]->getExtension();
    //                 $dcFiles[$i]->move($uploadPath, $dcNewName);
            
    //                 $drawing = new Drawing();
    //                 $drawing->setName('Die Construction Image');
    //                 $drawing->setDescription('Die Construction Image');
    //                 $drawing->setPath($uploadPath . $dcNewName);
    //                 $drawing->setOffsetX($padding);
    //                 $drawing->setOffsetY($padding); 
    //                 $drawing->setResizeProportional(true);
    //                 $drawing->setWidth($maxWidth);
    //                 $drawing->setHeight($maxHeight);
    //                 $drawing->setCoordinates($DcLayoutCells[$i]);
    //                 $drawing->setWorksheet($sheet);
    //             }
                
    //         }
    
    //         $cuCells = [];
    //         $dieSizeCell = [];
    //         for ($i = 48; $i <= 65; $i++) {
    //             $cuCells[] = "CU{$i}";
    //             $dieSizeCell[] = "CW{$i}";
    //         }
            
    //         $diesWeightCells = [];
    //         for ($i = 48; $i <= 63; $i += 3) {
    //             $diesWeightCells[] = "DB{$i}";
    //         }
            
    //         $mainPressCells = ['DB50', 'DB53', 'DB56', 'DB59', 'DB62', 'DB65'];
    //         $dieLengthArray = $this->request->getPost('die_length') ?? [];
    //         $dieWidthArray  = $this->request->getPost('die_width') ?? [];
           
    //         $dieHeightArray = $this->request->getPost('die_height') ?? [];
    //         $dieWeightArray = $this->request->getPost('die_weight') ?? [];
    //         $mainPressureArray = $this->request->getPost('main_pressure') ?? [];
    //         $prosesDieStandardArray  = $this->request->getPost('proses_standard_die') ?? [];
            
    //         $class = []; 
    //         $dieLenghtStandard = [];
    //         $dieWidthStandard = [];
      
    //         $values = ['L', 'W', 'H'];
    //         $totalDies = count($dieHeightArray); 
            
    //         for ($j = 0; $j < $totalDies; $j++) {
    //             for ($i = 0; $i < 3; $i++) {
    //                 if (isset($cuCells[$i + ($j * 3)])) {
    //                     $sheet->setCellValue($cuCells[$i + ($j * 3)], $values[$i]);
    //                 }
            
    //                 if (isset($dieSizeCell[$i + ($j * 3)])) {
    //                     $value = '';
    //                     if ($i == 0 && isset($dieLengthArray[$j])) {
    //                         $value = $dieLengthArray[$j]; 
    //                     } elseif ($i == 1 && isset($dieWeightArray[$j])) {
    //                         $value = $dieWeightArray[$j]; 
    //                     } elseif ($i == 2 && isset($dieHeightArray[$j])) {
    //                         $value = $dieHeightArray[$j]; 
    //                     }
    //                     $sheet->setCellValue($dieSizeCell[$i + ($j * 3)], $value);
    //                 }
    //             }
            
            
    //             if (isset($diesWeightCells[$j]) && isset($dieWeightArray[$j])) {
    //                 $sheet->setCellValue($diesWeightCells[$j], $dieWeightArray[$j]);
    //             }
            
    //             if (isset($mainPressCells[$j]) && isset($mainPressureArray[$j])) {
    //                 $sheet->setCellValue($mainPressCells[$j], $mainPressureArray[$j]);
    //             }
    //             // if (isset($nullCells[$i])) {
    //             //     $sheet->setCellValue($nullCells[$i], '-');
    //             // }
            
    //             // Mengisi mcCells dengan nilai dari dropdown machine[]
    //             // if (isset($mcCells[$i])) {
    //             //     $sheet->setCellValue($mcCells[$i], $_POST['machine'][$i] ?? '');
    //             // }
            
    //             // // Mengisi capacityCells dengan nilai dari input capacity[]
    //             // if (isset($capacityCells[$i])) {
    //             //     $sheet->setCellValue($capacityCells[$i], $_POST['capacity'][$i] ?? '');
    //             // }

            
    //         }
          
        
    //         $newFilePath = WRITEPATH . 'uploads/generated_' . time() . '.xlsx';
    //         $writer = new Xlsx($spreadsheet);
    //         $writer->save($newFilePath);
    
    //         return $this->response->download($newFilePath, null)->setFileName('generated.xlsx');
    
    // }
    public function submit()
    {
        $validation = \Config\Services::validation();
        $session = session();
        
        // // Validasi input
        // $validation->setRules([
        //     'cust' => 'required',
        //     'model' => 'required',
        //     'total_dies' => 'required|numeric',
        // ]);

        $blankLayoutName = null;
        $processLayoutName = null;
        
       // === Blank Layout ===
        $blankLayoutFile = $this->request->getFile('blank_layout_img');
        $blankLayoutSelected = $this->request->getPost('blank_layout_selected');

        if ($blankLayoutFile && $blankLayoutFile->isValid()) {
            $blankLayoutName = $blankLayoutFile->getRandomName();
            $blankLayoutFile->move(ROOTPATH . 'public/uploads/blank_layout', $blankLayoutName);
        } elseif ($blankLayoutSelected) {
            // Ambil path relatif dari URL
            $parsedPath = parse_url($blankLayoutSelected, PHP_URL_PATH);
            $relativePath = str_replace('/uploads/', '', $parsedPath); // contoh: dcp/nama_file.png
            $sourcePath = ROOTPATH . 'public/uploads/' . $relativePath;

            if (file_exists($sourcePath)) {
                $blankLayoutName = uniqid() . '_' . basename($sourcePath);
                copy($sourcePath, ROOTPATH . 'public/uploads/blank_layout/' . $blankLayoutName);
            }
        }

        // === Process Layout ===
        $processLayoutFile = $this->request->getFile('process_layout_img');
        $processLayoutSelected = $this->request->getPost('process_layout_selected');

        if ($processLayoutFile && $processLayoutFile->isValid()) {
            $processLayoutName = $processLayoutFile->getRandomName();
            $processLayoutFile->move(ROOTPATH . 'public/uploads/process_layout', $processLayoutName);
        } elseif ($processLayoutSelected) {
            // Ambil path relatif dari URL
            $parsedPath = parse_url($processLayoutSelected, PHP_URL_PATH);
            $relativePath = str_replace('/uploads/', '', $parsedPath); // contoh: dcp/nama_file.png
            $sourcePath = ROOTPATH . 'public/uploads/' . $relativePath;

            if (file_exists($sourcePath)) {
                $processLayoutName = uniqid() . '_' . basename($sourcePath);
                copy($sourcePath, ROOTPATH . 'public/uploads/process_layout/' . $processLayoutName);
            }
        }


        $mainData = [
            'cust' => $this->request->getPost('cust'),
            'model' => $this->request->getPost('model'),
            'receive' => $this->request->getPost('receive'),
            'part_no' => $this->request->getPost('part_no'),
            'part_name' => $this->request->getPost('part_name'),
            'cf' => $this->request->getPost('cf'),
            'material' => $this->request->getPost('material'),
            'tonasi' => $this->request->getPost('tonasi'),
            'length' => $this->request->getPost('length'),
            'width' => $this->request->getPost('width'),
            'boq' => $this->request->getPost('boq'),
            'blank' => $this->request->getPost('blank'),
            'panel' => $this->request->getPost('panel'),
            'scrap' => $this->request->getPost('scrap'),
            'total_mp' => $this->request->getPost('total_mp'),
            'doc_level' => $this->request->getPost('doc_level'),
            'total_stroke' => $this->request->getPost('total_stroke'),
            'blank_layout' => $blankLayoutName,
            'process_layout' => $processLayoutName,
            'created_at' => date('Y-m-d')
        ];
    
            $ppsId = $this->ppsModel->insert($mainData);
        
            $processes = $this->request->getPost('process');
            $diesData = [];
            
            foreach ($processes as $index => $process) {
                $cLayoutFile = $this->request->getFileMultiple('c_layout')[$index] ?? null;
                $dieConstrFile = $this->request->getFileMultiple('die_construction_img')[$index] ?? null;
                
                $cLayoutName = null;
                $dieConstrName = null;
                if ($cLayoutFile && $cLayoutFile->isValid()) {
                    // Jika upload file
                    $cLayoutName = $cLayoutFile->getRandomName();
                    $cLayoutFile->move(ROOTPATH . 'public/uploads/c_layout', $cLayoutName);
                } else {
                    // Jika pilih dari gambar yang ada
                    $selectedClayout = $this->request->getPost('c_layout_selected')[$index] ?? null;
                    if ($selectedClayout) {
                        // Ambil path setelah domain, contoh: /uploads/dcp/nama_file.png
                        $parsedUrl = parse_url($selectedClayout, PHP_URL_PATH);
                
                        // Pastikan path dimulai dari '/uploads/', lalu ambil path relatifnya
                        $relativePath = str_replace('/uploads/', '', $parsedUrl);
                
                        // Bangun path lengkap ke file sumber
                        $fullSourcePath = ROOTPATH . 'public/uploads/' . $relativePath;
                
                        if (file_exists($fullSourcePath)) {
                            // Generate nama baru agar tidak bentrok
                            $cLayoutName = uniqid() . '_' . basename($fullSourcePath);
                            $destinationPath = ROOTPATH . 'public/uploads/c_layout/' . $cLayoutName;
                
                            // Salin file
                            copy($fullSourcePath, $destinationPath);
                        }
                    }
                }
                
            
                // ==== HANDLE DIE CONSTRUCTION ====
                if ($dieConstrFile && $dieConstrFile->isValid()) {
                    $dieConstrName = $dieConstrFile->getRandomName();
                    $dieConstrFile->move(ROOTPATH . 'public/uploads/die_construction', $dieConstrName);
                } else {
                    $selectedDieConstr = $this->request->getPost('die_cons_selected')[$index] ?? null;
                    if ($selectedDieConstr) {
                        $originalPath = parse_url($selectedDieConstr, PHP_URL_PATH);
                        $fullSourcePath = ROOTPATH . 'public' . $originalPath;
            
                        if (file_exists($fullSourcePath)) {
                            $dieConstrName = uniqid() . '_' . basename($fullSourcePath);
                            $destinationPath = ROOTPATH . 'public/uploads/die_construction/' . $dieConstrName;
                            copy($fullSourcePath, $destinationPath);
                        }
                    }
                }
                $weight =   $this->request->getPost('die_weight')[$index];
                $class = null;
                if ($weight > 6971) {
                    $class = "A";
                } else if ($weight > 3914 && $weight <= 6971) {
                    $class = "B";
                } else if ($weight > 1961 && $weight <= 3914) {
                    $class = "C";
                } else if ($weight > 848 && $weight <= 1961) {
                    $class = "D";
                } else if ($weight > 397 && $weight <= 848) {
                    $class = "E";
                } else if ($weight > 0 && $weight <= 397) {
                    $class = "F";
                }

                $diesData[] = [
                    'pps_id' => $ppsId,
                    'process' => $process,
                    'process_join' => $this->request->getPost('process_join')[$index],
                    'proses' => $this->request->getPost('proses')[$index],
                    'length_mp' => $this->request->getPost('length_mp')[$index],
                    'main_pressure' => $this->request->getPost('main_pressure')[$index],
                    'machine' => $this->request->getPost('machine')[$index],
                    'capacity' => $this->request->getPost('capacity')[$index],
                    'cushion' => $this->request->getPost('cushion')[$index],
                    'die_length' => $this->request->getPost('die_length')[$index],
                    'die_width' => $this->request->getPost('die_width')[$index],
                    'die_height' => $this->request->getPost('die_height')[$index],
                    'casting_plate' => $this->request->getPost('casting_plate')[$index],
                    'die_weight' => $this->request->getPost('die_weight')[$index],
                    'upper' => $this->request->getPost('upper')[$index],
                    'lower' => $this->request->getPost('lower')[$index],
                    'pad' => $this->request->getPost('pad')[$index],
                    'pad_lifter' => $this->request->getPost('pad_lifter')[$index],
                    'sliding' => $this->request->getPost('sliding')[$index],
                    'guide' => $this->request->getPost('guide')[$index],
                    'insert' => $this->request->getPost('insert')[$index],
                    'heat_treatment' => $this->request->getPost('heat_treatment')[$index],
                    'panjang' => $this->request->getPost('panjang')[$index],
                    'lebar' => $this->request->getPost('lebar')[$index],
                    'clayout_img' => $cLayoutName,
                    'die_construction_img' => $dieConstrName,
                    'class' => $class,
                ];
            }

            $this->ppsDiesModel->insertBatch($diesData);

            $session->setFlashdata('success', 'Data berhasil disimpan');
            return redirect()->to('/pps');

      
    }
    public function edit($id)
    {
        $ppsModel = new PpsModel();
        $ppsDiesModel = new PpsDiesModel();
    
        $machineOptions = [];
        $letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
        foreach ($letters as $letter) {
            
            for ($i = 1; $i <= 4; $i++) {
                $machineOptions[] = $letter . $i;
            }
        }
        $machineOptions = array_merge($machineOptions, ['MP', 'SP1', 'SP2', 'SP3']);
    
        $pps = $ppsModel->find($id);
        if (!$pps) {
            return redirect()->to('/pps')->with('error', 'Data tidak ditemukan');
        }

        $dies = $ppsDiesModel->where('pps_id', $id)->findAll();
  
        $data = [
            'pps'            => $pps,
            'dies'           => $dies,
            'machineOptions' => $machineOptions,
        ];
        return view('pps/edit', $data);
    }

    public function update()
    {
        $ppsModel = new PpsModel();
        $ppsDiesModel = new PpsDiesModel();
    
        $id = $this->request->getPost('id');
        $oldData = $ppsModel->where('id', $id)->first();
   
        $dataPps = [
            'cust'         => $this->request->getPost('cust'),
            'model'        => $this->request->getPost('model'),
            'receive'      => $this->request->getPost('receive'),
            'part_no'      => $this->request->getPost('part_no'),
            'part_name'    => $this->request->getPost('part_name'),
            'cf'           => $this->request->getPost('cf'),
            'material'     => $this->request->getPost('material'),
            'tonasi'       => $this->request->getPost('tonasi'),
            'length'       => $this->request->getPost('length'),
            'width'        => $this->request->getPost('width'),
            'boq'          => $this->request->getPost('boq'),
            'blank'        => $this->request->getPost('blank'),
            'panel'        => $this->request->getPost('panel'),
            'scrap'        => $this->request->getPost('scrap'),
            'total_mp'     => $this->request->getPost('total_mp'),
            'doc_level'    => $this->request->getPost('doc_level'),
            'total_stroke' => $this->request->getPost('total_stroke'),
            'process_layout' => $this->request->getPost('process_layout'),
            'blank_layout'   => $this->request->getPost('blank_layout'),
            'created_by'   => session()->get('user_id')
        ];
        $uploadPath = FCPATH . 'uploads/pps/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }

        // Update Blank Layout
        $blankLayout = $this->request->getFile('blank_layout');
        if ($blankLayout && $blankLayout->isValid() && !$blankLayout->hasMoved()) {
            if (!empty($oldData['blank_layout'])) {
                @unlink($uploadPath . $oldData['blank_layout']);
            }
            $blankLayoutName = "blank_layout_" . time() . "." . $blankLayout->getExtension();
            $blankLayout->move($uploadPath, $blankLayoutName);
            $dataPps['blank_layout'] = $blankLayoutName;
        } else {
            // Jika tidak ada file baru, gunakan nilai file lama dari hidden input
            $dataPps['blank_layout'] = $this->request->getPost('old_blank_layout');
        }
        
        // Update Process Layout
        $processLayout = $this->request->getFile('process_layout');
        if ($processLayout && $processLayout->isValid() && !$processLayout->hasMoved()) {
            if (!empty($oldData['process_layout'])) {
                @unlink($uploadPath . $oldData['process_layout']);
            }
            $processLayoutName = "process_layout_" . time() . "." . $processLayout->getExtension();
            $processLayout->move($uploadPath, $processLayoutName);
            $dataPps['process_layout'] = $processLayoutName;
        } else {
            $dataPps['process_layout'] = $this->request->getPost('old_process_layout');
        }
        
    
     
        $ppsModel->update($id, $dataPps);
    
        $ppsDiesModel->where('pps_id', $id)->delete();
    
        $dies = $this->request->getPost('dies');
    
        if (!empty($dies) && is_array($dies)) {
            foreach ($dies as $index => $die) {

                $class = null;
                $die_weight = $die['die_weight'] ?? null;
                if($die_weight > 6971) {
                    $class = "A";
                } else if($die_weight > 3914 && $die_weight <= 6971) {
                    $class = "B";
                } else if($die_weight > 3914 && $die_weight <= 6971) {
                    $class = "C";
                } else if($die_weight > 1961 && $die_weight <= 3914) {
                    $class = "D";
                } else if($die_weight > 848 && $die_weight <= 1961) {
                    $class = "E";
                } else if($die_weight <= 848) {
                    $class = "F";
                }

                 $dieData = [
                    'pps_id'            => $id,
                    'process'           => $die['process'] ?? null,
                    'process_join'      => $die['process_join'] ?? null,
                    'proses'            => $die['proses'] ?? null,
                    'proses_gang'            => $die['proses_gang'] ?? null,
                    'length_mp'         => $die['length_mp'] ?? null,
                    'main_pressure'     => $die['main_pressure'] ?? null,
                    'panjang'           => $die['panjang'] ?? null,
                    'lebar'           => $die['lebar'] ?? null,
                    'machine'           => $die['machine'] ?? null,
                    'capacity'          => $die['capacity'] ?? null,
                    'cushion'           => $die['cushion'] ?? null,
                    'die_length'        => $die['die_length'] ?? null,
                    'die_width'         => $die['die_width'] ?? null,
                    'die_height'        => $die['die_height'] ?? null,
                    'casting_plate'     => $die['casting_plate'] ?? null,
                    'die_weight'        => $die['die_weight'] ?? null,
                    'dc_process'        => $die['dc_process'] ?? null,
                    'dc_machine'        => $die['dc_machine'] ?? null,
                    'upper'             => $die['upper'] ?? null,
                    'lower'             => $die['lower'] ?? null,
                    'pad'               => $die['pad'] ?? null,
                    'pad_lifter'        => $die['pad_lifter'] ?? null,
                    'sliding'           => $die['sliding'] ?? null,
                    'guide'             => $die['guide'] ?? null,
                    'insert'            => $die['insert'] ?? null,
                    'heat_treatment'    => $die['heat_treatment'] ?? null,
                    'slide_stroke'      => $die['slide_stroke'] ?? null,
                    'cushion_stroke'    => $die['cushion_stroke'] ?? null,
                    'die_cushion_pad'   => $die['die_cushion_pad'] ?? null,
                    'bolster_length'    => $die['bolster_length'] ?? null,
                    'bolster_width'    => $die['bolster_width'] ?? null,
                    'slide_area_length' => $die['slide_area_length'] ?? null,
                    'slide_area_width' => $die['slide_area_width'] ?? null,
                    'cushion_pad_length'=> $die['cushion_pad_length'] ?? null,
                    'cushion_pad_width'=> $die['cushion_pad_width'] ?? null,
                    'class'             => $class,
                    'die_height_max'    => $die['die_height_max'] ?? null,
                    'panjang'=> $die['lebar'] ?? null,
                 
                ];
                $clayoutFile = $this->request->getFile("dies.{$index}.clayout_img");
                if ($clayoutFile && $clayoutFile->isValid() && !$clayoutFile->hasMoved()) {
                    // Jika ada file lama, hapus file tersebut
                    $oldClayout = $this->request->getPost("dies.{$index}.old_clayout_img");
                    if (!empty($oldClayout)) {
                        @unlink(WRITEPATH . 'uploads/pps/' . $oldClayout);
                    }
                    // Gunakan file yang diambil dari getFile, bukan array lain
                    $clayoutName = "clayout_" . time() . "_$index." . $clayoutFile->getExtension();
                    $clayoutFile->move($uploadPath, $clayoutName);
                    $dieData['clayout_img'] = $clayoutName;
                } else {
                    // Jika tidak ada file baru, gunakan file lama
                    $dieData['clayout_img'] = $this->request->getPost("dies.{$index}.old_clayout_img");
                }
                
                $dieConstructionFile = $this->request->getFile("dies.{$index}.die_construction_img");
                if ($dieConstructionFile && $dieConstructionFile->isValid() && !$dieConstructionFile->hasMoved()) {
                    $oldDieConstruction = $this->request->getPost("dies.{$index}.old_die_construction_img");
                    if (!empty($oldDieConstruction)) {
                        @unlink(WRITEPATH . 'uploads/pps/' . $oldDieConstruction);
                    }
                    $dieConstrName = "die_constr_" . time() . "_$index." . $dieConstructionFile->getExtension();
                    $dieConstructionFile->move($uploadPath, $dieConstrName);
                    $dieData['die_construction_img'] = $dieConstrName;
                   
                  
                } else {
                    $dieData['die_construction_img'] = $this->request->getPost("dies.{$index}.old_die_construction_img");
                }
                print_r($dieData['proses'] );   
              
                $ppsDiesModel->insert($dieData);
            }
        
        } 
        return redirect()->to(site_url('pps'))->with('success', 'Data berhasil diupdate');
    }
    
    public function submitAndDownload()
    {
        $db = \Config\Database::connect();
        $validation = \Config\Services::validation();
        $session = session();

        $validation->setRules([
            'cust' => 'required',
            'model' => 'required',
            'total_dies' => 'required|numeric',
            'part_no' => 'required',
            'part_name' => 'required',
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $uploadPath = FCPATH . 'uploads/pps/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }
        
        // === Blank Layout ===
        $BlayoutImg = $this->request->getFile("blank_layout_img");
        $blankLayoutSelected = $this->request->getPost("blank_layout_selected");
        $blankLayoutName = null;
        
        if ($BlayoutImg && $BlayoutImg->isValid() && !$BlayoutImg->hasMoved()) {
            $blankLayoutName = "blank_layout_" . time() . "." . $BlayoutImg->getExtension();
            $BlayoutImg->move($uploadPath, $blankLayoutName);
        } elseif ($blankLayoutSelected) {
            $parsedPath = parse_url($blankLayoutSelected, PHP_URL_PATH); // contoh: /uploads/dcp/nama_file.png
            $sourcePath = FCPATH . ltrim($parsedPath, '/'); // hilangkan '/' depan
        
            if (file_exists($sourcePath)) {
                $blankLayoutName = "blank_layout_" . time() . "_" . basename($sourcePath);
                copy($sourcePath, $uploadPath . $blankLayoutName);
            }
        }
        
        // === Process Layout ===
        $processLayout = $this->request->getFile("process_layout_img");
        $processLayoutSelected = $this->request->getPost("process_layout_selected");
        $processLayoutName = null;
        
        if ($processLayout && $processLayout->isValid() && !$processLayout->hasMoved()) {
            $processLayoutName = "process_layout_" . time() . "." . $processLayout->getExtension();
            $processLayout->move($uploadPath, $processLayoutName);
        } elseif ($processLayoutSelected) {
            $parsedPath = parse_url($processLayoutSelected, PHP_URL_PATH);
            $sourcePath = FCPATH . ltrim($parsedPath, '/');
        
            if (file_exists($sourcePath)) {
                $processLayoutName = "process_layout_" . time() . "_" . basename($sourcePath);
                copy($sourcePath, $uploadPath . $processLayoutName);
            }
        }
        

        $mainData = [
            'cust' => $this->request->getPost('cust'),
            'model' => $this->request->getPost('model'),
            'receive' => $this->request->getPost('receive'),
            'part_no' => $this->request->getPost('part_no'),
            'part_name' => $this->request->getPost('part_name'),
            'panjang' => $this->request->getPost('panjang'),
            'lebar' => $this->request->getPost('lebar'),
            'cf' => $this->request->getPost('cf'),
            'material' => $this->request->getPost('material'),
            'tonasi' => $this->request->getPost('tonasi'),
            'length' => $this->request->getPost('length'),
            'width' => $this->request->getPost('width'),
            'boq' => $this->request->getPost('boq'),
            'blank' => $this->request->getPost('blank'),
            'panel' => $this->request->getPost('panel'),
            'scrap' => $this->request->getPost('scrap'),
            'total_dies' => $this->request->getPost('total_dies'),
            'total_mp' => $this->request->getPost('total_mp'),
            'doc_level' => $this->request->getPost('doc_level'),
            'total_stroke' => $this->request->getPost('total_stroke'),
            'blank_layout' => $blankLayoutName,
            'process_layout' => $processLayoutName,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $session->get('nickname')
        ];


        $ppsId = $this->ppsModel->insert($mainData);

        $diesData = [];
        $clayoutFiles = $this->request->getFileMultiple("c_layout");
        $dcFiles = $this->request->getFileMultiple("die_construction_img");

        foreach ($this->request->getPost('process') as $index => $process) {
            $clayoutName = null;
            $clayoutSelected = $this->request->getPost('c_layout_selected')[$index] ?? null;
            
            if (isset($clayoutFiles[$index]) && $clayoutFiles[$index]->isValid() && !$clayoutFiles[$index]->hasMoved()) {
                $clayoutName = "clayout_" . time() . "_$index." . $clayoutFiles[$index]->getExtension();
                $clayoutFiles[$index]->move($uploadPath, $clayoutName);
            } elseif ($clayoutSelected) {
                $parsedPath = parse_url($clayoutSelected, PHP_URL_PATH);
                $sourcePath = FCPATH . ltrim($parsedPath, '/');
                
                if (file_exists($sourcePath)) {
                    $clayoutName = "clayout_" . time() . "_$index." . pathinfo($sourcePath, PATHINFO_EXTENSION);
                    copy($sourcePath, $uploadPath . $clayoutName);
                }
            }
            
            $dieConstrName = null;
            $dieConstrSelected = $this->request->getPost('die_constr_selected')[$index] ?? null;
            
            if (isset($dcFiles[$index]) && $dcFiles[$index]->isValid() && !$dcFiles[$index]->hasMoved()) {
                $dieConstrName = "die_constr_" . time() . "_$index." . $dcFiles[$index]->getExtension();
                $dcFiles[$index]->move($uploadPath, $dieConstrName);
            } elseif ($dieConstrSelected) {
                $parsedPath = parse_url($dieConstrSelected, PHP_URL_PATH);
                $sourcePath = FCPATH . ltrim($parsedPath, '/');
                
                if (file_exists($sourcePath)) {
                    $dieConstrName = "die_constr_" . time() . "_$index." . pathinfo($sourcePath, PATHINFO_EXTENSION);
                    copy($sourcePath, $uploadPath . $dieConstrName);
                }
            }
            
            $die_weight = $this->request->getPost('die_weight')[$index] ?? null;
            $class = null;
            if($die_weight > 6971) {
                $class = "A";
            } else if($die_weight > 3914 && $die_weight <= 6971) {
                $class = "B";
            } else if($die_weight > 3914 && $die_weight <= 6971) {
                $class = "C";
            } else if($die_weight > 1961 && $die_weight <= 3914) {
                $class = "D";
            } else if($die_weight > 848 && $die_weight <= 1961) {
                $class = "E";
            } else if($die_weight <= 848) {
                $class = "F";
            }

            $diesData[] = [
                'pps_id' => $ppsId,
                'process' => $process,
                'proses' => $this->request->getPost('proses')[$index] ?? null,
                'proses_gang' =>$this->request->getPost('proses_gang')[$index] ?? null,
                'process_join' => $this->request->getPost('process_join')[$index] ?? null,
                'length_mp' => $this->request->getPost('length_mp')[$index] ?? null,
                'main_pressure' => $this->request->getPost('main_pressure')[$index] ?? null,
            
                'machine' => $this->request->getPost('machine')[$index] ?? null,
                'capacity' => $this->request->getPost('capacity')[$index] ?? null,
                'cushion' => $this->request->getPost('cushion')[$index] ?? null,
                'die_length' => $this->request->getPost('die_length')[$index] ?? null,
                'die_width' => $this->request->getPost('die_width')[$index] ?? null,
                'die_height' => $this->request->getPost('die_height')[$index] ?? null,
                'die_weight' => $this->request->getPost('die_weight')[$index] ?? null,
                'upper' => $this->request->getPost('upper')[$index] ?? null,
                'lower' => $this->request->getPost('lower')[$index] ?? null,
                'pad' => $this->request->getPost('pad')[$index] ?? null,
                'sliding' => $this->request->getPost('sliding')[$index] ?? null,
                'guide' => $this->request->getPost('guide')[$index] ?? null,
                'pad_lifter' => $this->request->getPost('pad_lifter')[$index] ?? null,
                'insert' => $this->request->getPost('insert')[$index] ?? null,
                'heat_treatment' => $this->request->getPost('heat_treatment')[$index] ?? null,
                'clayout_img' => $clayoutName,
                'die_construction_img' => $dieConstrName,
                'bolster_length'       => $this->request->getPost('bolster_length')[$index] ?? null,
                'bolster_width'       => $this->request->getPost('bolster_width')[$index] ?? null,
                'slide_area_length'    => $this->request->getPost('slide_area_length')[$index] ?? null,
                'slide_area_width'    => $this->request->getPost('slide_area_width')[$index] ?? null,
                'die_height_max'       => $this->request->getPost('die_height_max')[$index] ?? null,
                'cushion_pad_length'   => $this->request->getPost('cushion_pad_length')[$index] ?? null,
                'cushion_pad_width'   => $this->request->getPost('cushion_pad_width')[$index] ?? null,
                'cushion_stroke'       => $this->request->getPost('cushion_stroke')[$index] ?? null,
                'panjang'   => $this->request->getPost('panjang')[$index] ?? null,
                'lebar'       => $this->request->getPost('lebar')[$index] ?? null,
                'class'       => $class,
                'dc_process'   =>  $this->request->getPost('die_proses_standard_die')[$index] ?? null,
            ];
        }

        $this->ppsDiesModel->insertBatch($diesData);
   
        // $templatePath = FCPATH . 'uploads/template/templatePPS.xlsx';
        // if (!file_exists($templatePath)) {
        //     return redirect()->back()->with('error', 'Template Excel tidak ditemukan.');
        // }

        // $spreadsheet = IOFactory::load($templatePath);
        // $sheet = $spreadsheet->getActiveSheet();
        // $uploadPath = FCPATH . 'uploads/pps/';
        // if (!is_dir($uploadPath)) {
        //     mkdir($uploadPath, 0777, true);
        // }
        
        // $clayoutFiles = $this->request->getFileMultiple("c_layout");
        // $dcFiles = $this->request->getFileMultiple("die_construction_img");
        // $BlayoutImg = $this->request->getFile("blank_layout_img");

        // if ($BlayoutImg && $BlayoutImg->isValid() && !$BlayoutImg->hasMoved()) {
        //     $BlayoutImgNew = "blank_layout_" . time() . "." . $BlayoutImg->getExtension();
        //     $BlayoutImg->move($uploadPath, $BlayoutImgNew); 
        
        //     $drawing = new Drawing();
        //     $drawing->setName('Blank Layout Image');
        //     $drawing->setDescription('Blank Layout Image');
        //     $drawing->setPath($uploadPath . $BlayoutImgNew);
        //     $drawing->setOffsetX(10);
        //     $drawing->setOffsetY(10); 
        //     $drawing->setResizeProportional(true);
        //     $drawing->setWidth(100); 
        //     $drawing->setHeight(100); 
        //     $drawing->setCoordinates('CP4'); 
        //     $drawing->setWorksheet($sheet);
        // }
    
        // $processLayout = $this->request->getFile("process_layout_img");

        // if ($processLayout && $processLayout->isValid() && !$processLayout->hasMoved()) {
        //     $processLayoutNew = "process_layout_" . time() . "." . $processLayout->getExtension();
        //     $processLayout->move($uploadPath, $processLayoutNew);
        
        //     $drawing = new Drawing();
        //     $drawing->setName('Blank Layout Image');
        //     $drawing->setDescription('Blank Layout Image');
        //     $drawing->setPath($uploadPath . $processLayoutNew);
        //     $drawing->setOffsetX(10); 
        //     $drawing->setOffsetY(10); 
        //     $drawing->setResizeProportional(true);
        //     $drawing->setWidth(100); 
        //     $drawing->setHeight(100); 
      
        //     $drawing->setCoordinates('CI16'); 
        //     $drawing->setWorksheet($sheet);
        // }
    
        //     $sheet->setCellValue('C6', $this->request->getPost('cust'));
        //     $sheet->setCellValue('P6', $this->request->getPost('model'));

        //     $today = date('d-m-Y');
        //     $sheet->setCellValue('AQ6',  $this->request->getPost('receive'));
        //     $sheet->setCellValue('AB6',  $this->request->getPost('receive'));

        //     $sheet->setCellValue('CG5', $this->request->getPost('total_dies'));
        //     $sheet->setCellValue('CG7', $this->request->getPost('total_mp'));
        //     $sheet->setCellValue('CG9', $this->request->getPost('total_stroke'));
        //     $sheet->setCellValue('CG11', $this->request->getPost('doc_level'));
        
        //     $length = (float) $this->request->getPost('length');
        //     $width = (float) $this->request->getPost('width');
        //     $boq = (float) $this->request->getPost('boq');
        //     $sheet->setCellValue('DE68', $this->request->getPost('tonasi'));
        //     $partNo = "Part No :\n" . $this->request->getPost('part_no');
        //     $sheet->setCellValue('CG73', $partNo);
        //     $sheet->getStyle('CG73')->getFont()->setBold(true);
        //     $sheet->getStyle('CG73')->getAlignment()->setWrapText(true); 

        //     $partName = "Part Name :\n" . $this->request->getPost('part_name');
        //     $sheet->setCellValue('CU73', $partName);
        //     $sheet->getStyle('CU73')->getFont()->setBold(true); 
        //     $sheet->getStyle('CU73')->getAlignment()->setWrapText(true); 

        //     $sheet->setCellValue('CI70', $length);
        //     $sheet->setCellValue('CI71', $width);
        //     $sheet->setCellValue('CI72', $boq);
        //     $sheet->setCellValue('CO71',$this->request->getPost('blank'));
        //     $sheet->setCellValue('DB71',  $this->request->getPost('scrap'));
        //     $sheet->setCellValue('CU71',$this->request->getPost('panel'));
        
        //     $sheet->setCellValue('CO66', $this->request->getPost('cf') . " Unit");

        //     $sheet->setCellValue('CS68', $this->request->getPost('material'));
        //     $session = session(); 
        //     $sheet->setCellValue('DB79', $session->get('nickname'));
            
            
        //     $opCells      = ['C9',  'C21', 'C33', 'C45', 'C57', 'C70'];
        //     $processCells = ['C12', 'C24', 'C36', 'C48', 'C60', 'C73'];
        //     $procCells    = ['C15', 'C27', 'C39', 'C51', 'C63', 'C76'];
        //     $prosesCells  = ['C18', 'C30', 'C42', 'C54', 'C66', 'C79'];
        
        //     $cgOpProcessCells = ['CG48', 'CG51', 'CG54', 'CG57', 'CG60', 'CG63', ];
        //     $cgProcessCells = ['CG49', 'CG52', 'CG55', 'CG58', 'CG61', 'CG64'];
        
            
        
        //     $totalDies = min(6, (int) $this->request->getPost('total_dies'));
        //     $processArray = $this->request->getPost('process') ?? [];
        //     $prosesArray  = $this->request->getPost('proses') ?? [];


            
        //     $upperCells      = ['AY18', 'AY30', 'AY42', 'AY54', 'AY67', 'AY80'];
        //     $lowerCells      = ['AY19', 'AY31', 'AY43', 'AY55', 'AY68', 'AY81'];
        //     $padCells        = ['AY20', 'AY33', 'AY45', 'AY57', 'AY70', 'AY83'];
        //     $slidingCells    = ['BJ18', 'BJ30', 'BJ42', 'BJ54', 'BJ67', 'BJ80'];
        //     $guideCells      = ['BJ19', 'BJ31', 'BJ43', 'BJ55', 'BJ68', 'BJ81'];
        //     $padLifterCells  = ['BM19', 'BM32', 'BM44', 'BM56', 'BM69', 'BM82'];
        //     $insertCells     = ['BX18', 'BX30', 'BX42', 'BX54', 'BX67', 'BX80'];
            
        //     $upperTextCells      = ['AU18', 'AU32', 'AU44', 'AU56', 'AU69', 'AU82'];
        //     $lowerTextCells      = ['AU19', 'AU31', 'AU43', 'AU55', 'AU68', 'AU81'];
        //     $padTextCells       = ['AU20', 'AU33', 'AU45', 'AU57', 'AU70', 'AU83'];
        //     $slidingTextCells    = ['BE18', 'BE30', 'BE42', 'BE54', 'BE67', 'BE80'];
        //     $guideTextCells      = ['BE19', 'BE31', 'BE43', 'BE55', 'BE68', 'BE81'];
        //     $padLifterTextCells  = ['BE19', 'BE32', 'BE44', 'BE56', 'BE69', 'BE82'];
        //     $insertTextCells     = ['BT18', 'BT30', 'BT42', 'BT54', 'BT67', 'BT80'];
        //     $dieLengthCells = [];
        //     for ($i = 48; $i <= 63; $i += 3) {
        //         $dieLengthCells[] = 'CW' . $i;
        //     }

        //     $dieWeightCells = [];
        //     for ($i = 49; $i <= 64; $i += 3) {
        //         $dieWeightCells[] = 'CW' . $i;
        //     }

        //     $dieHeightCells = [];
        //     for ($i = 50; $i <= 65; $i += 3) {
        //         $dieHeightCells[] = 'CW' . $i;
        //     }

        //     $qtyDiesProcessCells = ['CL48', 'CL51', 'CL54', 'CL57', 'CL60', 'CL63'];
        //     $dieCushionCells = [];
        //     for ($i = 50; $i <= 65; $i += 3) {
        //         $dieCushionCells[] = 'CO' . $i;
        //     }
        //     $mcCells =  [];
        //     for ($i = 48; $i <= 63; $i += 3) {
        //         $mcCells[] = 'CO' . $i;
        //     }
        //     $bolsterLengthArr     = is_array($this->request->getPost('bolster_length'))     ? $this->request->getPost('bolster_length')     : [];
        //     $bolsterWeightArr     = is_array($this->request->getPost('bolster_width'))     ? $this->request->getPost('bolster_width')     : [];
        //     $slideAreaLengthArr   = is_array($this->request->getPost('slide_area_length'))   ? $this->request->getPost('slide_area_length')   : [];
        //     $slideAreaWeightArr   = is_array($this->request->getPost('slide_area_width'))   ? $this->request->getPost('slide_area_width')   : [];
        //     $dieHeightMaxArr         = is_array($this->request->getPost('die_height'))          ? $this->request->getPost('die_height')          : [];
        //     $cushionPadLengthArr  = is_array($this->request->getPost('cushion_pad_length'))  ? $this->request->getPost('cushion_pad_length')  : [];
        //     $cushionPadWeightArr  = is_array($this->request->getPost('cushion_pad_width'))  ? $this->request->getPost('cushion_pad_width')  : [];
        //     $cushionStrokeArr     = is_array($this->request->getPost('cushion_stroke'))      ? $this->request->getPost('cushion_stroke')      : [];
        //     $machineSpec          = is_array($this->request->getPost('machine'))             ? $this->request->getPost('machine')             : [];

        //     $n = count($machineSpec);
        //     $composites = [];
        //     for ($i = 0; $i < $n; $i++) {
        //         $composites[$i] = 
        //             (isset($bolsterLengthArr[$i]) ? $bolsterLengthArr[$i] : "") . "|" .
        //             (isset($bolsterWeightArr[$i]) ? $bolsterWeightArr[$i] : "") . "|" .
        //             (isset($slideAreaLengthArr[$i]) ? $slideAreaLengthArr[$i] : "") . "|" .
        //             (isset($slideAreaWeightArr[$i]) ? $slideAreaWeightArr[$i] : "") . "|" .
        //             (isset($dieHeightMaxArr[$i]) ? $dieHeightMaxArr[$i] : "") . "|" .
        //             (isset($cushionPadLengthArr[$i]) ? $cushionPadLengthArr[$i] : "") . "|" .
        //             (isset($cushionPadWeightArr[$i]) ? $cushionPadWeightArr[$i] : "") . "|" .
        //             (isset($cushionStrokeArr[$i]) ? $cushionStrokeArr[$i] : "");
        //     }

           
        //     $groups = [];
        //     $details = [];
        //     for ($i = 0; $i < $n; $i++) {
        //         $comp = $composites[$i];
        //         if (!isset($groups[$comp])) {
        //             $groups[$comp] = [];
        //             $details[$comp] = [
        //                 'bolster_length'     => isset($bolsterLengthArr[$i]) ? $bolsterLengthArr[$i] : "",
        //                 'bolster_width'     => isset($bolsterWeightArr[$i]) ? $bolsterWeightArr[$i] : "",
        //                 'slide_area_length'  => isset($slideAreaLengthArr[$i]) ? $slideAreaLengthArr[$i] : "",
        //                 'slide_area_width'  => isset($slideAreaWeightArr[$i]) ? $slideAreaWeightArr[$i] : "",
        //                 'die_height_max'         => isset($dieHeightMaxArr[$i]) ? $dieHeightMaxArr[$i] : "",
        //                 'cushion_pad_length' => isset($cushionPadLengthArr[$i]) ? $cushionPadLengthArr[$i] : "",
        //                 'cushion_pad_width' => isset($cushionPadWeightArr[$i]) ? $cushionPadWeightArr[$i] : "",
        //                 'cushion_stroke'     => isset($cushionStrokeArr[$i]) ? $cushionStrokeArr[$i] : "",
        //             ];
        //         }
        //         $groups[$comp][] = $machineSpec[$i];
        //     }

           
        //         $targetColumns = ["CQ", "CW", "DC"];
        //         $colIdx = 0;

        //         foreach ($groups as $comp => $machines) {
        //             if ($colIdx >= count($targetColumns)) {
                        
        //                 break;
        //             }
        //             $column = $targetColumns[$colIdx];
        //             $machineGroupStr = implode(" - ", $machines);
        //             $sheet->setCellValue("{$column}34", $machineGroupStr);
                    
        //             $d = $details[$comp];
                
        //             $sheet->setCellValue("{$column}35", $d['bolster_length']);
        //             $sheet->setCellValue("{$column}36", $d['bolster_width']);
        //             $sheet->setCellValue("{$column}37", $d['slide_area_length']);
        //             $sheet->setCellValue("{$column}38", $d['slide_area_width']);
        //             $sheet->setCellValue("{$column}39", $d['die_height_max']);
        //             $sheet->setCellValue("{$column}40", $d['cushion_pad_length']);
        //             $sheet->setCellValue("{$column}41", $d['cushion_pad_width']);
        //             $sheet->setCellValue("{$column}42", $d['cushion_stroke']);
                    
        //             $colIdx++;
        //         }


        //     $capacityCells =  [];
        //     for ($i = 49; $i <= 64; $i += 3) {
        //         $capacityCells[] = 'CO' . $i;
        //     }
        //     $ClayoutImageCells = ['H9', 'H21', 'H33', 'H45', 'H57', 'H70'];
        //     $DcLayoutCells = ['AT9', 'AT21', 'AT33', 'AT45', 'AT57', 'AT70'];
        //     $upperArr      = $this->request->getPost('upper') ?? [];
        //     $lowerArr      = $this->request->getPost('lower') ?? [];
        //     $padArr        = $this->request->getPost('pad') ?? [];
        //     $slidingArr    = $this->request->getPost('sliding') ?? [];
        //     $guideArr      = $this->request->getPost('guide') ?? [];
        //     $padLifterArr  = $this->request->getPost('pad_lifter') ?? [];
        //     $insertArr     = $this->request->getPost('insert') ?? [];

        //     $machines   = $this->request->getPost('machine') ?? [];
        //     $capacities = $this->request->getPost('capacity') ?? [];
        //     $cushions   = $this->request->getPost('cushion') ?? [];
        //     $maxWidth = 140;
        //     $maxHeight = 120;
        //     $padding = 10;

        //     for ($i = 0; $i < $totalDies; $i++) {
        //         $sheet->setCellValue($processCells[$i], $processArray[$i] ?? '');
        //         $sheet->setCellValue($prosesCells[$i], $prosesArray[$i] ?? '');
        //         $sheet->setCellValue($opCells[$i], 'OP');
        //         if (isset($qtyDiesProcessCells[$i])) {
        //             $sheet->setCellValue($qtyDiesProcessCells[$i], 1);
        //         }

        //         if (isset($procCells[$i])) {
        //             $sheet->setCellValue($procCells[$i], 'PROC.');
        //         }

        //         $sheet->setCellValue($cgOpProcessCells[$i], $processArray[$i] ?? '');
        //         $sheet->setCellValue(
        //             $cgOpProcessCells[$i] ?? '', 
        //             'OP ' . ($processArray[$i] ?? '')
        //         );
                
        //         $sheet->setCellValue($cgProcessCells[$i],  ($prosesArray[$i] ?? ''));
                
            
        //         $sheet->setCellValue($mcCells[$i], $machines[$i]); 
        
        
        //         $sheet->setCellValue($dieCushionCells[$i], $cushions[$i]);
            
        //         $sheet->setCellValue($capacityCells[$i], $capacities[$i]); 
            
            
        //         if (isset($upperCells[$i])) {
        //             $sheet->setCellValue($upperCells[$i], $upperArr[$i] ?? '');
        //         }
        
        //         if (isset($lowerCells[$i])) {
        //             $sheet->setCellValue($lowerCells[$i], $lowerArr[$i] ?? '');
        //         }
            
        //         if (isset($padCells[$i])) {
        //             $sheet->setCellValue($padCells[$i], $padArr[$i] ?? '');
        //         }
            
        //         if (isset($slidingCells[$i])) {
        //             $sheet->setCellValue($slidingCells[$i], $slidingArr[$i] ?? '');
        //         }
            
        //         if (isset($guideCells[$i])) {
        //             $sheet->setCellValue($guideCells[$i], $guideArr[$i] ?? '');
        //         }
            
        //         if (isset($padLifterCells[$i])) {
        //             $sheet->setCellValue($padLifterCells[$i], $padLifterArr[$i] ?? '');
        //         }
            
        //         if (isset($insertCells[$i])) {
        //             $sheet->setCellValue($insertCells[$i], $insertArr[$i] ?? '');
        //         }

        //         if (isset($upperTextCells[$i])) {
        //             $sheet->setCellValue($upperTextCells[$i], 'UPPER');
        //         }
            
        //         if (isset($lowerTextCells[$i])) {
        //             $sheet->setCellValue($lowerTextCells[$i], 'LOWER');
        //         }
            
        //         if (isset($padTextCells[$i])) {
        //             $sheet->setCellValue($padTextCells[$i], 'PAD');
        //         }
            
        //         if (isset($slidingTextCells[$i])) {
        //             $sheet->setCellValue($slidingTextCells[$i], 'SLIDING');
        //         }
            
        //         if (isset($guideTextCells[$i])) {
        //             $sheet->setCellValue($guideTextCells[$i], 'GUIDE');
        //         }
            
        //         if (isset($padLifterTextCells[$i])) {
        //             $sheet->setCellValue($padLifterTextCells[$i], 'PAD LIFTER');
        //         }
            
        //         if (isset($insertTextCells[$i])) {
        //             $sheet->setCellValue($insertTextCells[$i], 'INSERT');
        //         }
        //         if (isset($clayoutFiles[$i]) && $clayoutFiles[$i]->isValid() && !$clayoutFiles[$i]->hasMoved()) {
        //             $clayoutNewName = "clayout_" . time() . "_" . $i . "." . $clayoutFiles[$i]->getExtension();
        //             $clayoutFiles[$i]->move($uploadPath, $clayoutNewName);
            
        //             $drawing = new Drawing();
        //             $drawing->setName('Clayout Image');
        //             $drawing->setDescription('Clayout Image');
        //             $drawing->setPath($uploadPath . $clayoutNewName);
        //             $drawing->setOffsetX($padding);
        //             $drawing->setOffsetY($padding); 
        //             $drawing->setResizeProportional(true);
        //             $drawing->setWidth($maxWidth);
        //             $drawing->setHeight($maxHeight);
        //             $drawing->setCoordinates($ClayoutImageCells[$i]);
        //             $drawing->setWorksheet($sheet);
        //         }
            
        //         if (isset($dcFiles[$i]) && $dcFiles[$i]->isValid() && !$dcFiles[$i]->hasMoved()) {
        //             $dcNewName = "die_construction_" . time() . "_" . $i . "." . $dcFiles[$i]->getExtension();
        //             $dcFiles[$i]->move($uploadPath, $dcNewName);
            
        //             $drawing = new Drawing();
        //             $drawing->setName('Die Construction Image');
        //             $drawing->setDescription('Die Construction Image');
        //             $drawing->setPath($uploadPath . $dcNewName);
        //             $drawing->setOffsetX($padding); 
        //             $drawing->setOffsetY($padding); 
        //             $drawing->setResizeProportional(true);
        //             $drawing->setWidth($maxWidth);
        //             $drawing->setHeight($maxHeight);
        //             $drawing->setCoordinates($DcLayoutCells[$i]);
        //             $drawing->setWorksheet($sheet);
        //         }
        //     }

        //     $cuCells = [];
        //     $dieSizeCell = [];
        //     for ($i = 48; $i <= 65; $i++) {
        //         $cuCells[] = "CU{$i}";
        //         $dieSizeCell[] = "CW{$i}";
        //     }
            
        //     $diesWeightCells = [];
        //     for ($i = 48; $i <= 63; $i += 3) {
        //         $diesWeightCells[] = "DB{$i}";
        //     }
            
        //     $mainPressCells = ['DB50', 'DB53', 'DB56', 'DB59', 'DB62', 'DB65'];
        //     $dieLengthArray = $this->request->getPost('die_length') ?? [];
        //     $dieWidthArray  = $this->request->getPost('die_width') ?? [];
        
        //     $dieHeightArray = $this->request->getPost('die_height') ?? [];
        //     $dieWeightArray = $this->request->getPost('die_weight') ?? [];
        //     $mainPressureArray = $this->request->getPost('main_pressure') ?? [];

        //     $class = []; 
        //     $dieLenghtStandard = [];
        //     $dieWidthStandard = [];

            
        //     $values = ['L', 'W', 'H'];
        //     $totalDies = count($dieHeightArray); 
            
        //     for ($j = 0; $j < $totalDies; $j++) {
        //         for ($i = 0; $i < 3; $i++) {
        //             if (isset($cuCells[$i + ($j * 3)])) {
        //                 $sheet->setCellValue($cuCells[$i + ($j * 3)], $values[$i]);
        //             }
            
        //             if (isset($dieSizeCell[$i + ($j * 3)])) {
        //                 $value = '';
        //                 if ($i == 0 && isset($dieLengthArray[$j])) {
        //                     $value = $dieLengthArray[$j]; 
        //                 } elseif ($i == 1 && isset($dieWeightArray[$j])) {
        //                     $value = $dieWeightArray[$j]; 
        //                 } elseif ($i == 2 && isset($dieHeightArray[$j])) {
        //                     $value = $dieHeightArray[$j];
        //                 }
        //                 $sheet->setCellValue($dieSizeCell[$i + ($j * 3)], $value);
        //             }
        //         }
            
            
        //         if (isset($diesWeightCells[$j]) && isset($dieWeightArray[$j])) {
        //             $sheet->setCellValue($diesWeightCells[$j], $dieWeightArray[$j]);
        //         }
            
        //         if (isset($mainPressCells[$j]) && isset($mainPressureArray[$j])) {
        //             $sheet->setCellValue($mainPressCells[$j], $mainPressureArray[$j]);
        //         }
           
        //     }

        //     $partNo = $this->request->getPost('part_no');
        //     $partName = $this->request->getPost('part_name');
            

            
        //     $fileName = "PPS_" . $partNo . "_" . $partName . ".xlsx";
            
        //     $newFilePath = WRITEPATH . 'uploads/' . $fileName;
        //     $writer = new Xlsx($spreadsheet);
        //     $writer->save($newFilePath);
            
        //     return $this->response->download($newFilePath, null)->setFileName($fileName);
        return redirect()->to(site_url('pps'))->with('success', 'Data berhasil diupdate');
   
    }

    // public function generateExcel($ppsId)
    // {
    //     // Inisialisasi model untuk mengambil data PPS dan PPS Dies
    //     $ppsModel = new PpsModel();
    //     $ppsDiesModel = new PpsDiesModel();

    //     // Ambil data PPS utama berdasarkan ID
    //     $ppsData = $ppsModel->find($ppsId);
    //     if (!$ppsData) {
    //         // Jika data PPS tidak ditemukan, kembalikan error atau lakukan handling yang sesuai
    //         return redirect()->back()->with('error', 'Data PPS tidak ditemukan.');
    //     }

    //     // Ambil data PPS Dies berdasarkan pps_id
    //     $diesData = $ppsDiesModel->getDiesByPps($ppsId);

    //     // Tentukan path template Excel yang akan digunakan
    //     $templatePath = FCPATH . 'uploads/template/templatePPS.xlsx';
    //     if (!file_exists($templatePath)) {
    //         return redirect()->back()->with('error', 'Template Excel tidak ditemukan.');
    //     }

    //     // Load file template Excel
    //     $spreadsheet = IOFactory::load($templatePath);
    //     $sheet = $spreadsheet->getActiveSheet();

    //     // Tentukan folder untuk menyimpan file hasil generate
    //     $uploadPath = FCPATH . 'uploads/pps/';
    //     if (!is_dir($uploadPath)) {
    //         // Membuat folder upload jika belum ada
    //         mkdir($uploadPath, 0777, true);
    //     }

    //     // --- Pengisian Data PPS Utama ---
    //     // Mengisi data PPS utama dari $ppsData
    //     $sheet->setCellValue('C6', $ppsData['cust']);
    //     $sheet->setCellValue('P6', $ppsData['model']);
    //     $sheet->setCellValue('AQ6', $ppsData['receive']);
    //     $sheet->setCellValue('CG7', $ppsData['total_mp']); // Pastikan field sesuai dengan kebutuhan
    //     $sheet->setCellValue('CG11', $ppsData['doc_level']);
    //     $sheet->setCellValue('CG9', $ppsData('total_stroke'));
    //     $sheet->setCellValue('CG5', $ppsData('total_dies'));
            
    //     // Konversi nilai numerik
    //     $length = (float)$ppsData['length'];
    //     $width  = (float)$ppsData['width'];
    //     $boq    = (float)$ppsData['boq'];

    //     // Menuliskan Part No dan Part Name
    //     $partNo = "Part No :\n" . $ppsData['part_no'];
    //     $sheet->setCellValue('CG73', $partNo);
    //     $sheet->getStyle('CG73')->getFont()->setBold(true);
    //     $sheet->getStyle('CG73')->getAlignment()->setWrapText(true);

    //     $partName = "Part Name :\n" . $ppsData['part_name'];
    //     $sheet->setCellValue('CU73', $partName);
    //     $sheet->getStyle('CU73')->getFont()->setBold(true);
    //     $sheet->getStyle('CU73')->getAlignment()->setWrapText(true);

    //     $sheet->setCellValue('CI70', $length);
    //     $sheet->setCellValue('CI71', $width);
    //     $sheet->setCellValue('CI72', $boq);
    //     $sheet->setCellValue('CO71', $ppsData['blank']);
    //     $sheet->setCellValue('DB71', $ppsData['scrap']);
    //     $sheet->setCellValue('CU71', $ppsData['panel']);
    //     $sheet->setCellValue('CO66', $ppsData['cf'] . " Unit");
    //     $sheet->setCellValue('CS68', $ppsData['material']);
    //     $sheet->setCellValue('DB79', $session->get('nickname'));
            
    //     // Jika terdapat field gambar untuk blank_layout dan process_layout, tampilkan di Excel
    //     if (!empty($ppsData['blank_layout'])) {
    //         $blankLayoutFile = $uploadPath . $ppsData['blank_layout'];
    //         if (file_exists($blankLayoutFile)) {
    //             $drawing = new Drawing();
    //             $drawing->setName('Blank Layout Image');
    //             $drawing->setDescription('Blank Layout Image');
    //             $drawing->setPath($blankLayoutFile);
    //             $drawing->setOffsetX(10);
    //             $drawing->setOffsetY(10);
    //             $drawing->setResizeProportional(true);
    //             $drawing->setWidth(100);
    //             $drawing->setHeight(100);
    //             $drawing->setCoordinates('CP4');
    //             $drawing->setWorksheet($sheet);
    //         }
    //     }
        
    //     if (!empty($ppsData['process_layout'])) {
    //         $processLayoutFile = $uploadPath . $ppsData['process_layout'];
    //         if (file_exists($processLayoutFile)) {
    //             $drawing = new Drawing();
    //             $drawing->setName('Process Layout Image');
    //             $drawing->setDescription('Process Layout Image');
    //             $drawing->setPath($processLayoutFile);
    //             $drawing->setOffsetX(10);
    //             $drawing->setOffsetY(10);
    //             $drawing->setResizeProportional(true);
    //             $drawing->setWidth(100);
    //             $drawing->setHeight(100);
    //             $drawing->setCoordinates('CI16');
    //             $drawing->setWorksheet($sheet);
    //         }
    //     }

    //     // --- Pengisian Data PPS Dies ---
    //     // Contoh cell target untuk beberapa field (sesuaikan dengan layout Excel template)
    //     $opCells      = ['C9',  'C21', 'C33', 'C45', 'C57', 'C70'];
    //     $processCells = ['C12', 'C24', 'C36', 'C48', 'C60', 'C73'];
    //     $procCells    = ['C15', 'C27', 'C39', 'C51', 'C63', 'C76'];
    //     $prosesCells  = ['C18', 'C30', 'C42', 'C54', 'C66', 'C79'];
    //     $cgOpProcessCells = ['CG48', 'CG51', 'CG54', 'CG57', 'CG60', 'CG63'];
    //     $cgProcessCells   = ['CG49', 'CG52', 'CG55', 'CG58', 'CG61', 'CG64'];

    //     // Tentukan cell untuk machine; contoh menggunakan range CO48, CO51, dst.
    //     $mcCells = [];
    //     for ($i = 48; $i <= 63; $i += 3) {
    //         $mcCells[] = 'CO' . $i;
    //     }

    //     // Misal, kita mengisi data dies secara berurutan (sesuaikan jumlah dies dengan cell target)
    //     $padding = 10;
    //     $maxWidth = 140;
    //     $maxHeight = 120;
    //     $ClayoutImageCells = ['H9', 'H21', 'H33', 'H45', 'H57', 'H70'];
    //     $DcLayoutCells     = ['AT9', 'AT21', 'AT33', 'AT45', 'AT57', 'AT70'];

    //     // Pengisian data PPS Dies dengan perulangan, sesuaikan indeks cell jika diperlukan
    //     foreach ($diesData as $index => $die) {
    //         // Batasi pengisian data jika jumlah dies melebihi jumlah cell yang sudah didefinisikan
    //         if ($index >= count($processCells)) {
    //             break;
    //         }

    //         // Pengisian cell proses dan machine
    //         $sheet->setCellValue($processCells[$index], $die['process']);
    //         $sheet->setCellValue($cgOpProcessCells[$index], 'OP ' . $die['process']);
    //         $sheet->setCellValue($cgProcessCells[$index], $die['proses']);
    //         $sheet->setCellValue($opCells[$index], 'OP');
    //         if (isset($mcCells[$index])) {
    //             $sheet->setCellValue($mcCells[$index], $die['machine']);
    //         }

    //         // Pengisian data dimensi die (contoh: die_length, die_weight, die_height)
    //         // Penyesuaian cell index dapat dilakukan sesuai kebutuhan template
    //         $sheet->setCellValue('CI' . (70 + $index), $die['die_length']);
    //         $sheet->setCellValue('CI' . (71 + $index), $die['die_weight']);
    //         $sheet->setCellValue('CI' . (72 + $index), $die['die_height']);

    //         // Jika terdapat file gambar untuk clayout_img dan die_construction_img, tampilkan di Excel
    //         if (!empty($die['clayout_img'])) {
    //             $clayoutFile = $uploadPath . $die['clayout_img'];
    //             if (file_exists($clayoutFile)) {
    //                 $drawing = new Drawing();
    //                 $drawing->setName('Clayout Image');
    //                 $drawing->setDescription('Clayout Image');
    //                 $drawing->setPath($clayoutFile);
    //                 $drawing->setOffsetX($padding);
    //                 $drawing->setOffsetY($padding);
    //                 $drawing->setResizeProportional(true);
    //                 $drawing->setWidth($maxWidth);
    //                 $drawing->setHeight($maxHeight);
    //                 $drawing->setCoordinates($ClayoutImageCells[$index]);
    //                 $drawing->setWorksheet($sheet);
    //             }
    //         }
    //         if (!empty($die['die_construction_img'])) {
    //             $dieConFile = $uploadPath . $die['die_construction_img'];
    //             if (file_exists($dieConFile)) {
    //                 $drawing = new Drawing();
    //                 $drawing->setName('Die Construction Image');
    //                 $drawing->setDescription('Die Construction Image');
    //                 $drawing->setPath($dieConFile);
    //                 $drawing->setOffsetX($padding);
    //                 $drawing->setOffsetY($padding);
    //                 $drawing->setResizeProportional(true);
    //                 $drawing->setWidth($maxWidth);
    //                 $drawing->setHeight($maxHeight);
    //                 $drawing->setCoordinates($DcLayoutCells[$index]);
    //                 $drawing->setWorksheet($sheet);
    //             }
    //         }
    //     }

    //     // --- Pengisian Data Tambahan (jika ada) ---
    //     // Bagian selanjutnya dapat diadaptasi sesuai kebutuhan, misal mengisi data untuk bolster, slide, cushion, dll.
    //     // Kode di bawah ini dapat dikembangkan lebih lanjut berdasarkan struktur data PPS Dies.

    //     // --- Simpan File Excel yang Telah Digenerate ---
    //     $newFilePath = WRITEPATH . 'uploads/generated_' . time() . '.xlsx';
    //     $writer = new Xlsx($spreadsheet);
    //     $writer->save($newFilePath);

    //     // Mengembalikan file hasil generate untuk didownload
    //     return $this->response->download($newFilePath, null)->setFileName('generated.xlsx');
    // }

    public function generateExcel($ppsId)
    {
        $db = \Config\Database::connect();

        // Load models
        $ppsModel = new \App\Models\PpsModel();
        $ppsDiesModel = new \App\Models\PpsDiesModel();

        // Get PPS data
        $ppsData = $ppsModel->find($ppsId);
        if (!$ppsData) {
            return redirect()->back()->with('error', 'Data PPS tidak ditemukan.');
        }

        // Get PPS Dies data
        $ppsDiesData = $ppsDiesModel->getDiesByPps($ppsId);

        // Load template
        $templatePath = FCPATH . 'uploads/template/templatePPS.xlsx';
        if (!file_exists($templatePath)) {
            return redirect()->back()->with('error', 'Template Excel tidak ditemukan.');
        }

        $spreadsheet = IOFactory::load($templatePath);
        $sheet = $spreadsheet->getActiveSheet();
        $uploadPath = FCPATH . 'uploads/pps/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }

        // Set values from PPS data
        $sheet->setCellValue('DE68',  $ppsData['tonasi']);
        $sheet->setCellValue('C6', $ppsData['cust']);
        $sheet->setCellValue('P6', $ppsData['model']);
        $sheet->setCellValue('AB6', date('d/m/Y', strtotime($ppsData['receive'])));

        $formattedDate = date('d/m/Y', strtotime($ppsData['created_at']));
        $sheet->setCellValue('AQ6', $formattedDate);
        
        // $sheet->setCellValue('CG5', $ppsData['total_dies']);
        $sheet->setCellValue('CG7', $ppsData['total_mp']);
        $sheet->setCellValue('CG9', $ppsData['total_stroke']);
        $sheet->setCellValue('CG11', $ppsData['doc_level']);
        $sheet->setCellValue('CI70', $ppsData['length']);
        $sheet->setCellValue('CI71', $ppsData['width']);
        $sheet->setCellValue('CI72', $ppsData['boq']);
        $sheet->setCellValue('CO71', $ppsData['blank']);
        $sheet->setCellValue('DB71', $ppsData['scrap']);
        $sheet->setCellValue('CU71', $ppsData['panel']);
        $sheet->setCellValue('CO66', $ppsData['cf'] . " Unit");
        $sheet->setCellValue('CS68', $ppsData['material']);
        $session = session(); 
        $sheet->setCellValue('DB79', $session->get('nickname'));

        // Set part no and part name
        $partNo = "Part No :\n" . $ppsData['part_no'];
        $sheet->setCellValue('CG73', $partNo);
        $sheet->getStyle('CG73')->getFont()->setBold(true);
        $sheet->getStyle('CG73')->getAlignment()->setWrapText(true);

        $partName = "Part Name :\n" . $ppsData['part_name'];
        $sheet->setCellValue('CU73', $partName);
        $sheet->getStyle('CU73')->getFont()->setBold(true);
        $sheet->getStyle('CU73')->getAlignment()->setWrapText(true);

        // Set images if available
        if ($ppsData['blank_layout']) {
            $drawing = new Drawing();
            $drawing->setName('Blank Layout Image');
            $drawing->setDescription('Blank Layout Image');
            $drawing->setPath(FCPATH . 'uploads/pps/' . $ppsData['blank_layout']);
            $drawing->setOffsetX(10);
            $drawing->setOffsetY(10);
            $drawing->setResizeProportional(true);
            $drawing->setWidth(90);
            $drawing->setHeight(100);
            $drawing->setCoordinates('CP4');
            $drawing->setWorksheet($sheet);
        }

        if ($ppsData['process_layout']) {
            $drawing = new Drawing();
            $drawing->setName('Process Layout Image');
            $drawing->setDescription('Process Layout Image');
            $drawing->setPath(FCPATH . 'uploads/pps/' . $ppsData['process_layout']);
            $drawing->setOffsetX(10);
            $drawing->setOffsetY(10);
            $drawing->setResizeProportional(true);
            $drawing->setWidth(120);
            $drawing->setHeight(280);
            $drawing->setCoordinates('CI16');
            $drawing->setWorksheet($sheet);
        }

        // Set values from PPS Dies data
        $totalDies = count($ppsDiesData);
        $sheet->setCellValue('CG5', $totalDies);
        $opCells = ['C9', 'C21', 'C33', 'C45', 'C57', 'C70'];
        $processCells = ['C12', 'C24', 'C36', 'C48', 'C60', 'C73'];
        $procCells = ['C15', 'C27', 'C39', 'C51', 'C63', 'C76'];
        $prosesCells = ['C18', 'C30', 'C42', 'C54', 'C66', 'C79'];
        $cgOpProcessCells = ['CG48', 'CG51', 'CG54', 'CG57', 'CG60', 'CG63'];
        $cgProcessCells = ['CG49', 'CG52', 'CG55', 'CG58', 'CG61', 'CG64'];
        $qtyDiesProcessCells = ['CL48', 'CL51', 'CL54', 'CL57', 'CL60', 'CL63'];

        $lengthCells = ['CU48', 'CU51', 'CU54', 'CU57', 'CU60', 'CU63'];
        $widthCells = ['CU49', 'CU52', 'CU55', 'CU58', 'CU61', 'CU64'];
        $heightCells = ['CU50', 'CU53', 'CU56', 'CU59', 'CU62', 'CU65'];
        $mcCells = [];
        for ($i = 48; $i <= 63; $i += 3) {
            $mcCells[] = 'CO' . $i;
        }
        $capacityCells = [];
        for ($i = 49; $i <= 64; $i += 3) {
            $capacityCells[] = 'CO' . $i;
        }
        $dieCushionCells = [];
        for ($i = 50; $i <= 65; $i += 3) {
            $dieCushionCells[] = 'CO' . $i;
        }

        $upperTextCells      = ['AU18', 'AU30', 'AU42', 'AU54', 'AU67', 'AU80'];
        $lowerTextCells      = ['AU19', 'AU31', 'AU43', 'AU55', 'AU68', 'AU81'];
        $padTextCells       = ['AU20', 'AU32', 'AU44', 'AU56', 'AU69', 'AU82'];
        $slidingTextCells    = ['BE18', 'BE30', 'BE42', 'BE54', 'BE67', 'BE80'];
        $guideTextCells      = ['BE19', 'BE31', 'BE43', 'BE55', 'BE68', 'BE81'];
        $padLifterTextCells  = ['BE20', 'BE32', 'BE44', 'BE56', 'BE69', 'BE82'];
        $insertTextCells     = ['BT18', 'BT30', 'BT42', 'BT54', 'BT67', 'BT80'];

        
        // Inisialisasi array untuk menyimpan data
        $bolsterLengthArr = [];
        $bolsterWeightArr = [];
        $slideAreaLengthArr = [];
        $slideAreaWeightArr = [];
        $dieHeightMaxArr = [];
        $cushionPadLengthArr = [];
        $cushionPadWeightArr = [];
        $cushionStrokeArr = [];
        $machineSpec = [];

        // Isi array dengan data dari database
        foreach ($ppsDiesData as $die) {
            $bolsterLengthArr[] = $die['bolster_length'];
            $bolsterWeightArr[] = $die['bolster_width'];
            $slideAreaLengthArr[] = $die['slide_area_length'];
            $slideAreaWeightArr[] = $die['slide_area_width'];
            $dieHeightMaxArr[] = $die['die_height_max'];
            $cushionPadLengthArr[] = $die['cushion_pad_length'];
            $cushionPadWeightArr[] = $die['cushion_pad_width'];
            $cushionStrokeArr[] = $die['cushion_stroke'];
            $machineSpec[] = $die['machine'];
        }

        // Daftar kolom target yang ingin diisi data
        $targetColumns = ["CQ", "CU", "CZ", "DE"];
        $j = 0;
        for ($i = 0; $i < $totalDies; $i++) {
            $dieData = $ppsDiesData[$i];

            $column = $targetColumns[$j] ?? end($targetColumns);
        
            // Cek apakah ada baris selanjutnya untuk dibandingkan
            if (
                ($i < $totalDies - 1) &&
                ($bolsterLengthArr[$i]    ?? '') == ($bolsterLengthArr[$i+1]    ?? '') &&
                ($bolsterWeightArr[$i]    ?? '') == ($bolsterWeightArr[$i+1]    ?? '') &&
                ($slideAreaLengthArr[$i]  ?? '') == ($slideAreaLengthArr[$i+1]  ?? '') &&
                ($slideAreaWeightArr[$i]  ?? '') == ($slideAreaWeightArr[$i+1]  ?? '') &&
                ($dieHeightMaxArr[$i]     ?? '') == ($dieHeightMaxArr[$i+1]     ?? '') &&
                ($cushionPadLengthArr[$i] ?? '') == ($cushionPadLengthArr[$i+1] ?? '') &&
                ($cushionPadWeightArr[$i] ?? '') == ($cushionPadWeightArr[$i+1] ?? '') &&
                ($cushionStrokeArr[$i]    ?? '') == ($cushionStrokeArr[$i+1]    ?? '')
            ) {
                // Jika data baris ke-i dan ke-(i+1) identik, gabungkan machineSpec
                $mergedMachine = ($machineSpec[$i] ?? '') . ', ' . ($machineSpec[$i+1] ?? '');
                
                $sheet->setCellValue("{$column}34", $mergedMachine);
                $sheet->setCellValue("{$column}35", $bolsterLengthArr[$i]    ?? '');
                $sheet->setCellValue("{$column}36", $bolsterWeightArr[$i]    ?? '');
                $sheet->setCellValue("{$column}37", $slideAreaLengthArr[$i]  ?? '');
                $sheet->setCellValue("{$column}38", $slideAreaWeightArr[$i]  ?? '');
                $sheet->setCellValue("{$column}39", $dieHeightMaxArr[$i]     ?? '');
                $sheet->setCellValue("{$column}40", $cushionPadLengthArr[$i] ?? '');
                $sheet->setCellValue("{$column}41", $cushionPadWeightArr[$i] ?? '');
                $sheet->setCellValue("{$column}42", $cushionStrokeArr[$i]    ?? '');
                
                // Lewati baris berikutnya karena sudah digabung
                $i++; 
                $j++;
            } else {
                // Jika tidak ada pasangan (atau baris berikutnya berbeda), tuliskan data baris ke-i secara individual
                $sheet->setCellValue("{$column}34", $machineSpec[$i]         ?? '');
                $sheet->setCellValue("{$column}35", $bolsterLengthArr[$i]    ?? '');
                $sheet->setCellValue("{$column}36", $bolsterWeightArr[$i]    ?? '');
                $sheet->setCellValue("{$column}37", $slideAreaLengthArr[$i]  ?? '');
                $sheet->setCellValue("{$column}38", $slideAreaWeightArr[$i]  ?? '');
                $sheet->setCellValue("{$column}39", $dieHeightMaxArr[$i]     ?? '');
                $sheet->setCellValue("{$column}40", $cushionPadLengthArr[$i] ?? '');
                $sheet->setCellValue("{$column}41", $cushionPadWeightArr[$i] ?? '');
                $sheet->setCellValue("{$column}42", $cushionStrokeArr[$i]    ?? '');
                $j++;
            }
           // Hilangkan "OP" dari masing-masing nilai
            $processValue = str_replace("OP", "", $dieData['process']);
            $processJoinValue = str_replace("OP", "", $dieData['process_join']);
            $prosesValue = str_replace("OP", "", $dieData['proses']);
            $prosesGangValue = str_replace("OP", "", $dieData['proses_gang']);

            $sheet->setCellValue(
                $processCells[$i],
                $processValue . ($processJoinValue != null ? ", " . $processJoinValue : "")
            );
            $sheet->setCellValue(
                $prosesCells[$i],
                $prosesValue . ($prosesGangValue != null ? ", " . $prosesGangValue : "")
            );

              $sheet->setCellValue($opCells[$i], 'OP');
            $sheet->setCellValue($procCells[$i], 'PROC.');
                // Hapus "OP" dari field process dan proses, beserta field join-nya
            $cgOpProcessValue     = str_replace("OP", "", $dieData['process']);
            $cgOpProcessJoinValue = str_replace("OP", "", $dieData['process_join']);
            $cgProcessValue       = str_replace("OP", "", $dieData['proses']);
            $cgProcessGangValue   = str_replace("OP", "", $dieData['proses_gang']);

            $sheet->setCellValue(
                $cgOpProcessCells[$i],
                $cgOpProcessValue . ($cgOpProcessJoinValue != null ? ", " . $cgOpProcessJoinValue : "")
            );
            $sheet->setCellValue(
                $cgProcessCells[$i],
                $cgProcessValue . ($cgProcessGangValue != null ? ", " . $cgProcessGangValue : "")
            );

            $sheet->setCellValue($mcCells[$i], $dieData['machine']);
            $sheet->setCellValue($capacityCells[$i], $dieData['capacity']);
            $sheet->setCellValue($dieCushionCells[$i], $dieData['cushion']);
            // $sheet->setCellValue($qtyDiesProcessCells[$i], 1);
            if (isset($qtyDiesProcessCells[$i])) {
                if($cgProcessGangValue == null ){
                    $sheet->setCellValue($qtyDiesProcessCells[$i], 1);
                }else{    
                    $sheet->setCellValue($qtyDiesProcessCells[$i], 1/1);
                }
            }

            // Set die dimensions
            $sheet->setCellValue('CW' . (48 + ($i * 3)), $dieData['die_length']);
            $sheet->setCellValue('CW' . (49 + ($i * 3)), $dieData['die_width']);
            $sheet->setCellValue('CW' . (50 + ($i * 3)), $dieData['die_height']);
            $sheet->setCellValue('DB' . (48 + ($i * 3)), $dieData['die_weight']);
            $sheet->setCellValue('DB' . (50 + ($i * 3)), $dieData['main_pressure']);

            // Set other die-specific data
            $sheet->setCellValue('AY' . (18 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['upper']);
            $sheet->setCellValue('AY' . (19 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['lower']);
            $sheet->setCellValue('AY' . (20 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['pad']);
            $sheet->setCellValue('BJ' . (18 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['sliding']);
            $sheet->setCellValue('BJ' . (19 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['guide']);
            $sheet->setCellValue('BM' . (20 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['pad_lifter']);
            $sheet->setCellValue('BX' . (18 + ($i * 12) + ($i > 3 ? $i - 3 : 0)), $dieData['insert']);
            

            if (isset($lengthCells[$i])) {
                $sheet->setCellValue($lengthCells[$i], 'H');
            }
            
            if (isset($widthCells[$i])) {
                $sheet->setCellValue($widthCells[$i], 'H');
            }
            
            if (isset($heightCells[$i])) {
                $sheet->setCellValue($heightCells[$i], 'H');
            }
            
            if (isset($upperTextCells[$i])) {
                $sheet->setCellValue($upperTextCells[$i], 'UPPER');
            }
            if (isset($lowerTextCells[$i])) {
                $sheet->setCellValue($lowerTextCells[$i], 'LOWER');
            }
        
            if (isset($padTextCells[$i])) {
                $sheet->setCellValue($padTextCells[$i], 'PAD');
            }
        
            if (isset($slidingTextCells[$i])) {
                $sheet->setCellValue($slidingTextCells[$i], 'SLIDING');
            }
        
            if (isset($guideTextCells[$i])) {
                $sheet->setCellValue($guideTextCells[$i], 'GUIDE');
            }
        
            if (isset($padLifterTextCells[$i])) {
                $sheet->setCellValue($padLifterTextCells[$i], 'PAD LIFTER');
            }
        
            if (isset($insertTextCells[$i])) {
                $sheet->setCellValue($insertTextCells[$i], 'INSERT');
            }
        
            
            // Set images if available
            if ($dieData['clayout_img']) {
                $drawing = new Drawing();
                $drawing->setName('Clayout Image');
                $drawing->setDescription('Clayout Image');
                $drawing->setPath(FCPATH . 'uploads/pps/' . $dieData['clayout_img']);
                $drawing->setOffsetX(10);
                $drawing->setOffsetY(10);
                $drawing->setResizeProportional(true);
                $drawing->setWidth(200);
                $drawing->setHeight(200);
                $drawing->setCoordinates('H' . (9 + (($i - 1) * 12)));

                $drawing->setWorksheet($sheet);
            }

            if ($dieData['die_construction_img']) {
                $drawing = new Drawing();
                $drawing->setName('Die Construction Image');
                $drawing->setDescription('Die Construction Image');
                $drawing->setPath(FCPATH . 'uploads/pps/' . $dieData['die_construction_img']);
                $drawing->setOffsetX(10);
                $drawing->setOffsetY(10);
                $drawing->setResizeProportional(true);
                $drawing->setWidth(200);
                $drawing->setHeight(160);
                $drawing->setCoordinates('AT' . (9 + (($i - 1) * 12)));

                $drawing->setWorksheet($sheet);
            }   
        }
        foreach ($spreadsheet->getAllSheets() as $sheet) {
       
            $sheet->getProtection()->setSheet(true);
            $sheet->getProtection()->setPassword('rnd');
            
            $sheet->getProtection()->setSelectLockedCells(true);
            $sheet->getProtection()->setSelectUnlockedCells(true);
        }
        // Save the generated Excel file
        $newFilePath = WRITEPATH . 'uploads/generated_' . time() . '.xlsx';
        $writer = new Xlsx($spreadsheet);
        $writer->save($newFilePath);

        return $this->response->download($newFilePath, null)
        ->setFileName($ppsData['part_no'] . '-' . $ppsData['part_name'] . '.xlsx');
    
    }

    public function checkMatch()
    {
        $input = $this->request->getJSON(true);
    
        $mainPressures = $input['main_pressures'] ?? [];
        $dieLengths    = $input['die_lengths'] ?? [];
        $dieWidths     = $input['die_widths'] ?? [];
    
        if (!is_array($mainPressures) || !is_array($dieLengths) || !is_array($dieWidths)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Input tidak valid.'
            ])->setStatusCode(400);
        }
    
        $model = new McSpecModel();
        $machines = $model->findAll();
        $result = [];
    
        foreach ($mainPressures as $index => $mainPressure) {
            $dieLength = $dieLengths[$index] ?? 0;
        $dieWidth  = $dieWidths[$index] ?? 0;
    
            $matches = [];
            $closestIndex = null;
            $closestDiff = PHP_INT_MAX;
    
            foreach ($machines as $i => $machine) {
                $capacity = floatval($machine['capacity']);
                $threshold = 0.85 * $capacity;
    
                // Validasi ukuran die
                $bolsterLength = floatval($machine['bolster_length']);
                $bolsterWidth  = floatval($machine['bolster_width']);
                $slideLength   = floatval($machine['slide_area_length']);
                $slideWidth    = floatval($machine['slide_area_width']);
    
                $isSizeMatch = ($dieLength < $bolsterLength && $dieLength < $slideLength) &&
                ($dieWidth < $bolsterWidth && $dieWidth < $slideWidth);
 
                $isPressureMatch = $capacity > 0 && $mainPressure < $threshold;
                
                $isMatch = $isPressureMatch && $isSizeMatch;
                
                $reason = '';
                if (!$isPressureMatch) {
                    $reason .= "Main Pressure melebihi 85% kapasitas mesin. ";
                }
                if (!$isSizeMatch) {
                    if ($dieLength >= $bolsterLength || $dieLength >= $slideLength) {
                        $reason .= "Die Length melebihi Bolster/Slide. ";
                    }
                    if ($dieWidth >= $bolsterWidth || $dieWidth >= $slideWidth) {
                        $reason .= "Die Width melebihi Bolster/Slide. ";
                    }
                }
 
                $matches[] = [
                    'machine' => $machine['machine'],
                    'capacity' => $capacity,
                    'cushion' => $machine['cushion'],
                    'bolster_length' => $bolsterLength,
                    'bolster_width'  => $bolsterWidth,
                    'slide_area_length' => $slideLength,
                    'slide_area_width'  => $slideWidth,
                    'match' => $isMatch,
                    'highlight' => false,
                    'reason' => $isMatch ? '✅ Match' : trim($reason)
                ];
    
                if ($isMatch) {
                    $diff = abs($mainPressure - $threshold);
                    if ($diff < $closestDiff) {
                        $closestDiff = $diff;
                        $closestIndex = $i;
                    }
                }
            }
    
            if ($closestIndex !== null) {
                $matches[$closestIndex]['highlight'] = true;
            }
    
            $result[] = [
                'main_pressure' => $mainPressure,
                'die_length' => $dieLength,
                'die_width' => $dieWidth,
                'matches' => $matches, // tambahkan ini
                'reason' => $isMatch ? '✅ Match' : trim($reason)
            ];
            
        }
    
        return $this->response->setJSON($result);
    }
    
    public function listPpsImages()
    {
        $path = FCPATH . 'uploads/process_layout/';
        $files = scandir($path);
        $images = [];
    
        foreach ($files as $file) {
            if (in_array(pathinfo($file, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png', 'gif'])) {
                $images[] = base_url('uploads/process_layout/' . $file);
            }
        }
    
        return $this->response->setJSON($images);
    }
    
    
}
