<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<style>
.selectable-image:hover {
  outline: 2px solid #007bff;
}
.dcp-slider-wrapper {
  display: flex;
  align-items: center;
  position: relative;
}
.dcp-slider-container {
  display: flex;
  overflow-x: auto;
  scroll-behavior: smooth;
  gap: 10px;
  max-width: 100%;
}
.slider-btn {
  background: none;
  border: none;
  cursor: pointer;
}
.slider-btn svg {
  width: 24px;
  height: 24px;
}

</style>

<style>
    /* Styling Step Wizard */
    .step-wizard {
        margin-bottom: 2rem;
        position: relative;
    }
    .step-progress {
        display: flex;
        justify-content: space-between;
        list-style: none;
        padding: 0;
        margin: 0 0 1rem 0;
    }
    .step-progress li {
        flex: 1;
        text-align: center;
        position: relative;
    }
    .step-progress li:before {
        content: "";
        width: 20px;
        height: 20px;
        background-color: #e9ecef;
        border-radius: 50%;
        display: block;
        margin: 0 auto 0.5rem;
        position: relative;
        z-index: 1;
    }
    .step-progress li:after {
        content: "";
        position: absolute;
        width: 100%;
        height: 2px;
        background-color: #e9ecef;
        top: 10px;
        left: -50%;
    }
    .step-progress li:first-child:after {
        content: none;
    }
    .step-progress li.active:before {
        background-color: #007bff;
        color: white;
    }
    .step {
        display: none;
    }
    .step.active {
        display: block;
        animation: fadeIn 0.5s;
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    .nav-buttons {
        margin-top: 1.5rem;
    }
    .nav-buttons button {
        min-width: 120px;
    }
</style>

<div class="pd-ltr-20 xs-pd-20-10">
  <div class="min-height-200px">
    <!-- Page Header -->
    <div class="page-header">
      <div class="row">
        <div class="col-md-6 col-sm-12">
          <div class="title">
            <h4>Edit Data PPS</h4>
          </div>
          <nav aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= site_url('dashboard'); ?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?= site_url('pps'); ?>">PPS</a></li>
              <li class="breadcrumb-item active" aria-current="page">Edit Data PPS</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  
    <!-- Card Box Form Edit -->
    <div class="card-box p-4">
      <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error'); ?></div>
      <?php endif; ?>
      <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success'); ?></div>
      <?php endif; ?>
      
      <!-- Step Wizard -->
      <div class="step-wizard mb-4">
        <ul class="step-progress list-unstyled d-flex justify-content-between">
          <li class="active">Data Utama</li>
          <li>Detail Material</li>
          <li>Konfigurasi Dies</li>
          <li>Die Construction</li>
          <li>Gambar & Info Tambahan</li>
        </ul>
      </div>
      
      <!-- Form Edit -->
      <form action="<?= site_url('pps/update') ?>" method="post" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="id" value="<?= esc($pps['id']) ?>">
        
        <!-- Step 1: Data Utama -->
        <div class="step active" data-step="1">
          <div class="card p-3 mb-3">
            <h5>Data Utama</h5>
            <div class="row">
              <!-- Baris: Customer, Model, Receive -->
              <div class="col-md-4 mb-3">
                <label>Customer</label>
                <input type="text" name="cust" class="form-control" value="<?= esc($pps['cust']) ?>" required>
              </div>
              <div class="col-md-4 mb-3">
                <label>Model</label>
                <input type="text" name="model" class="form-control" value="<?= esc($pps['model']) ?>" required>
              </div>
              <div class="col-md-4 mb-3">
                <label>Receive</label>
                <input type="date" name="receive" class="form-control" value="<?= esc($pps['receive']) ?>">
              </div>
            </div>
            <div class="row">
              <!-- Baris: Part No dan Part Name -->
              <div class="col-md-6 mb-3">
                <label>Part No</label>
                <input type="text" name="part_no" class="form-control" value="<?= esc($pps['part_no']) ?>">
              </div>
              <div class="col-md-6 mb-3">
                <label>Part Name</label>
                <input type="text" name="part_name" class="form-control" value="<?= esc($pps['part_name']) ?>">
              </div>
            </div>
          </div>
          <div class="nav-buttons text-right">
            <button type="button" class="btn btn-primary next-step" data-next="2">Selanjutnya</button>
          </div>
        </div>
        <!-- End Step 1 -->
        
        <!-- Step 2: Detail Material -->
        <div class="step" data-step="2" style="display: none;">
          <div class="card p-3 mb-3">
            <h5>Detail Material</h5>
            <div class="row">
              <!-- Baris: Material & Thickness -->
              <div class="col-md-6 mb-3">
                <label>Material</label>
                <input type="text" name="material" id="material" class="form-control" value="<?= esc($pps['material']) ?>">
              </div>
              <div class="col-md-6 mb-3">
                <label>Thickness</label>
                <input type="text" name="tonasi" id="tonasi" class="form-control" value="<?= esc($pps['tonasi']) ?>">
              </div>
            </div>
            <div class="row">
              <!-- Baris: Length, Width, BOQ -->
              <div class="col-md-4 mb-3">
                <label>Length</label>
                <input type="number" name="length" id="length" class="form-control" value="<?= esc($pps['length']) ?>">
              </div>
              <div class="col-md-4 mb-3">
                <label>Width</label>
                <input type="number" name="width" id="width" class="form-control" value="<?= esc($pps['width']) ?>">
              </div>
              <div class="col-md-4 mb-3">
                <label>BOQ</label>
                <input type="number" name="boq" id="boq" class="form-control" value="<?= esc($pps['boq']) ?>">
              </div>
            </div>
            <div class="row">
              <!-- Baris: Blank, Panel, Scrap -->
              <div class="col-md-4 mb-3">
                <label>Blank</label>
                <input type="number" name="blank" id="blank" class="form-control" value="<?= esc($pps['blank']) ?>" readonly>
              </div>
              <div class="col-md-4 mb-3">
                <label>Panel</label>
                <input type="number" name="panel" id="panel" class="form-control" value="<?= esc($pps['panel']) ?>">
              </div>
              <div class="col-md-4 mb-3">
                <label>Scrap</label>
                <input type="number" name="scrap" id="scrap" class="form-control" value="<?= esc($pps['scrap']) ?>" readonly>
                <span id="scrapError" style="color: red;"></span>
              </div>
            </div>
          </div>
          <div class="nav-buttons text-right">
            <button type="button" class="btn btn-secondary prev-step" data-prev="1">Sebelumnya</button>
            <button type="button" class="btn btn-primary next-step" data-next="3">Selanjutnya</button>
          </div>
        </div>
        <!-- End Step 2 -->

        <?php 
          // Opsi untuk dropdown OP dan opsi proses
          $ops = ["OP10", "OP20", "OP30", "OP40", "OP50", "OP60", "OP70", "OP80"];
          $prosesOptions = ["DRAW", "FORM", "BEND", "REST", "FLANGE", "BLANK", "TRIM", "SEP", "PIE"];
        ?>

        <!-- Step 3: Konfigurasi Dies -->
        <div class="step" data-step="3" style="display: block;">
          
         <!-- Tombol untuk membuka modal -->
          <div class="text-left mb-2">
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#diesHintModal">
                  <i class="fa fa-lightbulb-o" aria-hidden="true"></i> Petunjuk
              </button>
          </div>

          <!-- Modal Dies Configuration -->
          <div class="modal fade" id="diesHintModal" tabindex="-1" role="dialog" aria-labelledby="diesHintModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                      <!-- Header Modal -->
                      <div class="modal-header">
                          <h5 class="modal-title" id="diesHintModalLabel">Logika Sistem Dies Configuration</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <!-- Body Modal -->
                      <div class="modal-body">
                          <h6><strong>1. Dies Configuration</strong></h6>
                          <img src="<?= base_url('assets/images/DiesConfiguration.png') ?>" alt="Dies Configuration" class="img-fluid mb-3">
                          <p>Dies Configuration digunakan untuk mengisi PRESS M/C SPEC dan PROCESS DETAIL																																																					
                          yang akan ditempelkan pada bagian Excel seperti gamabr diatas</p>

                          <hr>

                          <h6><strong>2. Konversi Tensile Material</strong></h6>
                          <p>Tensile material dikonversi berdasarkan nilai material yang digunakan:</p>
                          <pre>
                            if (tensile_material === 270) {
                                konversi = 30;
                            } else if (tensile_material === 440) {
                              konversi = 45;
                            } else if (material === 590) {
                              konversi = 60;
                            } else {
                              konversi = 100; 
                            }
                          </pre>

                          <hr>

                          <h6><strong>3. Perhitungan Main Pressure</strong></h6>
                          <p>Rumus perhitungan tekanan utama (Main Pressure):</p>
                          <ul>
                              <li>BL/TR: <code>(Luas * thickness * 0.8 * konversi * 1.2 * 1) / 1000</code></li>
                              <li>DR/DO: <code>(Luas * thickness * 0.8 * konversi * 1.2 * 2.5) / 1000</code></li>
                          </ul>

                          <hr>

                          <h6><strong>4. Spesifikasi Mesin</strong></h6>
                          <!-- <p>Spesifikasi mesin dapat dilihat pada gambar berikut:</p>
                          <img src="<?= base_url('assets/images/specMesin.png') ?>" alt="Spesifikasi Mesin" class="img-fluid mb-3"> -->
                          <p>Untuk melihat data lengkap, kunjungi: <a href="<?= base_url('master-pps') ?>"  target="_blank" >Master Data PPS</a></p>

                          <hr>

                          <h6><strong>5. Data Tonase, Cushion dan Die Height</strong></h6>

                          <p>Untuk melihat master data Tonase, Cushion dan Die Height tiap mesin, kunjungi: <a href="../master-pps"  target="_blank" >Master Data PPS</a></p>

                       

                          <hr>

                          <h6><strong>6. Perhitungan Die Weight</strong></h6>
                          <img src="<?= base_url('assets/images/konversiDieWeight.png') ?>" alt="Konversi Die Weight" class="img-fluid mb-3">
                          <p>Rumus perhitungan berat Die:</p>
                          <pre>(dieLength * dieWidth * dieHeight * factor * 7.85) / 1000000</pre>

                          <p>Untuk melihat master data Die Sizing Process, kunjungi: <a href="../master-pps"  target="_blank" >Master Data PPS</a></p>
                          <ul>
                              <li>Big Dies :Apabila memilih machine A, D, E, F, G</li>
                              <li>Medium Dies :Apabila memilih machine B, H, C</li>
                              <li>Small Dies :Apabila memilih machine 300 T (MP), SP</li>
                          </ul>
                          </div>
                  </div>
              </div>
          </div>
          <div class="card p-3 mb-3">
            <h5>Konfigurasi Dies</h5>
            <div class="col-md-3 mb-3">
              <label>CF</label>
              <input type="text" name="cf" class="form-control" value="<?= esc($pps['cf']) ?>">
            </div>
            <!-- Tabel Basic -->
            <h6 class="mb-3">Tabel Basic</h6>
            <!-- Button Add Row -->
            <div class="d-flex justify-content-center mb-3">
              <button type="button" id="addRow" class="btn btn-success mb-2">Add Row</button>
            </div>
           
            <div class="table-responsive mb-3">
              <table class="table table-bordered" id="tableBasic">
                <thead>
                          <tr>
                              <th width="8%">OP</th>
                              <th width="8%">OP Gang</th>
                              <th width="12%">Nama Proses</th>
                              <th width="12%">Proses Gang</th>
                              <th width="8%">Panjang Part</th>
                              <th width="8%">Lebar Part</th>
                              <th width="8%">Keliling</th>
                              <th width="8%">Main Pressure</th>
                              <th class="hidden-column" id="machineColumn" width="8%">Machine</th>
                              <th class="hidden-column" id="capacityColumn" width="8%">Capacity</th>
                              <th class="hidden-column" id="cushionColumn" width="8%">Cushion</th>
                              <th width="8%">Aksi</th>
                          </tr>
                      </thead>
                <tbody>
                  <?php if (!empty($dies)): ?>
                    <?php foreach ($dies as $index => $die): ?>
                      <tr data-index="<?= $index ?>">
                        <!-- OP: dropdown -->
                        <td>
                          <select name="dies[<?= $index ?>][process]" class="form-control basic-process" >
                            <?php foreach ($ops as $op): ?>
                              <option value="<?= $op ?>" <?= ($die['process'] == $op) ? 'selected' : '' ?>><?= $op ?></option>
                            <?php endforeach; ?>
                          </select>
                        </td>
                        <!-- OP Gang: dropdown -->
                        <td>
                          <select name="dies[<?= $index ?>][process_join]" class="form-control">
                          <option value="" selected>Pilih</option>
                          <?php foreach ($ops as $op): ?>
                              <option value="<?= $op ?>" <?= ($die['process_join'] == $op) ? 'selected' : '' ?>><?= $op ?></option>
                            <?php endforeach; ?>
                          </select>
                        </td>
                        <!-- Proses: dropdown -->
                        <td>
                          <div class="input-proses">
                              <?php for ($i = 1; $i <= 3; $i++): ?>
                                  <div class="proses-wrapper">
                                      <select name="dies[<?= $index ?>][proses_input<?= $i ?>]" class="form-control mb-2" 
                                          onchange="updateProsesHidden(this.closest('.input-proses')), updateDieConstructionRow(<?= $index ?>), updateDCProcessDropdown(<?= $index ?>)">
                                          <option value="" selected>Pilih</option>
                                          <?php foreach ($prosesOptions as $p): ?>
                                              <option value="<?= $p ?>" <?= ($die["proses"] == $p) ? 'selected' : '' ?>><?= $p ?></option>
                                          <?php endforeach; ?>
                                      </select>
                                      <label>
                                          <input type="checkbox" class="proses-checkbox" data-index="<?= $i ?>" 
                                              onchange="updateProsesHidden(this.closest('.input-proses'))" value="CAM"> CAM
                                      </label>
                                  </div>
                              <?php endfor; ?>
                              
                              <input type="text" name="dies[<?= $index ?>][proses]" class="form-control" 
                                  value="<?= esc($die['proses']) ?>" 
                                  oninput="updateDCProcessDropdown(<?= $index ?>), calculateDieWeight2(this)" readonly>
                          </div>
                        </td>


                        <!-- Proses Gang: dropdown -->
                        <td>
                          <div class="input-proses-gang">
                              <!-- Dropdown 1 + Checkbox CAM -->
                              <div class="proses-wrapper">
                                  <select name="dies[<?= $index ?>][proses_gang_input1]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('.input-proses-gang')), updateDCProcessDropdown(<?= $index ?>)">
                                      <option value="" selected>Pilih</option>
                                      <?php foreach ($prosesOptions as $p): ?>
                                          <option value="<?= $p ?>" <?= (isset($die['proses_gang_input1']) && $die['proses_gang_input1'] == $p) ? 'selected' : '' ?>><?= $p ?></option>
                                      <?php endforeach; ?>
                                  </select>
                                  <label>
                                      <input type="checkbox" class="proses-gang-checkbox" data-index="1" onchange="updateProsesGangHidden(this.closest('.input-proses-gang'))" value="CAM"> CAM
                                  </label>
                              </div>

                              <!-- Dropdown 2 + Checkbox CAM -->
                              <div class="proses-wrapper">
                                  <select name="dies[<?= $index ?>][proses_gang_input2]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('.input-proses-gang')), updateDCProcessDropdown(<?= $index ?>)">
                                      <option value="" selected>Pilih</option>
                                      <?php foreach ($prosesOptions as $p): ?>
                                          <option value="<?= $p ?>" <?= (isset($die['proses_gang_input2']) && $die['proses_gang_input2'] == $p) ? 'selected' : '' ?>><?= $p ?></option>
                                      <?php endforeach; ?>
                                  </select>
                                  <label>
                                      <input type="checkbox" class="proses-gang-checkbox" data-index="2" onchange="updateProsesGangHidden(this.closest('.input-proses-gang'))" value="CAM"> CAM
                                  </label>
                              </div>

                              <!-- Dropdown 3 + Checkbox CAM -->
                              <div class="proses-wrapper">
                                  <select name="dies[<?= $index ?>][proses_gang_input3]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('.input-proses-gang')), updateDCProcessDropdown(<?= $index ?>)">
                                      <option value="" selected>Pilih</option>
                                      <?php foreach ($prosesOptions as $p): ?>
                                          <option value="<?= $p ?>" <?= (isset($die['proses_gang_input3']) && $die['proses_gang_input3'] == $p) ? 'selected' : '' ?>><?= $p ?></option>
                                      <?php endforeach; ?>
                                  </select>
                                  <label>
                                      <input type="checkbox" class="proses-gang-checkbox" data-index="3" onchange="updateProsesGangHidden(this.closest('.input-proses-gang'))" value="CAM"> CAM
                                  </label>
                              </div>

                              <input type="text" name="dies[<?= $index ?>][proses_gang]" class="form-control" value="<?= isset($die['proses_gang']) ? esc($die['proses_gang']) : '' ?>" oninput="updateDCProcessDropdown(<?= $index ?>)" readonly>
                          </div>
                      </td>

                        <td>
                          <input type="number" name="dies[<?= $index ?>][panjang]" class="form-control" value="<?= esc($die['panjang']) ?>" oninput="calculateLuas(this)">
                        </td>
                        <td>
                          <input type="number" name="dies[<?= $index ?>][lebar]" class="form-control" value="<?= esc($die['lebar']) ?>" oninput="calculateLuas(this)">
                        </td>
                        <td>
                          <input type="number" name="dies[<?= $index ?>][length_mp]" class="form-control" value="<?= esc($die['length_mp']) ?>" oninput="calculateMainPressure(this)" readonly>
                        </td>
                        <td>
                          <input type="number" name="dies[<?= $index ?>][main_pressure]" class="form-control" value="<?= esc($die['main_pressure']) ?>">
                        </td>
                        <!-- Machine -->
                        <td>
                          <select name="dies[<?= $index ?>][machine]" class="form-control basic-machine" onchange="onMachineChange(this),  updateDieConstructionRow(this.closest('tr').getAttribute('data-index')),updateDCProcessDropdown(<?= $index ?>), calculateDieWeight2(this),  calculateTotalMP();">
                            <?php foreach ($machineOptions as $option): ?>
                              <option value="<?= esc($option) ?>" <?= ($die['machine'] == $option) ? 'selected' : '' ?>>
                                <?= esc($option) ?>
                              </option>
                            <?php endforeach; ?>
                          </select>
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][capacity]" class="form-control" value="<?= esc($die['capacity']) ?>" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][cushion]" class="form-control" value="<?= esc($die['cushion']) ?>" readonly>
                        </td>
                        <td>
                          <button type="button" class="btn btn-danger deleteRow">Hapus</button>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr data-index="0">
                      <td>
                        <select name="dies[0][process]" class="form-control basic-process">
                          <?php foreach ($ops as $op): ?>
                            <option value="<?= $op ?>"><?= $op ?></option>
                          <?php endforeach; ?>
                        </select>
                      </td>
                      <td>
                        <select name="dies[0][process_join]" class="form-control">
                          <?php foreach ($ops as $op): ?>
                            <option value="<?= $op ?>"><?= $op ?></option>
                          <?php endforeach; ?>
                        </select>
                      </td>
                      <td>
                        <div class="input-proses">
                            <!-- Dropdown 1 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_input1]" class="form-control mb-2" onchange="updateProsesHidden(this.closest('.input-proses')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option> 
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-checkbox" data-index="1" onchange="updateProsesHidden(this.closest('.input-proses'))" value="CAM"> CAM
                                </label>
                            </div>

                            <!-- Dropdown 2 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_input2]" class="form-control mb-2" onchange="updateProsesHidden(this.closest('.input-proses')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option>
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-checkbox" data-index="2" onchange="updateProsesHidden(this.closest('.input-proses'))" value="CAM"> CAM
                                </label>
                            </div>

                            <!-- Dropdown 3 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_input3]" class="form-control mb-2" onchange="updateProsesHidden(this.closest('.input-proses')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option> 
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-checkbox" data-index="3" onchange="updateProsesHidden(this.closest('.input-proses'))" value="CAM"> CAM
                                </label>
                            </div>

                            <input type="text" name="dies[0][proses]" class="form-control" oninput="updateDCProcessDropdown(0), calculateDieWeight2(this)" readonly>
                        </div>
                      </td>

                      <td>
                        <div class="input-proses-gang">
                            <!-- Dropdown 1 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_gang_input1]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option>
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-gang-checkbox" data-index="1" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang'))" value="CAM"> CAM
                                </label>
                            </div>

                            <!-- Dropdown 2 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_gang_input2]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option>
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-gang-checkbox" data-index="2" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang'))" value="CAM"> CAM
                                </label>
                            </div>

                            <!-- Dropdown 3 + Checkbox CAM -->
                            <div class="proses-wrapper">
                                <select name="dies[0][proses_gang_input3]" class="form-control mb-2" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang')), updateDCProcessDropdown(0)">
                                    <option value="" selected>Pilih</option>
                                    <?php foreach ($prosesOptions as $p): ?>
                                        <option value="<?= $p ?>"><?= $p ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label>
                                    <input type="checkbox" class="proses-gang-checkbox" data-index="3" onchange="updateProsesGangHidden(this.closest('div.input-proses-gang'))" value="CAM"> CAM
                                </label>
                            </div>

                            <input type="text" name="dies[0][proses_gang]" class="form-control" oninput="updateDCProcessDropdown(0)" readonly>
                        </div>
                      </td>
                      <td>
                      <input type="number" name="dies[0][panjang]" class="form-control" oninput="calculateLuas(this)">
                      </td>
                      <td>
                      <input type="number" name="dies[0][lebar]" class="form-control" oninput="calculateLuas(this)">
                      </td>
                      <td>
                      <input type="number" name="dies[0][length_mp]" class="form-control" oninput="calculateMainPressure(this)" readonly>
                      </td>
                      <td>
                        <input type="text" name="dies[0][main_pressure]" class="form-control">
                      </td>
                      <td>
                        <select name="dies[0][machine]" class="form-control basic-machine" onchange="onMachineChange(this),  updateDieConstructionRow(this.closest('tr').getAttribute('data-index')),updateDCProcessDropdown(0),  calculateDieWeight2(this),   calculateTotalMP();">
                          <?php foreach ($machineOptions as $option): ?>
                            <option value="<?= esc($option) ?>"><?= esc($option) ?></option>
                          <?php endforeach; ?>
                        </select>
                      </td>
                      <td>
                        <input type="text" name="dies[0][capacity]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][cushion]" class="form-control">
                      </td>
                      <td>
                        <button type="button" class="btn btn-danger deleteRow">Hapus</button>
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <div class="d-flex justify-content-center mb-3">
              <button type="button" class="btn btn-secondary ms-2" onclick="showMachineMatchModal()">List Match Machine</button>
            </div>
            <div class="card p-3 mb-3">
              <h6 class="mb-3">Tabel Die</h6>
              <div class="table-responsive">
                <table class="table table-bordered" id="tableDie">
                  <thead>
                    <tr>
                      <th>Process</th>
                      <th>Proses Standard Die</th>
                      <th>Die Length</th>
                      <th>Die Width</th>
                      <th>Die Height</th>
                      <th>Casting/Plate</th>
                      <th>Die Weight</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($dies)): ?>
                      <?php foreach ($dies as $index => $die): ?>
                        <tr data-index="<?= $index ?>">
                          <!-- Process mengikuti Basic -->
                          <td>
                            <input type="text" name="dies[<?= $index ?>][process]" class="form-control die-process" readonly value="<?= esc($die['process']) ?>">
                          </td>
                          <td>
                            <select name="dies[<?= $index ?>][dc_process]" class="form-control" onchange="onStandardChange(this)">
                              <option value="BIG DIE|SINGLE|DRAW" <?= ($die['dc_process'] == "BIG DIE|SINGLE|DRAW") ? 'selected' : '' ?>>BIG DIE, SINGLE, DRAW</option>
                              <option value="BIG DIE|SINGLE|DEEP DRAW" <?= ($die['dc_process'] == "BIG DIE|SINGLE|DEEP DRAW") ? 'selected' : '' ?>>BIG DIE, SINGLE, DEEP DRAW</option>
                              <option value="BIG DIE|SINGLE|TRIM" <?= ($die['dc_process'] == "BIG DIE|SINGLE|TRIM") ? 'selected' : '' ?>>BIG DIE, SINGLE, TRIM</option>
                              <option value="BIG DIE|SINGLE|FLANGE" <?= ($die['dc_process'] == "BIG DIE|SINGLE|FLANGE") ? 'selected' : '' ?>>BIG DIE, SINGLE, FLANGE</option>
                              <option value="BIG DIE|SINGLE|CAM FLANGE" <?= ($die['dc_process'] == "BIG DIE|SINGLE|CAM FLANGE") ? 'selected' : '' ?>>BIG DIE, SINGLE, CAM FLANGE</option>
                              <option value="MEDIUM DIE|SINGLE|DRAW" <?= ($die['dc_process'] == "MEDIUM DIE|SINGLE|DRAW") ? 'selected' : '' ?>>MEDIUM DIE, SINGLE, DRAW</option>
                              <option value="MEDIUM DIE|SINGLE|TRIM" <?= ($die['dc_process'] == "MEDIUM DIE|SINGLE|TRIM") ? 'selected' : '' ?>>MEDIUM DIE, SINGLE, TRIM</option>
                              <option value="MEDIUM DIE|SINGLE|FLANGE" <?= ($die['dc_process'] == "MEDIUM DIE|SINGLE|FLANGE") ? 'selected' : '' ?>>MEDIUM DIE, SINGLE, FLANGE</option>
                              <option value="MEDIUM DIE|SINGLE|CAM PIE" <?= ($die['dc_process'] == "MEDIUM DIE|SINGLE|CAM PIE") ? 'selected' : '' ?>>MEDIUM DIE, SINGLE, CAM PIE</option>
                              <option value="MEDIUM DIE|GANG|DRAW" <?= ($die['dc_process'] == "MEDIUM DIE|GANG|DRAW") ? 'selected' : '' ?>>MEDIUM DIE, GANG, DRAW</option>
                              <option value="MEDIUM DIE|GANG|TRIM" <?= ($die['dc_process'] == "MEDIUM DIE|GANG|TRIM") ? 'selected' : '' ?>>MEDIUM DIE, GANG, TRIM</option>
                              <option value="MEDIUM DIE|GANG|FLANGE-CAM PIE" <?= ($die['dc_process'] == "MEDIUM DIE|GANG|FLANGE-CAM PIE") ? 'selected' : '' ?>>MEDIUM DIE, GANG, FLANGE-CAM PIE</option>
                              <option value="SMALL DIE|SINGLE|BLANK" <?= ($die['dc_process'] == "SMALL DIE|SINGLE|BLANK") ? 'selected' : '' ?>>SMALL DIE, SINGLE, BLANK</option>
                              <option value="SMALL DIE|SINGLE|FORMING" <?= ($die['dc_process'] == "SMALL DIE|SINGLE|FORMING") ? 'selected' : '' ?>>SMALL DIE, SINGLE, FORMING</option>
                              <option value="SMALL DIE|SINGLE|CAM PIE" <?= ($die['dc_process'] == "SMALL DIE|SINGLE|CAM PIE") ? 'selected' : '' ?>>SMALL DIE, SINGLE, CAM PIE</option>
                              <option value="SMALL DIE|GANG|FORM-FLANGE" <?= ($die['dc_process'] == "SMALL DIE|GANG|FORM-FLANGE") ? 'selected' : '' ?>>SMALL DIE, GANG, FORM-FLANGE</option>
                              <option value="SMALL DIE|GANG|BEND 1, BEND 2" <?= ($die['dc_process'] == "SMALL DIE|GANG|BEND 1, BEND 2") ? 'selected' : '' ?>>SMALL DIE, GANG, BEND 1, BEND 2</option>
                              <option value="SMALL DIE|GANG|FORMING, PIE" <?= ($die['dc_process'] == "SMALL DIE|GANG|FORMING, PIE") ? 'selected' : '' ?>>SMALL DIE, GANG, FORMING, PIE</option>
                              <option value="SMALL DIE|PROGRESSIVE|BLANK-PIE" <?= ($die['dc_process'] == "SMALL DIE|PROGRESSIVE|BLANK-PIE") ? 'selected' : '' ?>>SMALL DIE, PROGRESSIVE, BLANK-PIE</option>
                            </select>
                          </td>

                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_length]" class="form-control" value="<?= esc($die['die_length']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_width]" class="form-control" value="<?= esc($die['die_width']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_height]" class="form-control" value="<?= esc($die['die_height']) ?>" readonly>
                          </td>
                          <td>
                              <select name="dies[<?= $index ?>][casting_plate]" class="form-control" onchange="calculateDieWeight(this),  updateDieConstructionRow(this.closest('tr').getAttribute('data-index'))">
                                  <option value="casting" <?= ($die['casting_plate'] == "casting") ? 'selected' : '' ?>>Casting</option>
                                  <option value="plate" <?= ($die['casting_plate'] == "plate") ? 'selected' : '' ?>>Plate</option>
                              </select>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_weight]" class="form-control" value="<?= esc($die['die_weight']) ?>" readonly>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                      <?php else: ?>
                        <?php $index = 0; ?> <!-- Definisikan index terlebih dahulu -->
                        <tr data-index="<?= $index ?>">
                          <td>
                            <input type="text" name="dies[<?= $index ?>][process]" class="form-control die-process" readonly>
                          </td>
                          <td>
                            <select name="dies[<?= $index ?>][dc_process]" class="form-control">
                              <option value="BIG DIE|SINGLE|DRAW">BIG DIE, SINGLE, DRAW</option>
                              <option value="BIG DIE|SINGLE|DEEP DRAW">BIG DIE, SINGLE, DEEP DRAW</option>
                              <option value="BIG DIE|SINGLE|TRIM">BIG DIE, SINGLE, TRIM</option>
                              <option value="BIG DIE|SINGLE|FLANGE">BIG DIE, SINGLE, FLANGE</option>
                              <option value="BIG DIE|SINGLE|CAM FLANGE">BIG DIE, SINGLE, CAM FLANGE</option>
                              <option value="MEDIUM DIE|SINGLE|DRAW">MEDIUM DIE, SINGLE, DRAW</option>
                              <option value="MEDIUM DIE|SINGLE|TRIM">MEDIUM DIE, SINGLE, TRIM</option>
                              <option value="MEDIUM DIE|SINGLE|FLANGE">MEDIUM DIE, SINGLE, FLANGE</option>
                              <option value="MEDIUM DIE|SINGLE|CAM PIE">MEDIUM DIE, SINGLE, CAM PIE</option>
                              <option value="MEDIUM DIE|GANG|DRAW">MEDIUM DIE, GANG, DRAW</option>
                              <option value="MEDIUM DIE|GANG|TRIM">MEDIUM DIE, GANG, TRIM</option>
                              <option value="MEDIUM DIE|GANG|FLANGE-CAM PIE">MEDIUM DIE, GANG, FLANGE-CAM PIE</option>
                              <option value="SMALL DIE|SINGLE|BLANK">SMALL DIE, SINGLE, BLANK</option>
                              <option value="SMALL DIE|SINGLE|FORMING">SMALL DIE, SINGLE, FORMING</option>
                              <option value="SMALL DIE|SINGLE|CAM PIE">SMALL DIE, SINGLE, CAM PIE</option>
                              <option value="SMALL DIE|GANG|FORM-FLANGE">SMALL DIE, GANG, FORM-FLANGE</option>
                              <option value="SMALL DIE|GANG|BEND 1, BEND 2">SMALL DIE, GANG, BEND 1, BEND 2</option>
                              <option value="SMALL DIE|GANG|FORMING, PIE">SMALL DIE, GANG, FORMING, PIE</option>
                              <option value="SMALL DIE|PROGRESSIVE|BLANK-PIE">SMALL DIE, PROGRESSIVE, BLANK-PIE</option>
                            </select>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_length]" class="form-control" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_width]" class="form-control" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_height]" class="form-control" readonly>
                          </td>
                          <td>
                            <select name="dies[<?= $index ?>][casting_plate]" class="form-control" onchange="calculateDieWeight(this), updateDieConstructionRow(this.closest('tr').getAttribute('data-index'))">
                              <option value="casting">Casting</option>
                              <option value="plate">Plate</option>
                            </select>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_weight]" class="form-control">
                          </td>
                        </tr>
                      <?php endif; ?>

                  </tbody>
                </table>
              </div>
            </div>

            <div class="modal fade" id="machineMatchModal" tabindex="-1">
              <div class="modal-dialog modal-xl">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title">Machine Match List</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <ul class="nav nav-tabs" id="pressureTabs" role="tablist">
                      <!-- Diisi oleh JS -->
                    </ul>
                    <div class="tab-content mt-3" id="pressureTabContent">
                      <!-- Diisi oleh JS -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Tabel Press M/C Spec -->
            <div class="card p-3 mb-3">
              <h5>Press M/C Spec</h5>
              <div class="table-responsive">
                <table class="table table-bordered" id="tablePress">
                  <thead>
                    <tr>
                      <th>Machine</th>
                      <th>Bolster Area L</th>
                      <th>Bolster Area W</th>
                      <th>Slide Area L</th>
                      <th>Slide Area W</th>
                      <th>Die Height</th>
                      <th>Cushion Pad L</th>
                      <th>Cushion Pad W</th>
                      <th>Cushion Stroke</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($dies)): ?>
                      <?php foreach ($dies as $index => $die): ?>
                        <tr data-index="<?= $index ?>">
                          <!-- Machine: readonly, mengikuti dropdown basic -->
                          <td>
                            <input type="text" name="dies[<?= $index ?>][machine]" class="form-control press-machine"  value="<?= esc($die['machine']) ?>" readonly >
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][bolster_length]" class="form-control" value="<?= esc($die['bolster_length']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][bolster_width]" class="form-control" value="<?= esc($die['bolster_width']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][slide_area_length]" class="form-control" value="<?= esc($die['slide_area_length']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][slide_area_width]" class="form-control" value="<?= esc($die['slide_area_width']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][die_height_max]" class="form-control" value="<?= esc($die['die_height_max']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][cushion_pad_length]" class="form-control" value="<?= esc($die['cushion_pad_length']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][cushion_pad_width]" class="form-control" value="<?= esc($die['cushion_pad_width']) ?>" readonly>
                          </td>
                          <td>
                            <input type="text" name="dies[<?= $index ?>][cushion_stroke]" class="form-control" value="<?= esc($die['cushion_stroke']) ?>" readonly>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    <?php else: ?>
                      <tr data-index="0">
                        <td>
                          <input type="text" name="dies[0][machine]" class="form-control press-machine" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][bolster_length]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][bolster_width]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][slide_area_length]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][slide_area_width]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][die_height_max]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][cushion_pad_length]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][cushion_pad_width]" class="form-control" readonly>
                        </td>
                        <td>
                          <input type="text" name="dies[0][cushion_stroke]" class="form-control" readonly>
                        </td>
                      </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>

           
          </div>
          <div class="nav-buttons text-right">
            <button type="button" class="btn btn-secondary prev-step" data-prev="2">Sebelumnya</button>
            <button type="button" class="btn btn-primary next-step" data-next="4">Selanjutnya</button>
          </div>
        </div>
        <!-- End Step 3 -->

        <!-- Step 4: Die Construction -->
        <div class="step" data-step="4" style="display: none;">
          <div class="text-left mb-2">
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#dieConstructionHintModal">
                  <i class="fa fa-lightbulb-o" aria-hidden="true"></i> Petunjuk
              </button>
          </div>

          <div class="modal fade" id="dieConstructionHintModal" tabindex="-1" role="dialog" aria-labelledby="dieConstructionHintModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                  <div class="modal-content">
                     
                      <div class="modal-header">
                          <h5 class="modal-title" id="dieConstructionHintModalLabel">Logika Sistem untuk Die Construction</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                          <h6><b>1. Penjelasan Die Construction</b></h6>
                          <img src="<?= base_url('assets/images/DiesConfiguration.png') ?>" alt="Dies Construction" class="img-fluid mb-3">
                          <p>Dies Configuration digunakan untuk mengisi <b>PRESS M/C SPEC</b> dan <b>PROCESS DETAIL</b> yang akan ditempelkan pada bagian Excel seperti pada gambar di atas.</p>

                          <hr>

                          <h6><b>2. Pemilihan Material pada Die Construction</b></h6>
                          <ul>
                              <li>Bagian <b>Upper & Lower Die</b> menggunakan material <b>SS41</b> jika <b>Die Plate</b>, sedangkan <b>Die Casting</b> menggunakan <b>FC300</b>.</li>
                              <li>Bagian <b>Pad</b> menggunakan material <b>S45C</b> untuk <b>Die Plate</b>, dan <b>FCD55</b> untuk <b>Die Casting</b>.</li>
                              <li>Bagian <b>Pad Lifter</b> menggunakan <b>Coil Spring</b> jika prosesnya melibatkan <b>FL, DR, BE, RE, atau FO</b>, sedangkan proses lainnya menggunakan <b>Gas Spring</b>.</li>
                              <li>Bagian <b>Sliding</b> selalu menggunakan <b>Wear Plate</b>.</li>
                              <li>Bagian <b>Guide</b> menggunakan <b>Guide Post</b> jika <b>Die Plate</b> dan proses melibatkan <b>BL, CUT, atau TR</b>. Selain itu, maka menggunakan <b>GUIDE HEEL</b>.</li>
                          </ul>

                          <hr>

                          <h6><b>3. Pemilihan Insert dan Heat Treatment</b></h6>
                          <ul>
                              <li>Jika material lebih dari <b>440 MPa</b> dan tonase lebih dari <b>1 ton</b>, maka insert menggunakan <b>SKD11</b>.</li>
                              <li>Proses seperti <b>FL, DR, BE, RE, dan FO</b> menggunakan insert <b>SXACE</b>, sementara <b>PI</b> menggunakan <b>S45C</b>.</li>
                              <li>Proses seperti <b>BL, TR, SEP, dan CUT</b> menggunakan <b>SKD11</b>.</li>
                              <li>Insert <b>SXACE</b> mendapatkan perlakuan <b>FULL HARD + COATING</b>, sementara lainnya menggunakan <b>FLAME HARDENING</b>.</li>
                          </ul>

                          <hr>

                          <h6><b>4. Output Tabel Configuration</b></h6>
                          <p>Output yang ditampilkan pada tabel configuration hanya sebagai <b>rekomendasi</b> dan dapat disesuaikan dengan kondisi yang dibutuhkan.</p>

                          <hr>

                          <h6><b>5. Upload Gambar</b></h6>
                          <p>Fitur upload gambar bersifat <b>opsional</b> dan tidak wajib diisi melalui program jika lebih mudah dilakukan melalui Excel.</p>
                      </div>
                  </div>
              </div>
          </div>
          <div class="card p-3 mb-3">
            <h5>Die Construction</h5>
            <div class="table-responsive">
              <table class="table table-bordered" id="tableDieConstruction">
                <thead>
                  <tr>
                    <th>Process</th>
                    <th>Machine</th>
                    <th>Upper</th>
                    <th>Lower</th>
                    <th>Pad</th>
                    <th>Pad Lifter</th>
                    <th>Sliding</th>
                    <th>Guide</th>
                    <th>Insert</th>
                    <th>Heat Treatment</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!empty($dies)): ?>
                    <?php foreach ($dies as $index => $die): ?>
                      <tr data-index="<?= $index ?>">
                        <!-- Process & Machine mengikuti Basic -->
                        <td>
                          <input type="text" name="dies[<?= $index ?>][proses]" class="form-control dc-proses" readonly value="<?= esc($die['proses']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][machine]" class="form-control dc-machine" readonly value="<?= esc($die['machine']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][upper]" class="form-control" value="<?= esc($die['upper']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][lower]" class="form-control" value="<?= esc($die['lower']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][pad]" class="form-control" value="<?= esc($die['pad']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][pad_lifter]" class="form-control" value="<?= esc($die['pad_lifter']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][sliding]" class="form-control" value="<?= esc($die['sliding']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][guide]" class="form-control" value="<?= esc($die['guide']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][insert]" class="form-control" value="<?= esc($die['insert']) ?>">
                        </td>
                        <td>
                          <input type="text" name="dies[<?= $index ?>][heat_treatment]" class="form-control" value="<?= esc($die['heat_treatment']) ?>">
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr data-index="0">
                      <td>
                        <input type="text" name="dies[0][proses]" class="form-control dc-proses" readonly>
                      </td>
                      <td>
                        <input type="text" name="dies[0][machine]" class="form-control dc-machine" readonly>
                      </td>
                      <td>
                        <input type="text" name="dies[0][upper]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][lower]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][pad]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][pad_lifter]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][sliding]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][guide]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][insert]" class="form-control">
                      </td>
                      <td>
                        <input type="text" name="dies[0][heat_treatment]" class="form-control">
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <table class="table table-bordered" id="tableImages">
              <thead>
                <tr>
                  <th>Process</th>
                  <th>C-Layout Image</th>
                  <th>Die Construction Image</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!empty($dies)): ?>
                  <?php foreach ($dies as $index => $die): ?>
                    <tr data-index="<?= $index ?>">
                      <td>
                        <input type="text" name="dies[<?= $index ?>][process]" class="form-control img-process" readonly value="<?= esc($die['process']) ?>">
                      </td>
                      <td>
                        <input type="file" accept=".jpg, .jpeg, .png" name="dies[<?= $index ?>][clayout_img]" class="form-control" onchange="previewImage(event, 'clayout_preview_<?= $index ?>')">
                        <?php if (!empty($die['clayout_img'])): ?>
                          <br>
                          
                          <img id="clayout_preview_<?= $index ?>" src="<?= base_url('uploads/pps/' . $die['clayout_img']) ?>" width="150" alt="C-Layout">
                          <input type="hidden" name="dies[<?= $index ?>][old_clayout_img]" value="<?= $die['clayout_img'] ?>">
                          <div class="dcp-image-list mb-2" id="clayout_image_list_<?= $index ?>" style="display: flex; gap: 10px; flex-wrap: wrap;"></div>
  <input type="hidden" name="dies[<?= $index ?>][selected_clayout_img]" id="selected_clayout_<?= $index ?>">
  <script>loadPpsImageList(<?= $index ?>, 'clayout');</script>
                        <?php else: ?>
                          <br>
                          <img id="clayout_preview_<?= $index ?>" src="#" width="150" alt="Preview" style="display:none;">
                          <input type="hidden" name="dies[<?= $index ?>][old_clayout_img]">
                          <div class="dcp-image-list mb-2" id="clayout_image_list_<?= $index ?>" style="display: flex; gap: 10px; flex-wrap: wrap;"></div>
                            <input type="hidden" name="dies[<?= $index ?>][selected_clayout_img]" id="selected_clayout_<?= $index ?>">
                            <script>loadPpsImageList(<?= $index ?>, 'clayout');</script>
                        <?php endif; ?>
                      </td>
                      <td>
                        <input type="file" accept=".jpg, .jpeg, .png" name="dies[<?= $index ?>][die_construction_img]" class="form-control" onchange="previewImage(event, 'die_construction_preview_<?= $index ?>')">
                        <?php if (!empty($die['die_construction_img'])): ?>
                          <br>
                          <img id="die_construction_preview_<?= $index ?>" src="<?= base_url('uploads/pps/' . $die['die_construction_img']) ?>" width="150" alt="Die Construction">
                          
                          <input type="hidden" name="dies[<?= $index ?>][old_die_construction_img]" value="<?= $die['die_construction_img'] ?>">
                        <?php else: ?>
                          <br>
                          <input type="hidden" name="dies[0][old_die_construction_img]" value="">
                          <img id="die_construction_preview_<?= $index ?>" src="#" width="150" alt="Preview" style="display:none;">
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr data-index="0">
                    <td>
                      <input type="text" name="dies[0][process]" class="form-control img-process" readonly>
                    </td>
                    <td>
                      <input type="file" accept=".jpg, .jpeg, .png" name="dies[0][clayout_img]" class="form-control" onchange="previewImage(event, 'clayout_preview_0')">
                      <input type="hidden" name="dies[0][old_clayout_img]" value="">
                      <br>
                      <img id="clayout_preview_0" src="#" width="150" alt="Preview" style="display:none;">
                    </td>
                    <td>
                      <input type="file" accept=".jpg, .jpeg, .png" name="dies[0][die_construction_img]" class="form-control" onchange="previewImage(event, 'die_construction_preview_0')">
                      <input type="hidden" name="dies[0][old_die_construction_img]" value="">
                      <br>
                      <img id="die_construction_preview_0" src="#" width="150" alt="Preview" style="display:none;">
                    </td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <script>
            function previewImage(event, previewId) {
              var input = event.target;
              var reader = new FileReader();
              reader.onload = function(){
                var imgElement = document.getElementById(previewId);
                imgElement.src = reader.result;
                imgElement.style.display = "block";
              }
              if(input.files && input.files[0]){
                reader.readAsDataURL(input.files[0]);
              }
            }
          </script>
        
          <div class="nav-buttons text-right">
            <button type="button" class="btn btn-secondary prev-step" data-prev="3">Sebelumnya</button>
            <button type="button" class="btn btn-primary next-step" data-next="5">Selanjutnya</button>
          </div>
        </div>

      
        
        <!-- Step 5: Gambar & Informasi Tambahan -->
        <div class="step" data-step="5" style="display: none;">
          <div class="card p-3 mb-3">
            <div class="text-left mb-2">
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#additionalInfoHintModal">
                  <i class="fa fa-lightbulb-o" aria-hidden="true"></i> Petunjuk
              </button>
            </div>

            <!-- Modal Additional Information -->
            <div class="modal fade" id="additionalInfoHintModal" tabindex="-1" role="dialog" aria-labelledby="additionalInfoHintModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <!-- Header Modal -->
                        <div class="modal-header">
                            <h5 class="modal-title" id="additionalInfoHintModalLabel">Panduan Additional Information</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <!-- Body Modal -->
                        <div class="modal-body">
                            <h6><strong>1. Penjelasan Additional Information</strong></h6>
                            <img src="<?= base_url('assets/images/DiesCons.png') ?>" alt="Dies Construction" class="img-fluid mb-3">
                            <p>Dies Configuration digunakan untuk mengisi **PROCESS LAYOUT** dan **PROCESS DETAIL** yang akan ditempelkan pada bagian Excel seperti pada gambar di atas.</p>

                            <hr>

                            <h6><strong>2. Perhitungan Total MP</strong></h6>
                            <ul>
                                <li><strong>Jika Mesin Big Press</strong>: Setiap mesin **x 2 orang**, kecuali **Line E**.</li>
                                <li><strong>Jika Mesin 300T & SP</strong>: Setiap mesin **x 1 orang**.</li>
                                <li><strong>Untuk Line E</strong>: **4 mesin** hanya memerlukan **3 orang**.</li>
                            </ul>

                            <hr>

                            <h6><strong>3. Upload Gambar</strong></h6>
                            <p>Upload gambar bersifat **opsional** dan tidak wajib diisi melalui program.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card p-3 mb-3">
                <h5>Additional Information</h5>
                <div class="form-group row">
                  <div class="col-md-4 mb-3">
                    <label for="total_mp" class="col-form-label">Total MP</label>
                    <input type="text" id="total_mp" name="total_mp" class="form-control" value="<?= esc($pps['total_mp']) ?>">
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="doc_level" class="col-form-label">Doc Level</label>
                    <input type="text" id="doc_level" name="doc_level" class="form-control" value="<?= esc($pps['doc_level']) ?>">
                    <div id="docsuggestions" class="suggestions-dropdown" style="display: none;"></div>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="total_stroke" class="col-form-label">Total Stroke</label>
                    <input type="text" id="total_stroke" name="total_stroke" class="form-control" value="<?= esc($pps['total_stroke']) ?>">
                  </div>
                </div>
            </div>
            <div class="card p-3 mb-3">
              <h5>Gambar & Informasi Tambahan</h5>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label>Blank Layout</label>
                  <input type="file" name="blank_layout" class="form-control" accept=".jpg, .jpeg, .png">
                  <?php if(!empty($pps['blank_layout'])): ?>
                    <img src="<?= base_url('uploads/pps/' . $pps['blank_layout']) ?>" width="150" alt="Blank Layout">
                    <!-- Add hidden input to preserve the filename -->
                    <input type="hidden" name="old_blank_layout" value="<?= $pps['blank_layout'] ?>">
                  <?php endif; ?>
                </div>
                <div class="card p-3 mb-3">
                  <div class="row">
                    <div class="col-md-12 mb-3">
                      <label>Gambar Proses Layout <span class="text-danger">*</span></label>

                      <!-- Upload baru -->
                      <input type="file" name="process_layout_img" class="form-control mb-2" accept=".png,.jpg,.jpeg" id="processUpload">

                      <!-- Preview yang dipilih dari list atau hasil upload -->
                      <img id="processPreview" style="max-width: 120px; display: <?= !empty($pps['process_layout']) ? 'block' : 'none' ?>; margin-top: 5px;"
                        src="<?= !empty($pps['process_layout']) ? base_url('uploads/pps/' . $pps['process_layout']) : '' ?>" />

                      <!-- Jika ada data lama, simpan di hidden input -->
                      <?php if (!empty($pps['process_layout'])): ?>
                        <input type="hidden" name="old_process_layout" value="<?= $pps['process_layout'] ?>">
                      <?php endif; ?>

                      <!-- Hidden input jika pilih dari list -->
                      <input type="hidden" name="process_layout_selected" id="processSelected">

                      <!-- List gambar dari folder -->
                     <!-- Wrapper carousel -->
                      <div class="dcp-slider-wrapper mt-2">
                        <!-- Tombol kiri -->
                        <button type="button" class="slider-btn left" onclick="scrollSlider('left')">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left">
                            <polyline points="15 18 9 12 15 6"></polyline>
                          </svg>
                        </button>

                        <!-- Container gambar -->
                        <div id="processList" class="dcp-slider-container">
                          <!-- Gambar dimuat lewat JS -->
                        </div>

                        <!-- Tombol kanan -->
                        <button type="button" class="slider-btn right" onclick="scrollSlider('right')">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                            <polyline points="9 18 15 12 9 6"></polyline>
                          </svg>
                        </button>
                      </div>

                    </div>
                  </div>
                </div>

              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label>Created At</label>
                  <p class="form-control-plaintext"><?= isset($pps['created_at']) ? date('d-m-Y H:i', strtotime($pps['created_at'])) : '-' ?></p>
                </div>
              </div>
            </div>
            <div class="nav-buttons text-right">
              <button type="button" class="btn btn-secondary prev-step" data-prev="4">Sebelumnya</button>
              <button type="submit" class="btn btn-success">Update Data</button>
            </div>
        </div>
        <!-- End Step 5 -->
      </form>
      <div id="errorMessage" style="color: red;"></div>
    </div>
  </div>
</div>

<script>
  var csrfName = "<?= csrf_token() ?>";
  var csrfHash = "<?= csrf_hash() ?>";
</script>
<script>
function loadPpsImages2(containerId, hiddenInputId, previewId, selectedValue = '') {
  fetch("<?= base_url('Pps/listPpsImages') ?>")
    .then(res => res.json())
    .then(images => {
      images.forEach(imgPath => {
        const img = document.createElement('img');
        img.src = imgPath;
        img.style.width = '100px';
        img.style.cursor = 'pointer';
        img.style.border = '2px solid transparent';

        if (imgPath.includes(selectedValue)) {
          img.style.border = '2px solid green';
        }

        img.addEventListener('click', () => {
          document.getElementById(hiddenInputId).value = imgPath;
          document.getElementById(previewId).src = imgPath;
          document.getElementById(previewId).style.display = 'block';

          // Reset border
          containerId.querySelectorAll('img').forEach(i => {
            i.style.border = '2px solid transparent';
          });
          img.style.border = '2px solid green';
        });

        containerId.appendChild(img);
      });
    });
}

document.addEventListener('DOMContentLoaded', () => {
  const processList = document.getElementById('processList');
  const processSelected = document.getElementById('processSelected');
  const processPreview = document.getElementById('processPreview');

  loadPpsImages2(processList, 'processSelected', 'processPreview', '<?= $pps['process_layout'] ?? '' ?>');

  document.getElementById('processUpload').addEventListener('change', (e) => {
    processSelected.value = '';
    processPreview.src = URL.createObjectURL(e.target.files[0]);
    processPreview.style.display = 'block';
  });
});
</script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script>
          $(document).ready(function(){
            var rowCount = <?= !empty($dies) ? count($dies) : 1 ?>;
            
            // Tambah row
            $('#addRow').click(function(){
              var newRow = generateRow(rowCount);
              $('#tableBasic tbody').append(newRow.basic);
              $('#tablePress tbody').append(newRow.press);
              $('#tableDie tbody').append(newRow.die);
              $('#tableDieConstruction tbody').append(newRow.dieConstruction);
              $('#tableImages tbody').append(newRow.images);
              rowCount++;
            });
            
            // Hapus row berdasarkan data-index
            $('#tableBasic').on('click', '.deleteRow', function(){
              var $row = $(this).closest('tr');
              var index = $row.data('index');
              $('tr[data-index="' + index + '"]').remove();
            });
            
            // Sinkronisasi nilai dari Basic ke tabel lainnya
            $('#tableBasic').on('change', '.basic-process', function(){
              var val = $(this).val();
              var index = $(this).closest('tr').data('index');
              $('tr[data-index="'+ index +'"] .die-process, tr[data-index="'+ index +'"] .dc-proses, tr[data-index="'+ index +'"] .img-process').val(val);
            });
            $('#tableBasic').on('change', '.basic-machine', function(){
              var val = $(this).val();
              var index = $(this).closest('tr').data('index');
              $('tr[data-index="'+ index +'"] .press-machine').val(val);
              $('tr[data-index="'+ index +'"] .dc-machine').val(val);
            });
            
            // Fungsi generate row baru secara dinamis
            function generateRow(index) {
              // Tabel Basic
              var processNumber = (index + 1) * 10;
var processValue = 'OP' + processNumber;

var basic = '<tr data-index="'+ index +'">'+
  '<td>'+
    '<select name="dies['+ index +'][process]" class="form-control basic-process">'+
      '<option value="'+ processValue +'" selected>'+ processValue +'</option>'+
    '</select>'+
  '</td>'+

                '<td>'+
                  '<select name="dies['+ index +'][process_join]" class="form-control">'+
                    '<option value="" selected>Pilih</option>'+
                    '<?php foreach ($ops as $op): ?>'+
                      '<option value="<?= $op ?>"><?= $op ?></option>'+
                    '<?php endforeach; ?>'+
                  '</select>'+
                '</td>'+
            '<td>'+
                '<div class="input-proses">'+
                    // Dropdown 1
                    '<div class="proses-wrapper">'+
                        '<select name="dies['+ index +'][proses_input1]" class="form-control" onchange="updateProsesHidden(this.closest(\'div.input-proses\')); updateDCProcessDropdown('+ index +')">'+
                            '<option value="" selected>Pilih</option>'+ 
                            '<?php foreach ($prosesOptions as $p): ?>'+
                                '<option value="<?= $p ?>"><?= $p ?></option>'+
                            '<?php endforeach; ?>'+
                        '</select>'+
                        '<label>'+
                            '<input type="checkbox" class="proses-checkbox" data-index="1" onchange="updateProsesHidden(this.closest(\'div.input-proses\'))" value="CAM"> CAM'+
                        '</label>'+
                    '</div>'+

                    // Dropdown 2
                    '<div class="proses-wrapper">'+
                        '<select name="dies['+ index +'][proses_input2]" class="form-control" onchange="updateProsesHidden(this.closest(\'div.input-proses\')); updateDCProcessDropdown('+ index +')">'+
                            '<option value="" selected>Pilih</option>'+ 
                            '<?php foreach ($prosesOptions as $p): ?>'+
                                '<option value="<?= $p ?>"><?= $p ?></option>'+
                            '<?php endforeach; ?>'+
                        '</select>'+
                        '<label>'+
                            '<input type="checkbox" class="proses-checkbox" data-index="2" onchange="updateProsesHidden(this.closest(\'div.input-proses\'))" value="CAM"> CAM'+
                        '</label>'+
                    '</div>'+

                    // Dropdown 3
                    '<div class="proses-wrapper">'+
                        '<select name="dies['+ index +'][proses_input3]" class="form-control" onchange="updateProsesHidden(this.closest(\'div.input-proses\')); updateDCProcessDropdown('+ index +')">'+
                            '<option value="" selected>Pilih</option>'+ 
                            '<?php foreach ($prosesOptions as $p): ?>'+
                                '<option value="<?= $p ?>"><?= $p ?></option>'+
                            '<?php endforeach; ?>'+
                        '</select>'+
                        '<label>'+
                            '<input type="checkbox" class="proses-checkbox" data-index="3" onchange="updateProsesHidden(this.closest(\'div.input-proses\'))" value="CAM"> CAM'+
                        '</label>'+
                    '</div>'+
                    '<input type="text" name="dies['+ index +'][proses]" class="form-control" readonly>'+
                '</div>'+
            '</td>' +
                '<td>'+
                  '<div class="input-proses-gang">'+
                      // Dropdown 1 + Checkbox CAM
                      '<div class="proses-wrapper">'+
                          '<select name="dies['+ index +'][proses_gang_input1]" class="form-control" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\')); updateDCProcessDropdown('+ index +')">'+
                              '<option value="" selected>Pilih</option>'+ 
                              '<?php foreach ($prosesOptions as $p): ?>'+
                                  '<option value="<?= $p ?>"><?= $p ?></option>'+
                              '<?php endforeach; ?>'+
                          '</select>'+
                          '<label>'+
                              '<input type="checkbox" class="proses-gang-checkbox" data-index="1" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\'))" value="CAM"> CAM'+
                          '</label>'+
                      '</div>'+

                      // Dropdown 2 + Checkbox CAM
                      '<div class="proses-wrapper">'+
                          '<select name="dies['+ index +'][proses_gang_input2]" class="form-control" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\')); updateDCProcessDropdown('+ index +')">'+
                              '<option value="" selected>Pilih</option>'+ 
                              '<?php foreach ($prosesOptions as $p): ?>'+
                                  '<option value="<?= $p ?>"><?= $p ?></option>'+
                              '<?php endforeach; ?>'+
                          '</select>'+
                          '<label>'+
                              '<input type="checkbox" class="proses-gang-checkbox" data-index="2" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\'))" value="CAM"> CAM'+
                          '</label>'+
                      '</div>'+

                      // Dropdown 3 + Checkbox CAM
                      '<div class="proses-wrapper">'+
                          '<select name="dies['+ index +'][proses_gang_input3]" class="form-control" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\')); updateDCProcessDropdown('+ index +')">'+
                              '<option value="" selected>Pilih</option>'+ 
                              '<?php foreach ($prosesOptions as $p): ?>'+
                                  '<option value="<?= $p ?>"><?= $p ?></option>'+
                              '<?php endforeach; ?>'+
                          '</select>'+
                          '<label>'+
                              '<input type="checkbox" class="proses-gang-checkbox" data-index="3" onchange="updateProsesGangHidden(this.closest(\'div.input-proses-gang\'))" value="CAM"> CAM'+
                          '</label>'+
                      '</div>'+

                      '<input type="text" name="dies['+ index +'][proses_gang]" class="form-control" readonly>'+
                  '</div>'+
              '</td>'+

                '<td><input type="number" name="dies['+ index +'][panjang]" class="form-control" oninput="calculateLuas(this)"></td>'+
                '<td><input type="number" name="dies['+ index +'][lebar]" class="form-control" oninput="calculateLuas(this)"></td>'+
                '<td><input type="number" name="dies['+ index +'][length_mp]" class="form-control" oninput="calculateMainPressure(this)" readonly></td>'+
                '<td><input type="text" name="dies['+ index +'][main_pressure]" class="form-control" readonly></td>'+
                '<td>'+
                  '<select name="dies['+ index +'][machine]" class="form-control basic-machine" onchange="  calculateTotalMP(); onMachineChange(this); updateDCProcessDropdown('+ index +'); updateDieConstructionRow(this.closest(\'tr\').getAttribute(\'data-index\')); calculateDieWeight2(this)" >'+
                    '<?php foreach ($machineOptions as $option): ?>'+
                      '<option value="<?= esc($option) ?>" >'+
                        '<?= esc($option) ?>'+
                      '</option>'+ 
                    '<?php endforeach; ?>'+
                  '</select>'+
                '</td>'+
                '<td><input type="text" name="dies['+ index +'][capacity]" class="form-control" readonly></td>'+
                '<td><input type="text" name="dies['+ index +'][cushion]" class="form-control" readonly></td>'+
                '<td><button type="button" class="btn btn-danger deleteRow">Hapus</button></td>'+
              '</tr>';
              // Tabel Press M/C Spec (machine readonly)
              var press = '<tr data-index="'+ index +'">'+
                            '<td><input type="text" name="dies['+ index +'][machine]" class="form-control press-machine" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][bolster_length]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][bolster_width]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][slide_area_length]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][slide_area_width]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][die_height_max]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][cushion_pad_length]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][cushion_pad_width]" class="form-control" readonly></td>'+
                            '<td><input type="text" name="dies['+ index +'][cushion_stroke]" class="form-control" readonly></td>'+
                          '</tr>';
              // Tabel Die (process mengikuti basic)
              var die = '<tr data-index="'+ index +'">'+
                         '<td><input type="text" name="dies['+ index +'][process]" class="form-control die-process" value="'+ processValue +'" readonly></td>'+
                          '<td>'+
                            '<select name="dies['+ index +'][dc_process]" class="form-control">'+
                              '<option value="BIG DIE|SINGLE|DRAW">BIG DIE, SINGLE, DRAW</option>'+
                              '<option value="BIG DIE|SINGLE|DEEP DRAW">BIG DIE, SINGLE, DEEP DRAW</option>'+
                              '<option value="BIG DIE|SINGLE|TRIM">BIG DIE, SINGLE, TRIM</option>'+
                              '<option value="BIG DIE|SINGLE|FLANGE">BIG DIE, SINGLE, FLANGE</option>'+
                              '<option value="BIG DIE|SINGLE|CAM FLANGE">BIG DIE, SINGLE, CAM FLANGE</option>'+
                              '<option value="MEDIUM DIE|SINGLE|DRAW">MEDIUM DIE, SINGLE, DRAW</option>'+
                              '<option value="MEDIUM DIE|SINGLE|TRIM">MEDIUM DIE, SINGLE, TRIM</option>'+
                              '<option value="MEDIUM DIE|SINGLE|FLANGE">MEDIUM DIE, SINGLE, FLANGE</option>'+
                              '<option value="MEDIUM DIE|SINGLE|CAM PIE">MEDIUM DIE, SINGLE, CAM PIE</option>'+
                              '<option value="MEDIUM DIE|GANG|DRAW">MEDIUM DIE, GANG, DRAW</option>'+
                              '<option value="MEDIUM DIE|GANG|TRIM">MEDIUM DIE, GANG, TRIM</option>'+
                              '<option value="MEDIUM DIE|GANG|FLANGE-CAM PIE">MEDIUM DIE, GANG, FLANGE-CAM PIE</option>'+
                              '<option value="SMALL DIE|SINGLE|BLANK">SMALL DIE, SINGLE, BLANK</option>'+
                              '<option value="SMALL DIE|SINGLE|FORMING">SMALL DIE, SINGLE, FORMING</option>'+
                              '<option value="SMALL DIE|SINGLE|CAM PIE">SMALL DIE, SINGLE, CAM PIE</option>'+
                              '<option value="SMALL DIE|GANG|FORM-FLANGE">SMALL DIE, GANG, FORM-FLANGE</option>'+
                              '<option value="SMALL DIE|GANG|BEND 1, BEND 2">SMALL DIE, GANG, BEND 1, BEND 2</option>'+
                              '<option value="SMALL DIE|GANG|FORMING, PIE">SMALL DIE, GANG, FORMING, PIE</option>'+
                              '<option value="SMALL DIE|PROGRESSIVE|BLANK-PIE">SMALL DIE, PROGRESSIVE, BLANK-PIE</option>'+
                            '</select>'+
                          '</td>'+
                          '<td><input type="text" name="dies['+ index +'][die_length]" class="form-control" readonly></td>'+
                          '<td><input type="text" name="dies['+ index +'][die_width]" class="form-control" readonly></td>'+
                          '<td><input type="text" name="dies['+ index +'][die_height]" class="form-control" readonly></td>'+
                          '<td>'+
                            '<select name="dies['+ index +'][casting_plate]" class="form-control" onchange="calculateDieWeight(this); updateDieConstructionRow(this.closest(\'tr\').getAttribute(\'data-index\'))">'+
                              '<option value="casting">Casting</option>'+
                              '<option value="plate">Plate</option>'+
                            '</select>'+
                          '</td>'+
                          '<td><input type="text" name="dies['+ index +'][die_weight]" class="form-control" readonly></td>'+
                        '</tr>';
              // Tabel Die Construction (process & machine mengikuti basic)
              var dieConstruction = '<tr data-index="'+ index +'">'+
                                        '<td><input type="text" name="dies['+ index +'][proses]" class="form-control dc-proses" readonly></td>'+
                                        '<td><input type="text" name="dies['+ index +'][machine]" class="form-control dc-machine" readonly></td>'+
                                        '<td><input type="text" name="dies['+ index +'][upper]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][lower]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][pad]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][pad_lifter]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][sliding]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][guide]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][insert]" class="form-control"></td>'+
                                        '<td><input type="text" name="dies['+ index +'][heat_treatment]" class="form-control"></td>'+
                                      '</tr>';
              // Tabel Images (process mengikuti basic)
              var images = '<tr data-index="'+ index +'">'+
                              '<td><input type="text" name="dies['+ index +'][process]" class="form-control img-process" readonly></td>'+
                              '<td><input type="file" accept=".jpg, .jpeg, .png" name="dies['+ index +'][clayout_img]" class="form-control" onchange="previewImage(event, \'clayout_preview_'+ index +'\')">'+
                             ' <input type="hidden" name="dies[0][old_clayout_img]" value="">' +
                                '<br><img id="clayout_preview_'+ index +'" src="#" width="150" alt="Preview" style="display:none;">'+
                              '</td>'+
                              '<td><input type="file" accept=".jpg, .jpeg, .png" name="dies['+ index +'][die_construction_img]" class="form-control" onchange="previewImage(event, \'die_construction_preview_'+ index +'\')">'+
                              ' <input type="hidden" name="dies[0][old_die_construction_img]" value="">'  
                                '<br><img id="die_construction_preview_'+ index +'" src="#" width="150" alt="Preview" style="display:none;">'+
                              '</td>'+
                            '</tr>';
              return {
                basic: basic,
                press: press,
                die: die,
                dieConstruction: dieConstruction,
                images: images
              };
            }
          });
        </script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    const steps = document.querySelectorAll('.step');
    const stepProgress = document.querySelectorAll('.step-progress li');
    let currentStep = 1;

    function showStep(stepNumber) {
      steps.forEach(step => {
     
        step.style.display = 'none';
        step.classList.remove('active');
      });
    
      const activeStep = document.querySelector(`.step[data-step="${stepNumber}"]`);
      if (activeStep) {
        activeStep.style.display = 'block';
        activeStep.classList.add('active');
      }
      
      stepProgress.forEach((item, index) => {
        if (index < stepNumber) {
          item.classList.add('active');
        } else {
          item.classList.remove('active');
        }
      });
    }
    document.querySelectorAll('.next-step').forEach(button => {
      button.addEventListener('click', function() {
        const nextStep = parseInt(this.dataset.next);
        if (validateStep(currentStep)) {
          currentStep = nextStep;
          showStep(currentStep);
        }
      });
    });

    document.querySelectorAll('.prev-step').forEach(button => {
      button.addEventListener('click', function() {
        const prevStep = parseInt(this.dataset.prev);
        currentStep = prevStep;
        showStep(currentStep);
      });
    });

    function validateStep(stepNumber) {
      const currentStepElement = document.querySelector(`.step[data-step="${stepNumber}"]`);
      const requiredFields = currentStepElement.querySelectorAll('[required]');
      let isValid = true;
      requiredFields.forEach(field => {
        if (!field.value.trim()) {
          isValid = false;
          field.classList.add('is-invalid');
        } else {
          field.classList.remove('is-invalid');
        }
      });
      if (!isValid) {
        alert('Silakan lengkapi semua field yang wajib diisi.');
      }
      return isValid;
    }

    showStep(currentStep);
  });
</script>
<script>
function showMachineMatchModal() {
    const mainPressureInputs = document.querySelectorAll('input[name^="dies"][name$="[main_pressure]"]');
    const dieLengthInputs = document.querySelectorAll('input[name^="dies"][name$="[die_length]"]');
    const dieWidthInputs = document.querySelectorAll('input[name^="dies"][name$="[die_width]"]');
    const processInputs = document.querySelectorAll('select[name^="dies"][name$="[process]"]');

    let mainPressures = [];
    let dieLengths = [];
    let dieWidths = [];
    let processNames = [];
    let rowIndices = [];

    mainPressureInputs.forEach((input, index) => {
        const val = parseFloat(input.value);
        const length = parseFloat(dieLengthInputs[index]?.value);
        const width = parseFloat(dieWidthInputs[index]?.value);
        const process = processInputs[index]?.value || `OP${index+1}`;

        if (!isNaN(val) && !isNaN(length) && !isNaN(width)) {
            mainPressures.push(val);
            dieLengths.push(length);
            dieWidths.push(width);
            processNames.push(process);
            rowIndices.push(index);
        }
    });

    if (mainPressures.length === 0) {
        alert('Please fill in all Main Pressure, Die Length, and Die Width values.');
        return;
    }

    const modal = new bootstrap.Modal(document.getElementById('machineMatchModal'));
    const modalBody = document.querySelector('#machineMatchModal .modal-body');
    modalBody.innerHTML = '<div class="text-center py-4"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><p class="mt-2">Loading machine match data...</p></div>';
    modal.show();

    fetch('/machine-match/checkMatch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || ''
        },
        body: JSON.stringify({
            main_pressures: mainPressures,
            die_lengths: dieLengths,
            die_widths: dieWidths,
            process_names: processNames
        })
    })
    .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
    })
    .then(data => {
        let tabHeaderHtml = '';
        let tabContentHtml = '';

        data.forEach((row, index) => {
            const tabId = `pressure-tab-${index}`;
            const activeClass = index === 0 ? 'active' : '';
            const showClass = index === 0 ? 'show active' : '';
            const rowIndex = rowIndices[index];

            let tableRows = '';
            row.matches.forEach(match => {
                const highlightStyle = match.highlight ? ' style="background-color: #e6ffe6;"' : '';
                tableRows += `
                    <tr${highlightStyle}>
                        <td>${match.machine}</td>
                        <td>${match.capacity}</td>
                        <td>${match.cushion}</td>
                        <td>${match.bolster_length} x ${match.bolster_width}</td>
                        <td>${match.slide_area_length} x ${match.slide_area_width}</td>
                        <td>${match.match ? '✅ Match' : `❌ ${match.reason}`}</td>

                      
                    </tr>
                `;
            });

            tabHeaderHtml += `
                <li class="nav-item" role="presentation">
                    <button class="nav-link ${activeClass}" id="${tabId}-tab" data-bs-toggle="tab" data-bs-target="#${tabId}" type="button" role="tab" aria-controls="${tabId}" aria-selected="${index === 0}">
                        ${processNames[index] || `Row ${index + 1}`}
                    </button>
                </li>
            `;

            tabContentHtml += `
                <div class="tab-pane fade ${showClass}" id="${tabId}" role="tabpanel" aria-labelledby="${tabId}-tab">
                    <div class="alert alert-info">
                        <strong>Process:</strong> ${processNames[index]}<br>
                        <strong>Main Pressure:</strong> ${row.main_pressure || '-'} ton<br>
                        <strong>Die Size:</strong> ${row.die_length || '-'} x ${row.die_width || '-'} mm
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mt-2">
                            <thead class="table-light">
                                <tr>
                                    <th>Machine</th>
                                    <th>Capacity</th>
                                    <th>Cushion</th>
                                    <th>Bolster Area</th>
                                    <th>Slide Area</th>
                                    <th>Status</th>
                              
                                </tr>
                            </thead>
                            <tbody>${tableRows}</tbody>
                        </table>
                    </div>
                </div>
            `;
        });

        modalBody.innerHTML = `
            <ul class="nav nav-tabs" id="pressureTabs" role="tablist">
                ${tabHeaderHtml}
            </ul>
            <div class="tab-content mt-3" id="pressureTabContent">
                ${tabContentHtml}
            </div>
        `;
    })
    .catch(err => {
        console.error('Error:', err);
        modalBody.innerHTML = `
            <div class="alert alert-danger">
                <h5>Error Loading Machine Matches</h5>
                <p>${err.message}</p>
                <button class="btn btn-sm btn-secondary" onclick="showMachineMatchModal()">Try Again</button>
            </div>
        `;
    });
}


  document.addEventListener('DOMContentLoaded', function() {
  let partNoInput = document.getElementById("part_no");
    let cfInput = document.getElementById("cf");

    partNoInput.addEventListener("input", function () {
        if (partNoInput.value.includes("/") ||partNoInput.value.includes(",") ) {
            cfInput.value = "1/1";
        } else {
            cfInput.value = "1";
        }
    });
  });
  document.addEventListener('DOMContentLoaded', function () {
      // Untuk proses (biasa)
      document.querySelectorAll('.input-proses').forEach(function (container) {
          var inputProses = container.querySelector('input[name$="[proses]"]');
          if (inputProses) {
              setProsesFields(container, inputProses.value, 'proses-checkbox');
          }
      });

      // Untuk proses gang
      document.querySelectorAll('.input-proses-gang').forEach(function (container) {
          var inputProsesGang = container.querySelector('input[name$="[proses_gang]"]');
          if (inputProsesGang) {
              setProsesFields(container, inputProsesGang.value, 'proses-gang-checkbox');
          }
      });
  });


  function setProsesFields(container, valueStr, checkboxClass) {
      if (!container || typeof valueStr !== 'string') return;

      var parts = valueStr.split('-').map(item => item.trim());
      var selects = container.querySelectorAll('select');
      var checkboxes = container.querySelectorAll('.' + checkboxClass);

      // Reset dropdowns & checkboxes sebelum di-set ulang
      selects.forEach(select => select.value = "");
      checkboxes.forEach(checkbox => checkbox.checked = false);

      let camIndexes = []; // Untuk menyimpan indeks di mana 'CAM' ditemukan
      let processValues = [];

      parts.forEach((part, index) => {
          if (part.toUpperCase().includes("CAM")) {
              camIndexes.push(index);
              processValues.push(part.replace("CAM", "").trim()); // Hapus hanya "CAM", tidak pakai spasi setelahnya
          } else {
              processValues.push(part);
          }
      });


      // Atur nilai dropdown berdasarkan urutan
      processValues.forEach((value, index) => {
          if (selects[index]) {
              selects[index].value = value.toUpperCase(); // Set dropdown sesuai urutan
          }
      });

      // Set checkbox CAM sesuai urutan yang ditemukan
      camIndexes.forEach((camIndex) => {
          if (checkboxes[camIndex]) {
              checkboxes[camIndex].checked = true;
          }
      });

  }

  const partNoInput = document.getElementById('part_no');
  const cfInput = document.getElementById('cf');

  partNoInput.addEventListener('input', function() {
    const value = partNoInput.value;

    if (value.includes(',') || value.includes('/')) {
      cfInput.value = '1/1';
    } else {
      cfInput.value = '1';
    }
  });
</script>
<script>
function updateProsesGangHidden(containerGang) {
  if (!containerGang) return;
  
  var selects = containerGang.querySelectorAll('select');
  var cb = containerGang.querySelector('input.proses-gang-checkbox');
  var hidden = containerGang.querySelector('input[name*="[proses_gang]"]');

  var gabungan = "";
  if (selects.length >= 3) {
    gabungan = selects[0].value;
    
    if (selects[1].value != null && selects[1].value !== '') {
      gabungan += '-' + selects[1].value;
    }
    if (selects[2].value != null && selects[2].value !== '') {
      gabungan += '-' + selects[2].value;
    }
  }
  
  if (cb && cb.checked) {
    gabungan = "CAM" + (gabungan ? " " + gabungan : "");
  }
  
  if (hidden) {
    hidden.value = gabungan;
  }
}

function updateProsesHidden(containerProses) {
    if (!containerProses) return;

    var selects = containerProses.querySelectorAll('select');
    var checkboxes = containerProses.querySelectorAll('.proses-checkbox');
    var hidden = containerProses.querySelector('input[name*="[proses]"]');

    var gabungan = [];

    selects.forEach((select, index) => {
        if (select.value) {
            var value = select.value;
            if (checkboxes[index] && checkboxes[index].checked) {
                value = "CAM " + value;
            }
            gabungan.push(value);
        }
    });

    hidden.value = gabungan.join('-');
    console.log("Updated proses value:", hidden.value);
}


function updateDCProcessDropdown(rowIndex) {
  var $row = $('tr[data-index="' + rowIndex + '"]');

  var machine = $row.find('select[name="dies['+ rowIndex +'][machine]"]').val() || "";
  var proses = $row.find('select[name^="dies['+ rowIndex +'][proses_input"]').map(function() {
    return $(this).val();
  }).get().join(" ");
  var process = $row.find('select[name="dies['+ rowIndex +'][process_join]"]').val() || "";
  var processJoin = $row.find('select[name="dies['+ rowIndex +'][proses_gang_input1]"]').val() || "";

  var machineUpper = machine.toUpperCase();
  var category = "";
  if (/[ADEFG]/.test(machineUpper)) {
    category = "BIG DIE";
  } else if (/[BHC]/.test(machineUpper)) {
    category = "MEDIUM DIE";
  } else {
    category = "SMALL DIE";
  }

  var jenisProses = "";
  if (!processJoin || processJoin.trim() === "" || processJoin.trim() === "-") {
    jenisProses = "SINGLE";
  } else {
    jenisProses = "GANG";
  }

  var prosesValue = "";
  if (category === "BIG DIE") {
   
   jenisProses = "SINGLE";
   if (/DRAW|FORM|FLANGE|BEND|REST/.test(process)) {
     prosesValue = "DRAW";
   } else if(/CAM-FLANGE/.test(process)){
     prosesValue = "CAM FLANGE";
   }else if(/FLANGE/.test(process)){
     prosesValue = "FLANGE";
   }
   else {
     prosesValue = "TRIM";
   }
 } else if (category === "MEDIUM DIE") {
   if (jenisProses === "SINGLE") {
     if (/DRAW|FORM|BEND|REST/.test(process)) {
       prosesValue = "DRAW";
     } else if (process.includes("CAM") && process.includes("PIE")) {
       prosesValue = "CAM PIE";
     } else if (process.includes("FLANGE") ) {
       prosesValue = "FLANGE";
     } else {
       prosesValue = "TRIM";
     }
   } else { 
     if (/DRAW|FLANGE|FORM|BEND|REST/.test(process)) {
       prosesValue = "DRAW";
     } else if (process.includes("CAM") && process.includes("PIE")) {
       if (processJoin.includes("FLANGE")) {
         prosesValue = "FLANGE-CAM PIE";
       } else {
         prosesValue = "DRAW";
       }
     } else if (process.includes("FLANGE")) {
       if (processJoin.includes("CAM") && processJoin.includes("PIE")) {
         prosesValue = "FLANGE-CAM PIE";
       } else {
         prosesValue = "DRAW";
       }
     } else {
       prosesValue = "TRIM";
     }
   }
 } else if (category === "SMALL DIE") {
   if (jenisProses === "SINGLE") {
     if (process.includes("CAM") && process.includes("PIE")) {
       prosesValue = "CAM PIE";
     }else if (/DRAW|FLANGE|FORM|BEND|PIERCE|REST/.test(process)) {
       prosesValue = "FORMING";
     } else {
       prosesValue = "BLANK";
     }
   } else if (jenisProses === "GANG") {
     if (process.includes("BEND") || processJoin.includes("BEND")) {
       prosesValue = "BEND 1, BEND 2";
     } else if (
       (process.includes("FORM") || processJoin.includes("FORM")) &&
       (process.includes("PIE") || processJoin.includes("PIE"))
     ) {
       prosesValue = "FORMING, PIE";
     } else if (
       (process.includes("BLANK") || processJoin.includes("BLANK")) &&
       (process.includes("PIE") || processJoin.includes("PIE"))
     ) {
       prosesValue = "BLANK-PIE";
     } else if (
       (
             /TRIM|PIE|BLANK|SEP/.test(process) ||
             /TRIM|PIE|BLANK|SEP/.test(processJoin)
         )
     ) {
       prosesValue = "BLANK-PIE";
     } else {
       prosesValue = "FORM-FLANGE";
     }
   }
 }

  var dcProcessValue = category + "|" + jenisProses + "|" + prosesValue;


  var $dcProcessDropdown = $row.find('select[name="dies['+ rowIndex +'][dc_process]"]');
  if ($dcProcessDropdown.find('option[value="'+ dcProcessValue +'"]').length > 0) {
    $dcProcessDropdown.val(dcProcessValue);
  }
  var $dieSelect = $('#tableDie tbody').find('tr[data-index="'+ rowIndex +'"] select[name="dies['+ rowIndex +'][dc_process]"]');
  if ($dieSelect.length) {
    onStandardChange($dieSelect[0]);
  }
}

function updateDieConstructionRow(rowIndex) {

  var basicRow = document.querySelector('#tableBasic tbody tr[data-index="'+ rowIndex +'"]');
  var dieRow = document.querySelector('#tableDie tbody tr[data-index="'+ rowIndex +'"]');
  if (!basicRow) return; 
 
  const proses = basicRow.querySelector('input[name^="dies"][name$="[proses]"]').value;
  const casting_plate = dieRow.querySelector('[name^="dies"][name$="[casting_plate]"]').value;
  const machine = basicRow.querySelector('[name^="dies"][name$="[machine]"]').value;
  var angka = document.getElementById('material').value;
  var material = parseFloat(angka.replace(/\D/g, '')) || 0;
  var tonasi = parseFloat(document.getElementById('tonasi').value) || 0;

  var upperValue = ( casting_plate.includes("plate")) ? "SS41" : "FC300";
  console.log("wer"+casting_plate );
  var lowerValue = upperValue;
  var padValue = ( casting_plate.includes("plate")) ? "S45C" : "FCD55";
  
  var insertVal;
  if (material > 440 || tonasi > 1) {
    insertVal = "SKD11";
  } else if (
    proses.toUpperCase().includes("FL") ||
    proses.toUpperCase().includes("DR") ||
    proses.toUpperCase().includes("BE") ||
    proses.toUpperCase().includes("RE") ||
    proses.toUpperCase().includes("FO")
  ) {
    insertVal = "SXACE";
  } else if (proses.toUpperCase().includes("PI")) {
    insertVal = "S45C";
  } else if (
    proses.toUpperCase().includes("BL") ||
    proses.toUpperCase().includes("TR") ||
    proses.toUpperCase().includes("SEP") ||
    proses.toUpperCase().includes("CUT")
  ) {
    insertVal = "SKD11";
  } else {
    insertVal = "";
  }
  
  var heat_treatment = (insertVal === "SXACE") ? "FULLHARD + COATING" : "FLAMEHARD";
  var padLifterValue = (
    proses.toUpperCase().includes("FL") ||
    proses.toUpperCase().includes("DR") ||
    proses.toUpperCase().includes("BE") ||
    proses.toUpperCase().includes("RE") ||
    proses.toUpperCase().includes("FO")
  ) ? "Coil Spring" : "Gas Spring";
  var slidingValue = "Wear Plate";
  var guideValue = ( casting_plate.includes("pplate") ||
                    proses.toUpperCase().includes("BL") ||
                    proses.toUpperCase().includes("CUT") ||
                    proses.toUpperCase().includes("SEP") ||
                    proses.toUpperCase().includes("PIE") ||
                    proses.toUpperCase().includes("TR"))
                    ? "Guide Post" : "GUIDE HEEL";

  var dieConsRow = document.querySelector('#tableDieConstruction tbody tr[data-index="'+ rowIndex +'"]');
  if (!dieConsRow) return; 

  
  var inputProcess = dieConsRow.querySelector('input[name^="dies"][name$="[proses]"]');
  if (inputProcess) inputProcess.value = proses;

  var inputProcess = dieConsRow.querySelector('input[name^="dies"][name$="[machine]"]');
  if (inputProcess) inputProcess.value = machine;

  var inputcasting_plate = dieConsRow.querySelector('select[name^="dies"][name$="[casting_plate]"]');
  if (inputcasting_plate) inputcasting_plate.value = casting_plate;
  
  var inputUpper = dieConsRow.querySelector('input[name^="dies"][name$="[upper]"]');
  if (inputUpper) inputUpper.value = upperValue;
  
  var inputLower = dieConsRow.querySelector('input[name^="dies"][name$="[lower]"]');
  if (inputLower) inputLower.value = lowerValue;
  
  var inputPad = dieConsRow.querySelector('input[name^="dies"][name$="[pad]"]');
  if (inputPad) inputPad.value = padValue;
  
  var inputPadLifter = dieConsRow.querySelector('input[name^="dies"][name$="[pad_lifter]"]');
  if (inputPadLifter) inputPadLifter.value = padLifterValue;
  
  var inputSliding = dieConsRow.querySelector('input[name^="dies"][name$="[sliding]"]');
  if (inputSliding) inputSliding.value = slidingValue;
  
  var inputGuide = dieConsRow.querySelector('input[name^="dies"][name$="[guide]"]');
  if (inputGuide) inputGuide.value = guideValue;
  
  var inputInsert = dieConsRow.querySelector('input[name^="dies"][name$="[insert]"]');
  if (inputInsert) inputInsert.value = insertVal;
  
  var inputHeat = dieConsRow.querySelector('input[name^="dies"][name$="[heat_treatment]"]');
  if (inputHeat) inputHeat.value = heat_treatment;
}


// Add event listeners to trigger table update
  // document.addEventListener('DOMContentLoaded', function() {
  //   // Initial generation
  //    updateDieConstructionRow(rowIndex);

  //   // Add listeners to material and tonasi inputs
  //   document.getElementById('material').addEventListener('input', generateDieConstructionTable);
  //   document.getElementById('tonasi').addEventListener('input', generateDieConstructionTable);

  //   // Add listeners to all relevant inputs in tableBasic
  //   const tableBasic = document.getElementById('tableBasic');
  //   tableBasic.addEventListener('change', function(e) {
  //     if (e.target.matches('select, input')) {
  //        updateDieConstructionRow(rowIndex);
  //     }
  //   });
  // });
  function onStandardChange(selectElem) {  
    var selectedStandard = selectElem.value; 
    console.log("standar"+ selectedStandard);
    var basicRow = selectElem.closest('tr');
    var dieTableBody = document.getElementById('tableDie').querySelector('tbody');
    var dieRows = Array.from(dieTableBody.children);
    var rowIndex = dieRows.indexOf(basicRow);

    var formData = new FormData();
    formData.append('standard', selectedStandard);
    formData.append(csrfName, csrfHash);

    fetch("<?= site_url('pps/fetchStandard') ?>", {
      method: "POST",
      body: formData,
      headers: { "X-Requested-With": "XMLHttpRequest" }
    })
    .then(response => response.json())
    .then(data => {
      if (data.csrfHash) { 
        csrfHash = data.csrfHash; 
      }
      if (data.error) {
        alert(data.error);
      } else if (data.success) {
        var dieLengthValue = data.data['die_length'];
        var dieWidthValue = data.data['die_width'];

        var dieLengthInput = basicRow.querySelector('input[name^="dies"][name*="[die_length]"]');
        var dieWidthInput = basicRow.querySelector('input[name^="dies"][name*="[die_width]"]');

        if (dieLengthInput) {
          dieLengthInput.value = dieLengthValue;
        }
        if (dieWidthInput) {
          dieWidthInput.value = dieWidthValue;
        }
      }
    })
    .catch(error => {
      alert("Terjadi kesalahan: " + error);
      console.error(error);
    });
  }
</script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
  let length = document.getElementById('length');
  let width = document.getElementById('width');
  let tonasi = document.getElementById('tonasi');
  let boq = document.getElementById('boq');
  let blank = document.getElementById('blank');
  let panel = document.getElementById('panel');
  let scrap = document.getElementById('scrap');

  function calculateBlank() {
    let l = parseFloat(length.value) || 0;
    let w = parseFloat(width.value) || 0;
    let t = parseFloat(tonasi.value) || 0;
    let b = parseFloat(boq.value) || 1;

    let tes = (l * w * t * 7.85 / 1000000).toFixed(3);
    let result = ((l * w * t * 7.85 / 1000000) / b).toFixed(3);
    
    blank.value = result;
    
    calculateScrap();
  }

    
  function calculateScrap() {
      let blankVal = parseFloat(blank.value) || 0;
      let panelVal = parseFloat(panel.value) || 0;
      let scrapVal = blankVal - panelVal;
      scrap.value = scrapVal.toFixed(3);
    }
    [length, width, tonasi, boq].forEach(input => {
      input.addEventListener('input', calculateBlank);
    });
    panel.addEventListener('input', calculateScrap);
  });

  function calculateDieWeight(element) {
    var currentRow = element.closest('tr');
    var index = currentRow.getAttribute('data-index');
    var tableId = currentRow.closest('table').id;
    
    // Jika elemen dipanggil dari tableBasic, kita perlu mencari baris yang sesuai di tableDie
    if (tableId === "tableBasic") {
        currentRow = document.querySelector('#tableDie tr[data-index="' + index + '"]');
        if (!currentRow) {
            console.error("Baris di tableDie dengan data-index " + index + " tidak ditemukan.");
            return;
        }
    }
    
    var dieLengthElem = currentRow.querySelector('input[name$="[die_length]"]');
    var dieWidthElem  = currentRow.querySelector('input[name$="[die_width]"]');
    var dieHeightElem = currentRow.querySelector('input[name$="[die_height]"]');
    var castplateElem = currentRow.querySelector('select[name$="[casting_plate]"]');
    
    var prosesElem = document.querySelector('#tableBasic tr[data-index="' + index + '"] input[name$="[proses]"]');
    
    if (!dieLengthElem || !dieWidthElem || !dieHeightElem || !prosesElem || !castplateElem) {
        console.error("Beberapa elemen tidak ditemukan untuk baris index " + index);
        return;
    }
    
    var dieLength = parseFloat(dieLengthElem.value) || 0;
    var dieWidth  = parseFloat(dieWidthElem.value)  || 0;
    var dieHeight = parseFloat(dieHeightElem.value) || 0;
    
    var prosesValue   = prosesElem.value.toLowerCase();
    var castplateValue = castplateElem.value.toLowerCase();
    
    var factor = 1;
   
    if (castplateValue === "casting") {
        if (prosesValue.includes("bend")) { factor = 0.44; }
        else if (prosesValue.includes("form")|| prosesValue.includes("rest")) { factor = 0.43; }
        else if (prosesValue.includes("blank")) { factor = 0.40; }
        else if (prosesValue.includes("fl")) { factor = 0.40; }
        else if (prosesValue.includes("pie")) { factor = 0.39; }
        else if (prosesValue.includes("trim")|| prosesValue.includes("sep")) { factor = 0.38; }
        else if (prosesValue.includes("draw")) { factor = 0.37; }
        else{
          factor = 0.50; 
        }
    } else if (castplateValue === "plate") {
        if (prosesValue.includes("blank")) { factor = 0.52; }
        else if (prosesValue.includes("trim")|| prosesValue.includes("sep")) { factor = 0.52; }
        else if (prosesValue.includes("bend")) { factor = 0.50; }
        else if (prosesValue.includes("form")|| prosesValue.includes("rest")) { factor = 0.50; }
        else if (prosesValue.includes("pie")) { factor = 0.46; }
        else if (prosesValue.includes("fl")) { factor = 0.46; }
        else if (prosesValue.includes("draw")) { factor = 0.45; }
        else{
          factor = 0.50; 
        }
    }
    var dieWeight = (dieLength * dieWidth * dieHeight * factor * 7.85) / 1000000;
    
    var dieWeightElem = currentRow.querySelector('input[name$="[die_weight]"]');
    if (dieWeightElem) {
        dieWeightElem.value = dieWeight.toFixed(2);
    } else {
        console.error("Elemen input untuk die_weight tidak ditemukan di baris index " + index);
    }
  }


  document.addEventListener("DOMContentLoaded", function () {
      document.querySelectorAll('#tableDie input, #tableDie select').forEach(function (input) {
          input.addEventListener("input", function () {
              calculateDieWeight(this);
          });
      });
  });

  function onMachineChange(elem) {
    var machine = $(elem).val();
    var $basicRow = $(elem).closest('tr');
    var index = $basicRow.data('index');

    $('tr[data-index="'+ index +'"] .press-machine').val(machine);

    $.ajax({
      url: "<?= base_url('pps/fetchMachineByMachine') ?>",
      type: "POST",
      dataType: "json",
      data: { machine: machine },
      success: function(response) {
          if (response.success) {
            var basicData = response.data;
            var machineData = response.machine_data;
            var dh_dies = response.dh_dies;
             $basicRow.find('input[name*="[capacity]"]').val(basicData.capacity);
            $basicRow.find('input[name*="[cushion]"]').val(basicData.cushion);
            
             var $pressRow = $('#tablePress tbody').find('tr[data-index="'+ index +'"]');
            $pressRow.find('input[name*="[machine]"]').val(machineData.machine);
            $pressRow.find('input[name*="[bolster_length]"]').val(machineData.bolster_length);
            $pressRow.find('input[name*="[bolster_width]"]').val(machineData.bolster_width);
            $pressRow.find('input[name*="[slide_area_length]"]').val(machineData.slide_area_length);
            $pressRow.find('input[name*="[slide_area_width]"]').val(machineData.slide_area_width);
            $pressRow.find('input[name*="[die_height_max]"]').val(machineData.die_height);
            $pressRow.find('input[name*="[cushion_pad_length]"]').val(machineData.cushion_pad_length);
            $pressRow.find('input[name*="[cushion_pad_width]"]').val(machineData.cushion_pad_width);
            $pressRow.find('input[name*="[cushion_stroke]"]').val(machineData.cushion_stroke);
           
            var $sizingRow = $('#tableDie tbody').find('tr[data-index="'+ index +'"]');
            $sizingRow.find('input[name*="[die_height]"]').val(dh_dies.dh_dies);
            updateDCProcessDropdown(index);
     
          } else {
            console.error(response.error);
          }
      },
      error: function(xhr, status, error) {
        console.log("Error fetching machine data: " + error);
      }
    });
  }
  function calculateLuas(element) {
      var row = element.closest('tr');
      if (!row) return;

      var panjangInput = row.querySelector('input[name*="[panjang]"]');
      var lebarInput = row.querySelector('input[name*="[lebar]"]'); 

      if (!panjangInput || !lebarInput) return;

      var panjangValue = parseFloat(panjangInput.value) || 0;
      var lebarValue   = parseFloat(lebarInput.value)   || 0;

      var luas = panjangValue * lebarValue;

      var lengthMpInput = row.querySelector('input[name*="[length_mp]"]');
      if (lengthMpInput) {  
          lengthMpInput.value = luas;
          calculateMainPressure(row);
      }
  }

  function calculateMainPressure(element) {

    var row = element.closest('tr');

    var lengthMpInput = row.querySelector('input[name*="[length_mp]"]');
    var length_mp = parseFloat((lengthMpInput && lengthMpInput.value) ? lengthMpInput.value : 0) || 0;

    var materialElem = document.getElementById('material');
    var materialText = (materialElem && materialElem.value) ? materialElem.value : "";
    var materialMatch = materialText.match(/\d+/); 
    var material = materialMatch ? parseInt(materialMatch[0]) : 0;

    var tensile_material;
    if (material === 270) {
      tensile_material = 30;
    } else if (material === 440) {
      tensile_material = 45;
    } else if (material === 590) {
      tensile_material = 60;
    } else {
      tensile_material = 100;
    }

    var tonasiElem = document.querySelector('[name="tonasi"]');
    var thickness = (tonasiElem && tonasiElem.value) ? parseFloat(tonasiElem.value) : 0;

    var prosesSelect = row.querySelector('input[name*="[proses]"]');
    var proses = prosesSelect ? prosesSelect.value : '';

    var specialProcesses = ["BLANK", "PIE", "TRIM", "SEP"];
    var multiplier = specialProcesses.some(sp => proses.includes(sp)) ? 1 : 2.5;

    var mainPressure = (length_mp * thickness * 0.8 * tensile_material * 1.2 * multiplier) / 1000;
    console.log("Length MP:", length_mp, "Thickness:", thickness, "Tensile Material:", tensile_material, "Multiplier:", multiplier);

    var mainPressureInput = row.querySelector('input[name*="[main_pressure]"]');
    if (mainPressureInput) {
      mainPressureInput.value = mainPressure.toFixed(2);
    }
  }

  var custSuggestions = ["MMKI", "ADM", "TMMIN", "GMR", "HMMI", "HPM"];

  $(document).ready(function(){
      $('#cust').on('input', function(){
          var inputVal = $(this).val().toLowerCase();
          var suggestionBox = $('#cust-suggestions');
          suggestionBox.empty();
          
          var matches = custSuggestions.filter(function(item){
              return item.toLowerCase().indexOf(inputVal) !== -1;
          });
          
          if(matches.length > 0 && inputVal.length > 0){
              matches.forEach(function(match){
                  suggestionBox.append('<div class="suggestion-item">' + match + '</div>');
              });
              suggestionBox.show();
          } else {
              suggestionBox.hide();
          }
      });

      $('#cust-suggestions').on('click', '.suggestion-item', function(){
          $('#cust').val($(this).text());
          $('#cust-suggestions').hide();
      });

      $(document).on('click', function(event){
          if(!$(event.target).closest('#cust, #cust-suggestions').length){
              $('#cust-suggestions').hide();
          }
      });
  });
</script>
<script>
    var DocSuggestions = ["RFQ"];

    $(document).ready(function(){
        $('#doc_level').on('input', function(){
            var inputVal = $(this).val().toLowerCase();
            var suggestionBox = $('#docsuggestions');
            suggestionBox.empty();
            
            var matches = DocSuggestions.filter(function(item){
                return item.toLowerCase().indexOf(inputVal) !== -1;
            });
            
            if(matches.length > 0 && inputVal.length > 0){
                matches.forEach(function(match){
                    suggestionBox.append('<div class="suggestion-item">' + match + '</div>');
                });
                suggestionBox.show();
            } else {
                suggestionBox.hide();
            }
        });

       $('#docsuggestions').on('click', '.suggestion-item', function(){
            $('#doc_level').val($(this).text());
            $('#docsuggestions').hide();
        });

        $(document).on('click', function(event){
            if(!$(event.target).closest('#cust, #cust-suggestions').length){
                $('#cust-suggestions').hide();
            }
        });
    });
</script>
<script>
    var custSuggestions = ["MMKI", "ADM", "TMMIN", "GMR", "HMMI"];

    $(document).ready(function(){
        $('#cust').on('input', function(){
            var inputVal = $(this).val().toLowerCase();
            var suggestionBox = $('#cust-suggestions');
            suggestionBox.empty();
            
            var matches = custSuggestions.filter(function(item){
                return item.toLowerCase().indexOf(inputVal) !== -1;
            });
            
            if(matches.length > 0 && inputVal.length > 0){
                matches.forEach(function(match){
                    suggestionBox.append('<div class="suggestion-item">' + match + '</div>');
                });
                suggestionBox.show();
            } else {
                suggestionBox.hide();
            }
        });

        $('#cust-suggestions').on('click', '.suggestion-item', function(){
            $('#cust').val($(this).text());
            $('#cust-suggestions').hide();
        });

        $(document).on('click', function(event){
            if(!$(event.target).closest('#cust, #cust-suggestions').length){
                $('#cust-suggestions').hide();
            }
        });
    });
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  let length = document.getElementById('length');
  let width = document.getElementById('width');
  let tonasi = document.getElementById('tonasi');
  let boq = document.getElementById('boq');
  let blank = document.getElementById('blank');
  let panel = document.getElementById('panel');
  let scrap = document.getElementById('scrap');

  function calculateBlank() {
    let l = parseFloat(length.value) || 0;
    let w = parseFloat(width.value) || 0;
    let t = parseFloat(tonasi.value) || 0;
    let b = parseFloat(boq.value) || 1;

    let tes = (l * w * t * 7.85 / 1000000).toFixed(3);
    let result = ((l * w * t * 7.85 / 1000000) / b).toFixed(3);
    
    blank.value = result;
    
    calculateScrap();
}

  
function calculateScrap() {
  let blankVal = parseFloat(blank.value) || 0;
  let panelVal = parseFloat(panel.value) || 0;
  let scrapVal = blankVal - panelVal;
  scrap.value = scrapVal.toFixed(3);
  
  let scrapError = document.getElementById('scrapError');
  if (scrapVal < 0) {
    scrapError.textContent = "Warning: Nilai Scrap negatif!";
  } else {
    scrapError.textContent = "";
  }
}

  [length, width, tonasi, boq].forEach(input => {
    input.addEventListener('input', calculateBlank);
  });
  panel.addEventListener('input', calculateScrap);
});
function calculateTotalMP() {
    // Ambil semua select dengan name yang mengandung [machine]
    var machineSelects = document.querySelectorAll('select[name^="dies"][name$="[machine]"]');
    var totalMP = 0;

    machineSelects.forEach(function(select) {
        var machineVal = select.value.toUpperCase();

        if (machineVal.includes("E")) {
            totalMP = 3; // Langsung 3, tidak ditambah
            
        } else if (machineVal.includes("SP")) {
            totalMP += 1;
        } else {
            totalMP += 2;
        }
    });

    document.getElementById('total_mp').value = totalMP;
}


    function loadPpsImageList(index, type) {
      const container = document.getElementById(`${type}_image_list_${index}`);
      const hiddenInput = document.getElementById(`selected_${type}_${index}`);
      
      fetch("<?= base_url('Pps/listPpsImages') ?>")
        .then(response => response.json())
        .then(images => {
          container.innerHTML = ''; // kosongkan container
          images.forEach(imgUrl => {
            const img = document.createElement('img');
            img.src = imgUrl;
            img.width = 100;
            img.classList.add('selectable-image');
            img.style.cursor = 'pointer';
            img.onclick = () => {
              hiddenInput.value = imgUrl;
              document.getElementById(`${type}_preview_${index}`).src = imgUrl;
              document.getElementById(`${type}_preview_${index}`).style.display = 'block';
            };
            container.appendChild(img);
          });
        });
    }
    function scrollSlider(direction) {
  const container = document.getElementById('processList');
  const scrollAmount = 150;

  if (direction === 'left') {
    container.scrollLeft -= scrollAmount;
  } else if (direction === 'right') {
    container.scrollLeft += scrollAmount;
  }
}
function calculateDieWeight2(element) {
    // Ambil index baris dari atribut data-index
    var index = element.closest("tr").getAttribute("data-index");

    // Cari baris di #tableDie yang sesuai
    var dieTableRow = document.querySelector('#tableDie tbody tr[data-index="' + index + '"]');

    if (!dieTableRow) {
        console.error("Baris tidak ditemukan di #tableDie untuk index:", index);
        return;
    }

    // Ambil input dari tabel #tableDie
    var dieLength = parseFloat(dieTableRow.querySelector('input[name="dies[' + index + '][die_length]"]')?.value) || 0;
    var dieWidth = parseFloat(dieTableRow.querySelector('input[name="dies[' + index + '][die_width]"]')?.value) || 0;
    var dieHeight = parseFloat(dieTableRow.querySelector('input[name="dies[' + index + '][die_height]"]')?.value) || 0;

    var dieProsesStandardDieElem = dieTableRow.querySelector('select[name="dies[' + index + '][dc_process]"]');
    var castplateElem = dieTableRow.querySelector('select[name="dies[' + index + '][casting_plate]"]');

    if (!castplateElem) {
        console.error("Elemen casting_plate tidak ditemukan di #tableDie.");
        return;
    }

    // Ambil nilai proses dari #tableBasic berdasarkan index
    var basicTableRow = document.querySelector('#tableBasic tbody tr[data-index="' + index + '"]');
    if (!basicTableRow) {
        console.error("Baris tidak ditemukan di #tableBasic untuk index:", index);
        return;
    }

    var prosesElem = basicTableRow.querySelector('input[name="dies[' + index + '][proses]"]');
    var prosesValue = prosesElem ? prosesElem.value.toLowerCase() : "";

    var castplateValue = castplateElem.value.toLowerCase();
    var factor = 1;

    if (castplateValue === "casting") {
        if (prosesValue.includes("bend")) factor = 0.44;
        else if (prosesValue.includes("form") || prosesValue.includes("rest")) factor = 0.43;
        else if (prosesValue.includes("blank")) factor = 0.40;
        else if (prosesValue.includes("flange")) factor = 0.40;
        else if (prosesValue.includes("pie")) factor = 0.39;
        else if (prosesValue.includes("trim") || prosesValue.includes("sep")) factor = 0.38;
        else if (prosesValue.includes("draw")) factor = 0.37;
    } else if (castplateValue.includes("plate")) {
        if (prosesValue.includes("blank") || prosesValue.includes("trim") || prosesValue.includes("sep")) factor = 0.52;
        else if (prosesValue.includes("bend") || prosesValue.includes("form") || prosesValue.includes("rest")) factor = 0.50;
        else if (prosesValue.includes("pie") || prosesValue.includes("fl")) factor = 0.46;
        else if (prosesValue.includes("draw")) factor = 0.45;
    }

    var dieWeight = (dieLength * dieWidth * dieHeight * factor * 7.85) / 1000000;
    var dieWeightElem = dieTableRow.querySelector('input[name="dies[' + index + '][die_weight]"]');

    if (dieWeightElem) {
        dieWeightElem.value = dieWeight.toFixed(2);
        console.log("Berat die dihitung:", dieWeightElem.value);
    } else {
        console.error("Input untuk die_weight tidak ditemukan.");
    }
}
  
</script>


<?= $this->endSection() ?>
